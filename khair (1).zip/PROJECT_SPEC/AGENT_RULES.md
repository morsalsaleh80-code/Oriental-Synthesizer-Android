# Agent Rules & Engineering Constraints

## 1. Clean-Room Implementation Mandate
- **Strict Independence**: All architectures, algorithms, data structures, and code must be authored independently from first principles.
- **No Proprietary Artifacts**: Absolutely no proprietary Korg/Yamaha/Roland source code, disassembly, ROM dumps, or copyrighted assets may be imported, referenced, or reproduced.
- **Clean Greenfield**: This codebase has zero legacy dependencies. Never search for, copy, or migrate code from any past PA arranger projects.

## 2. Hard Real-Time Audio Constraints (Zero-Tolerance Rules)
In any code executing on or invoked by the audio thread:
1. **NO Memory Allocation / Deallocation**: Never call `malloc`, `free`, `new`, `delete`, or operations resizing vectors/strings. All audio buffers, voice pools, and tables must be pre-allocated.
2. **NO Blocking Synchronization**: Never use `std::mutex`, `synchronized`, Java monitors, semaphores, or condition variables. Only lock-free atomic primitives and lock-free SPSC queues are permitted.
3. **NO I/O Operations**: Never perform disk reads/writes, database operations, socket/network operations, or IPC.
4. **NO JVM/JNI Invocations**: The audio thread must never invoke JNI callbacks or Java/Kotlin methods. Communication from native audio to UI/Kotlin must be via lock-free atomic snapshots or polling ring buffers.
5. **NO Uncontrolled Loops / Heavy Logging**: Never log strings (`__android_log_print`) or perform unbounded loops inside the audio callback.
6. **Bounded Execution Time**: The audio callback must execute well within its buffer deadline (e.g., < 2 ms for a 96-sample buffer at 48 kHz).

## 3. UI and Feature Integrity
- **No Fake Features or Dead-End UI Affordances**: Every button, slider, and toggle in the UI must connect to a functional backend subsystem. If a feature is scheduled for a future phase, it must not be presented as active.
- **Clear Identification of Scaffolding**: Any temporary test harness, mock clock, or scaffolding must be explicitly labeled in both code and UI.
- **Deterministic State Flow**: The UI interacts solely with the Performance Controller via unidirectional data flow (UDF). The Controller translates user intent into timestamped real-time events.

## 4. Engineering Autonomy & Safeguards
- The agent may independently make design and architectural decisions consistent with the Master Spec.
- **STOP & REPORT** immediately before:
  - Destructive architecture replacement.
  - Irreversible data migration or schema breakage.
  - Incompatible public API redesign.
  - Any violation of real-time audio safety rules.
