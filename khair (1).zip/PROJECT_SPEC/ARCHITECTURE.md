# Architecture Specification — Professional Android Arranger Workstation

## 1. System Module Hierarchy & Dependencies

```
[ Android Jetpack Compose UI ]
        │  (Unidirectional State & User Intent)
        ▼
[ Performance Controller & State Layer (Kotlin) ]
        │
   ┌────┴──────────────────────────┐
   ▼                               ▼
[ MIDI Dispatcher & Input ]  [ Arranger / Style Manager ]
   │                               │
   └──────────────┬────────────────┘
                  │ (JNI boundary: thread-safe, non-blocking)
                  ▼
[ Realtime Event Queue (Native C++ Lock-Free SPSC) ]
                  │
                  ▼
[ Native Audio Engine (C++20) ]
   ├── Voice Engine & Synthesis Pipeline
   ├── Voice Allocator (Bounded O(1) Stealing)
   ├── Resonant Filter & ADSR Modulators
   ├── 8-Bus Arranger Mixer & Master Bus
   └── Oboe / AAudio Low-Latency Audio Stream Callback
```

## 2. Dependency Direction
- **UI** depends on **Performance Controller** (ViewModels and UI States).
- **Performance Controller** depends on **AudioBridge** (Kotlin JNI interface).
- **AudioBridge** interacts with **C++ Native Audio Engine** via pure C bindings / JNI export functions.
- **Native Audio Engine** has zero dependency on Java, Android Framework, or UI classes.
- Dependency rule: Lower layers NEVER depend on upper layers. Audio callback NEVER calls into JNI.

## 3. Audio Path
1. Hardware audio driver invokes `AudioStreamCallback::onAudioReady(oboe::AudioStream *stream, void *audioData, int32_t numFrames)`.
2. Audio engine drains pending real-time events from the SPSC ring buffer (e.g. `NoteOn`, `NoteOff`, `PitchBend`, `ParamChange`).
3. Active voices process their sample frames:
   - Calculate pitch ratio (accounting for base tuning, pitch bend, and oriental cent offsets).
   - Advance oscillator phase or sample read pointer.
   - Apply biquad filter and ADSR envelope gain.
   - Accumulate into per-channel stereo mix buffers.
4. Channel strips apply volume, pan, and FX sends.
5. Master bus applies master limiter / soft-clipper to prevent harsh distortion.
6. Interleaved stereo float32 frames are written directly to `audioData`.
7. Atomic peak meters and diagnostic counters are updated for the UI.

## 4. MIDI Path
1. External USB MIDI (via Android USB Host API) or on-screen touch keyboard generates MIDI events.
2. MIDI events are converted to a normalized `WorkstationEvent` struct with a 64-bit nanosecond timestamp.
3. Controller enqueues the event into the native lock-free ring buffer via JNI without taking locks.
4. In the audio thread, events are processed before generating the next buffer segment, maintaining sample-accurate timing.

## 5. Persistence Path (Future Phases)
- Performance presets, sound sets, and user configurations are stored in JSON/Protobuf formats via Kotlin Coroutines on `Dispatchers.IO`.
- Loading a sound bank writes data into pre-allocated memory pools before activating the bank in the audio engine.
- Zero disk reads during active audio rendering.

## 6. Arranger & Sampler Subsystems Integration
- **Arranger**: Evaluates chords played on lower keyboard zone, tracks meter/bar/beat clock, and triggers accompaniment pattern events into the Realtime Event Bus.
- **Sampler**: Maps sample WAV/PCM data into memory-mapped buffers with pre-calculated loop points and key zones.
