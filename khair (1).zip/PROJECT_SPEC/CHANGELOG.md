# Changelog — Professional Android Arranger Workstation

All notable changes to this project will be documented in this file.

## [Phase 6.5.0] - Real KORG SET PCM Playback Pipeline
### Added
- **Native PCM Voice Engine (`WorkstationVoicePool.h`)**: Implemented `PcmSample` multi-sample memory architecture with bounded preallocated slots (up to 16 sample slots), real-time linear interpolation, loop boundary wrapping (`[loopStart, loopEnd)`), note-off decay gating, and pitch-ratio calculation accounting for root key, cent offset, and pitch bend.
- **Audio Engine Forwarding (`OboeAudioEngine.h`)**: Delegated `loadPcmSample`, `clearPcmSamples`, `isPcmSampleLoaded`, and `setActivePcmSlot` into native voice pool off the real-time audio thread.
- **JNI Bridge Integration (`native-bridge.cpp`)**: Added thread-safe JNI exports (`loadPcmSample16`, `loadPcmSampleFloat`, `clearPcmSamples`, `isPcmSampleLoaded`, `setActivePcmSlot`) converting 16-bit little-endian PCM byte streams to normalized floats with zero locks in audio render path.
- **Kotlin Audio Bridge (`NativeAudioBridge.kt`)**: Added `loadIrSample()` bridge method allowing verified `IrSample` instances with real PCM bytes to be loaded into native memory.
- **PCM Parser Enhancements (`PcmParser.kt`)**: Implemented `encodeRiffWave()` for standard RIFF/WAVE round-trips with `smpl` chunk support, and `createAcousticReferenceSample()` providing verified 16-bit PCM harmonic waveforms.
- **Factory Reference SET Integration (`SetRepository.kt`)**: Upgraded factory demo SET to supply verified 16-bit linear PCM audio samples.
- **Controller Auto-Binding (`PerformanceController.kt`)**: Connected SET package activation to load verified PCM samples into the native engine for Upper/Lead keyboard playback, with `isPcmPlaybackActive` state flag.
- **Unit & Integration Test Suite (`PcmPlaybackUnitTest.kt`)**: Added comprehensive tests verifying RIFF WAVE encoding/decoding, sampler chunk loop parsing, pitch transposition mathematics across octaves, and graceful fallback when native libraries are absent.


## [Fix] - Oboe Audio Stream Resiliency & Format Conversion
### Fixed
- Resolved `AudioTrack` buffer underrun/mismatch (`EVENT_MORE_DATA requested 7680 bytes but callback returned -1 bytes`) by enabling `setFormatConversionAllowed(true)` and `setChannelConversionAllowed(true)` on `AudioStreamBuilder`.
- Resolved `ErrorDisconnected` crash in browser emulator / shared audio endpoints by switching from `SharingMode::Exclusive` to `SharingMode::Shared` with `PerformanceMode::LowLatency`.
- Added multi-format buffer fallback in `onAudioReady` supporting both `AudioFormat::Float` and `AudioFormat::I16` with zero heap allocations.
- Fixed race condition and double-close error in `onErrorAfterClose` by resetting stream references prior to reopening.


## [Phase 0.1.0] - Greenfield Inception
### Added
- Created complete project governance and architecture documentation under `PROJECT_SPEC/`:
  - `MASTER_PROJECT_SPEC.md`
  - `AGENT_RULES.md`
  - `REALTIME_RULES.md`
  - `ARCHITECTURE.md`
  - `THREADING_MODEL.md`
  - `REALTIME_AUDIT.md`
  - `PROJECT_STATE.md`
  - `CHECKPOINT.md`
  - `TASK_QUEUE.md`
  - `CHANGELOG.md`
- Synchronized application naming in `metadata.json` and `strings.xml` to "Arranger Workstation".
- Established native audio pipeline architecture:
  - C++20 lock-free Single-Producer Single-Consumer (SPSC) event ring buffer.
  - Low-latency audio callback framework utilizing Oboe / AAudio.
  - Polyphonic voice pool with deterministic $O(1)$ voice allocation and stealing.
  - Real-time diagnostic metrics (callback duration, active voice counter, buffer frames, xrun tracking).
  - JNI native bridge for lock-free communication between Kotlin and C++.
  - Jetpack Compose workstation UI with responsive multi-touch performance keyboard and diagnostic telemetry.

## [Phase 6.0.0] - Arranger Sequencer & Style Playback Engine
### Added
- **KORG Note Translation Engine (NTT)** (`NoteTranslationEngine.kt`): Complete musical voice-leading algorithms supporting Parallel, Fixed, and Bass-follow rules with automatic slash-chord inversion tracking and register clamping.
- **Factory Multi-Track Pattern Bank** (`FactoryStylePatternGenerator.kt`): Authentic 8-track accompaniment arrangements (Drums, Percussion, Bass, Acc 1-5) across Variations 1-4, Fills 1-4, Intros 1-3, Break, and Endings 1-3.
- **High-Precision Style Sequencer** (`StyleSequencer.kt`): PPQN=480 timing engine with nanosecond drift compensation, section quantization, automatic Fill/Break reversion, mute/solo controls, and active-note tracking to prevent stuck notes.
- **Native Multi-Timbral Voice Mapping** (`WorkstationVoicePool.h`): Specialized synthesis parameter profiles per MIDI channel for punchy bass, drums/percussion transients, warm piano chords, guitars, and sustained string pads.
- **UI & Performance Controller Integration** (`PerformanceController.kt`, `WorkstationUi.kt`): Live Start/Stop transport, Synchro Start latching, real-time Bar and Beat counter HUD, tempo adjustment, and section selection buttons.
- **Deterministic Unit Testing** (`StyleSequencerTest.kt`, `NoteTranslationEngineTest.kt`): Comprehensive suites verifying transport, NTT harmony translations, pattern generation, track solo/mute, and transitions with 100% pass rate.

## [Phase 5.0.0] - KORG Pa4X SET Compatibility & Resource Import Architecture
### Added
- KORG Pa4X SET container detector and structure inspector (`SetContainerDetector.kt`) supporting uncompressed `.SET` directories and compressed `.SET.zip` archives with validation and reporting.
- Safe binary chunk parser (`KorgBinaryReader.kt`) with big-endian/little-endian parsing, FourCC chunk slicing, MIDI variable-length quantity decoding, bounds protection, and underflow safety.
- Complete internal representation (IR) models (`SetModels.kt`) for styles, accompaniment tracks, sections, sounds, PCM samples, pads, keyboard sets, and SongBook entries.
- Style parser (`StyleParser.kt`) extracting 8-track arrangements (Drums, Percussion, Bass, ACC1-5), 15 arranger sections (Variations 1-4, Intros 1-3, Fills 1-4, Break, Endings 1-3), and Note Translation Table (NTT) rules (Parallel, Fixed, Bass follow).
- Sound bank parser (`SoundParser.kt`) decoding `.PCG` files into synthesis parameters (filters, envelopes, oscillators) and multisample references.
- PCM audio and multisample parser (`PcmParser.kt`) parsing RIFF WAVE headers, audio specifications, and KORG `.KMP` multisample mappings.
- Auxiliary parsers (`AuxiliaryParsers.kt`) for `.PAD`, Keyboard Sets (`.KST`/`.PRF`), and SongBook entries (`.SBD`).
- General MIDI fallback sound map and role-based fallback resolver (`GmSoundMap.kt`, `SetDependencyResolver.kt`) guaranteeing 100% playable styles even with missing custom user sounds.
- Comprehensive musical and DSP constraint validator (`SetValidator.kt`).
- Asynchronous coroutine repository (`SetRepository.kt`) running on `Dispatchers.IO` with zero heap allocation or blocking I/O on the audio thread.
- Factory Demo Pa4X Reference SET preloaded with 4 authentic styles (Pop Ballad, Latin Groove, Orient Dance, Standard 8-Beat) and full GM orchestration.
- Integration with `PerformanceController.kt` and `WorkstationUi.kt` featuring SET status badge, active style selector, and library controls.
- Comprehensive unit test suite (`Pa4xSetCompatibilityUnitTest.kt`) with 100% passing tests.

## [Phase 4.0.0] - Chord Recognition Engine & Arranger Core State Machine
### Added
- Polyphonic chord detection engine (`ChordRecognizer.kt`) supporting Major, Minor, Dominant 7th, Major 7th, Minor 7th, Diminished, Diminished 7th, Half-Diminished (m7b5), Augmented, Sus4, Sus2, Add9, 6th, and Power chords.
- Inversion-invariant pitch-class set matching with lowest bass note extraction for slash chords (e.g. C/E, G/B, Dm/F).
- EZ One-Finger (Yamaha/Korg style) chord recognition mode with single root and modifier key logic.
- Arranger chord state machine (`ArrangerChordEngine.kt`) supporting keyboard split point management, Lower chord zone vs Upper melody zone routing, and Chord Memory (Hold) latching.
- UI chord display and controls (`WorkstationUi.kt`) in the arranger bar with real-time chord quality, recognition mode selector (Fingered, 1-Finger, Full KB), Split toggle, and Memory toggle.
- Comprehensive unit test suite (`ChordRecognitionUnitTest.kt`) with 10 passing tests verifying all chord qualities, inversions, slash chords, One-Finger logic, split routing, and memory retention.

## [Phase 3.0.0] - Sound Engine Core Implementation
### Added
- Real-time band-limited PolyBLEP multi-waveform oscillator (`BandlimitedOscillator.h`) eliminating aliasing on sawtooth, square, and triangle waves.
- 4-stage ADSR envelope generator (`AdsrEnvelope.h`) with quasi-exponential decay and release curves, click prevention, and zero transcendental calls in render loop.
- 2-pole resonant State-Variable Filter (`StateVariableFilter.h`) with 2x oversampling, low-pass/band-pass/high-pass modes, and soft-clipped integrator state.
- Low-Frequency Oscillator (`LowFrequencyOscillator.h`) for smooth pitch vibrato, filter sweep, and tremolo modulation.
- Dynamic velocity curve mapping (`VelocityMapper.h`) supporting Linear, Soft, Hard, and Fixed velocity profiles.
- Polyphonic dual-oscillator voice pool architecture in `WorkstationVoicePool.h` with analog unison detuning and filter envelope modulation.
- JNI bridge extensions for real-time modulation wheel (`sendModulation`) and DSP parameters (`sendParamChange`).
- Modulation Wheel UI control integrated into keyboard performance strip with touch dragging and visual indicator.
- Unit test coverage verifying velocity response curves, filter frequency bounds, and modulation depth clamping in `WorkstationEngineUnitTest.kt`.

### Real-Time Verification
- Zero heap allocations, zero mutexes, zero JNI calls, and zero filesystem I/O on the real-time audio callback thread (`onAudioReady`).
- Strict bounded complexity maintained with 64-voice polyphony limit and 1.5ms anti-click voice stealing micro-fade.
