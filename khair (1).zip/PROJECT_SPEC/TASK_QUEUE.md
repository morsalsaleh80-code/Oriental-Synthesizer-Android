# Task Queue — Greenfield Arranger Workstation

## Phase 0: Greenfield Foundation & Native Audio Infrastructure (COMPLETE)
- [x] P0.1: Clean-room project verification and baseline compilation.
- [x] P0.2: Set application identity (`metadata.json`, `strings.xml`).
- [x] P0.3: Author all required engineering governance documentation in `PROJECT_SPEC/`.
- [x] P0.4: Configure Gradle with CMake, NDK, and Oboe prefab dependencies.
- [x] P0.5: Implement C++ lock-free SPSC Event Queue (`LockFreeEventQueue.h`).
- [x] P0.6: Implement C++ Voice Pool and deterministic voice allocator (`WorkstationVoicePool.h`).
- [x] P0.7: Implement C++ Oboe / AAudio stream wrapper with low-latency callback (`OboeAudioEngine.h`, `OboeAudioEngine.cpp`).
- [x] P0.8: Implement JNI Bridge layer (`native-bridge.cpp`).
- [x] P0.9: Implement Kotlin Audio Engine wrapper (`NativeAudioBridge.kt`).
- [x] P0.10: Implement Performance Controller and state machine (`PerformanceController.kt`).
- [x] P0.11: Implement Jetpack Compose Workstation UI with diagnostic dashboard & live touch keyboard.
- [x] P0.12: Implement Unit Tests for real-time safe data structures and voice allocation.
- [x] P0.13: Verify compilation and pass all test suites.

## Phase 1: Voice Engine & Sound Synthesis (Next)
- [ ] P1.1: Multi-oscillator synthesis (bandlimited sawtooth, square, pulse-width modulation).
- [ ] P1.2: 4-stage ADSR envelope generator with exponential curves.
- [ ] P1.3: 2-pole and 4-pole resonant state-variable filters (low-pass, band-pass, high-pass).
- [ ] P1.4: LFO modulation routing (Pitch vibrato, Filter wah, Amplitude tremolo).
- [ ] P1.5: Keyboard velocity curve mapping (Soft, Medium, Hard, Fixed).

## Phase 2: Keyboard Engine & Oriental / Microtonal Tuning
- [ ] P2.1: Multi-zone keyboard engine: Lower (Arranger trigger zone), Upper 1, Upper 2, Upper 3.
- [ ] P2.2: Split point configuration with instant latching.
- [ ] P2.3: Microtonal Scale Matrix (12-note chromatic cent offsets, -64 to +63 cents).
- [ ] P2.4: Oriental/Arabic quarter-tone quick toggle buttons (Bayati, Rast, Hijaz, Sikah presets).

## Phase 3: MIDI Engine & USB/BLE Connectivity
- [ ] P3.1: Android USB Host MIDI 1.0 integration with hotplug detection.
- [ ] P3.2: Timestamped MIDI parser (NoteOn, NoteOff, CC, PitchBend, Aftertouch).
- [ ] P3.3: MIDI Clock generator and MIDI Clock sync slave mode.
- [ ] P3.4: BLE MIDI service integration.

## Phase 4: Chord Recognition Engine & Arranger State Machine (COMPLETE)
- [x] P4.1: Polyphonic chord detection (Major, Minor, 7th, Maj7, Min7, Dim, Aug, Sus4, Add9, slash bass chords).
- [x] P4.2: Fingered, One-Finger, and Full-Keyboard chord recognition modes.
- [x] P4.3: Memory / chord hold state machine.

## Phase 5: KORG Pa4X SET Compatibility & Resource Import (COMPLETE)
- [x] P5.1: KORG SET Container Detector & Structure Inspector (.SET folders & zip archives).
- [x] P5.2: Safe Binary Chunk Reader (KorgBinaryReader with endianness, FourCC, VLQ, bounds protection).
- [x] P5.3: Style Parser (.STY container, 8 accompaniment tracks, variations 1-4, intro/fill/ending, NTT rules).
- [x] P5.4: Sound (.PCG) & PCM/Wave (.KMP/.PCM/WAV) Parsers.
- [x] P5.5: Auxiliary Parsers (.PAD, KeyboardSet .KST/.PRF, SongBook .SBD).
- [x] P5.6: Cross-Resource Dependency Resolver & General MIDI Fallback Mapper (GmSoundMap).
- [x] P5.7: Set Validator against workstation real-time musical and DSP constraints.
- [x] P5.8: Asynchronous SetRepository & Factory Demo Pa4X Reference SET.
- [x] P5.9: PerformanceController & WorkstationUi integration (SET manager, style selector, HUD diagnostics).

## Phase 6: Arranger Sequencer & Style Playback Engine (COMPLETE)
- [x] P6.1: KORG Note Translation Engine (NTT) supporting Parallel, Fixed, and Bass-follow voicing modes (`NoteTranslationEngine.kt`).
- [x] P6.2: Authentic 8-track factory style pattern bank across all arranger sections (`FactoryStylePatternGenerator.kt`).
- [x] P6.3: High-precision PPQN=480 drift-compensated arranger sequencer (`StyleSequencer.kt`).
- [x] P6.4: Real-time section switching (Fill/Break auto-return, section quantization, loop boundaries).
- [x] P6.5: Multi-timbral voice assignment per channel (Drums, Percussion, Bass, Acc 1-5 in `WorkstationVoicePool.h`).
- [x] P6.6: Arranger transport integration in `PerformanceController.kt` and `WorkstationUi.kt` (Play/Stop, Synchro Start, Beat/Bar display, section selector).
- [x] P6.7: Unit and integration test verification with 100% pass rate (`StyleSequencerTest.kt`, `NoteTranslationEngineTest.kt`).

## Phase 7: Mixer, DSP & FX
- [ ] P7.1: 8-channel track mixer with stereo pan and volume faders.
- [ ] P7.2: Send FX 1: Stereo ping-pong delay with tempo sync.
- [ ] P7.3: Send FX 2: Algorithmic plate/hall reverb.
- [ ] P7.4: Master 3-band parametric EQ and peak limiter.

## Phase 8: Presets, SongBook & Performance Management
- [ ] P8.1: Performance set storage and retrieval via Coroutines.
- [ ] P8.2: SongBook database indexing styles, sounds, and registrations.
