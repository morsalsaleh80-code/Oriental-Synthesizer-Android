# Threading Model & Concurrency Architecture

## 1. Thread Hierarchy and Roles

```
┌────────────────────────────────────────────────────────┐
│ UI Thread (Android Main Thread)                        │
│ - Jetpack Compose composition and layout               │
│ - User interaction & touch event capture               │
│ - Diagnostic dashboard rendering (60 FPS)              │
└────────────────────────┬───────────────────────────────┘
                         │ State updates via Flow / State
┌────────────────────────▼───────────────────────────────┐
│ Performance Controller Thread (Kotlin Coroutine)       │
│ - Coordinates keyboard splits, layers, and octaves     │
│ - Dispatches user events to Native Event Bus           │
└────────────────────────┬───────────────────────────────┘
                         │ Lock-free SPSC Ring Buffer (C++)
┌────────────────────────▼───────────────────────────────┐
│ Native Audio Thread (AAudio / Oboe Real-Time Thread)   │
│ - Priority: SCHED_FIFO (assigned by Android AudioFlinger)
│ - Zero locks, zero heap allocations, zero JNI callbacks│
│ - Consumes SPSC events and renders audio frames        │
└────────────────────────────────────────────────────────┘
                         ▲
                         │ Atomic pointers / read-only swap
┌────────────────────────┴───────────────────────────────┐
│ Background Worker Threads (Dispatchers.IO / C++ Worker)│
│ - Preset file I/O & sample loading                     │
│ - Style file parsing                                   │
│ - Non-real-time preparation of audio data              │
└────────────────────────────────────────────────────────┘
```

## 2. Ownership of Mutable State
- **Audio Thread State**:
  - Voice active flags, phase accumulators, envelope states, and filter coefficients are exclusively owned and mutated by the audio thread.
  - No external thread ever writes directly to voice variables.
- **Controller / UI State**:
  - MutableStateFlow in ViewModel controls UI display states (selected preset, tempo, volume slider levels).
- **Inter-Thread Bridge**:
  - Control parameters (e.g., Master Volume, Pitch Bend, Tempo) are communicated via atomic variables (`std::atomic<float>`, `std::atomic<int32_t>`) or through timestamped `WorkstationEvent` messages in the SPSC ring buffer.

## 3. Real-Time Audio Priority Guarantees
- Priority inversion is mathematically prevented by eliminating all mutual exclusion locks between the audio thread and any non-audio thread.
- If the SPSC event queue is momentarily empty, the audio thread continues rendering ongoing voices seamlessly.
- If the SPSC queue is full due to abnormal flood, the producer drops or handles the overflow without stalling the audio thread.
