# Professional Android Arranger Workstation — Master Project Specification

## 1. Product Mission & Vision
The **Professional Android Arranger Workstation** is a professional real-time Android musical workstation engineered for serious musicians and live stage performance. It is designed from the ground up as a greenfield, clean-room, low-latency audio workstation.

This application is **NOT a toy keyboard application**. It provides deterministic real-time audio generation, professional keyboard split/layer management, style-driven accompaniment with synchronized chord tracking, multi-zone sample playback, microtonal/oriental scale tuning, and studio-grade DSP/mixing.

## 2. Core Architectural Principles
1. **Clean-Room Engineering**:
   - Zero copying of proprietary source code, firmware, ROMs, or copyrighted artwork/assets.
   - Independent implementation of all arranger, style, chord recognition, and voice allocation logic.
2. **Hard Real-Time Audio Guarantees**:
   - The audio rendering callback runs under AAudio / Oboe at highest real-time priority (`AAUDIO_PERFORMANCE_MODE_LOW_LATENCY`).
   - The audio callback must **NEVER** allocate heap memory, execute blocking locks, perform disk/network I/O, execute JNI calls back into JVM, or run unbounded loops.
   - Non-real-time operations (file loading, UI rendering, style parsing, preset management) run exclusively on background worker threads.
3. **Deterministic State & Lock-Free Inter-Thread Communication**:
   - Single-Producer Single-Consumer (SPSC) lock-free ring buffers transfer timestamped events (Note On/Off, Control Change, Arranger triggers) from the controller thread to the native audio engine.
   - Atomic state publication and immutable configuration snapshots prevent data races without priority inversion.

## 3. High-Level Subsystem Breakdown
1. **Presentation / UI Layer (Jetpack Compose & M3)**:
   - Workstation-style dark-mode interface optimized for stage performance.
   - Multi-touch velocity-sensitive on-screen keyboard with split & layer indicators.
   - Arranger control panel: Variation 1-4, Intro 1-3, Fill 1-4, Break, Ending 1-3, Synchro Start/Stop, Tempo tap/wheel.
   - Real-time diagnostic monitors (buffer underrun counters, callback latency, CPU load, active voice count).
2. **Performance Controller & Event Bus**:
   - Central coordination layer mediating between UI events, physical USB/BLE MIDI inputs, and the sound engine.
   - High-resolution timestamping of events.
3. **Arranger & Style Engine**:
   - Real-time chord recognizer with root detection, chord quality, and slash chords.
   - Style pattern playback synchronized to bar and beat boundaries.
   - NTT (Note Translation Table) and chord-transposition rule system.
   - Multi-track accompaniment: Drums, Percussion, Bass, ACC1, ACC2, ACC3, ACC4, ACC5.
4. **Voice & Sampler Engine**:
   - Polyphonic synthesizer and multisample player.
   - Key zone mapping, velocity layers, root key tracking, preloaded sample buffers.
   - Deterministic voice allocator with musical voice stealing (oldest quietest note releasing).
   - Per-voice envelopes (ADSR), low-pass resonant biquad filters, and LFO modulators.
5. **Mixer, DSP & FX**:
   - 8-bus / multi-channel mixer with per-channel gain, pan, EQ, and effects send.
   - Real-time stereo delay, chorus, and algorithmic reverb.
6. **Native Audio Engine (C++ / Oboe / AAudio)**:
   - High-performance C++20 audio rendering pipeline.
   - SPSC ring buffer for real-time safe MIDI event ingestion.
   - Low-latency stream configuration via Google Oboe.
7. **Microtonal & Oriental Tuning Engine**:
   - 12-TET equal temperament baseline.
   - Quarter-tone / Maqam tuning matrix with per-note cent offsets (-64 to +63 cents).
   - Real-time scale switching without voice disruption.

## 4. Phased Development Roadmap
- **Phase 0 (Today)**: Greenfield foundation, CMake & C++ toolchain, Oboe/AAudio native audio engine, SPSC lock-free event queue, real-time audio callback, diagnostics & test harness, and architectural documentation.
- **Phase 1**: Voice Engine foundation, band-limited oscillators, ADSR envelopes, resonant filters, polyphonic voice allocator with voice stealing.
- **Phase 2**: Keyboard Engine (Splits, Layers, Lower/Upper 1-3), Pitch bend, Mod wheel, and Microtonal/Arabic quarter-tone matrix.
- **Phase 3**: MIDI Engine (USB MIDI 1.0/2.0 integration, BLE MIDI, high-resolution internal routing).
- **Phase 4**: Chord Recognition Engine & Arranger Core state machine.
- **Phase 5**: Style Engine (8-track accompaniment, Bar/Beat clock, Variation/Fill/Break transitions).
- **Phase 6**: Multisample Engine & Soundbank loader.
- **Phase 7**: Mixer, DSP & FX (Stereo Delay, Algorithmic Reverb, 3-Band EQ).
- **Phase 8**: Performance presets, SongBook, and persistence.
