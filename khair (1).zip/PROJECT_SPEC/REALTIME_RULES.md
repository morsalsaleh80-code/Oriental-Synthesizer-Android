# Real-Time Audio Rules & Safety Architecture

## 1. The Audio Callback Boundary
On Android, professional audio requires Oboe or direct AAudio with:
- `AudioStreamBuilder::setPerformanceMode(PerformanceMode::LowLatency)`
- `AudioStreamBuilder::setSharingMode(SharingMode::Exclusive)`
- Real-time priority audio thread assigned by Android's audio server (`SCHED_FIFO` or `SCHED_RESET_ON_FORK`).

To maintain priority and prevent underruns (xruns):
The OS audio thread must never be descheduled or block on any resource owned by a non-real-time thread.

## 2. Forbidden Operations inside Audio Render Path
| Forbidden Operation | Why It Causes Audio Glitches / Xruns | Safe Alternative |
|---|---|---|
| `malloc()`, `free()`, `new`, `delete` | Kernel heap lock contention, memory defragmentation delays | Pre-allocate fixed-capacity voice pools and sample buffers at engine startup. |
| `std::mutex`, `pthread_mutex_lock` | Priority inversion: a low-priority UI thread holding the lock blocks the audio thread | Lock-free Single-Producer Single-Consumer (SPSC) ring buffers and atomic variables (`std::atomic`). |
| File I/O (`fread`, `open`, `mmap`) | Disk latency spikes of 5–100ms exceed buffer deadlines (<2.5ms) | Asynchronous background streaming to pre-allocated ring buffers. |
| Network / Socket operations | Unpredictable network latency and thread blocking | Background networking thread pushes to disk cache; audio thread reads memory. |
| JNI / Callbacks to Kotlin/Java | JVM garbage collection pauses and JNI invocation overhead | Lock-free polling of native atomic state from Kotlin via dedicated polling loop or coroutine. |
| Console logging (`std::cout`, `__android_log_print`) | `vsnprintf` formatting and blocking IPC to `logd` | Write metrics to atomic counters/ring buffer; UI/worker thread drains and logs. |

## 3. Communication Patterns

### Downstream (Control -> Audio Thread)
- **Control Thread (Producer)**: UI event handler or MIDI dispatcher creates timestamped `WorkstationEvent` struct.
- **Queue**: Lock-free SPSC circular queue with atomic head/tail pointers using `std::memory_order_acquire` and `std::memory_order_release`.
- **Audio Thread (Consumer)**: Drains pending events at the start of each `onAudioReady` slice and renders corresponding voice state.

### Upstream (Audio Thread -> UI/Control Thread)
- **Audio Thread (Producer)**: Updates `std::atomic<float>` audio peak meters, `std::atomic<uint32_t>` xrun counters, and voice usage metrics.
- **UI / Diagnostic Thread (Consumer)**: Samples the atomic variables at 30–60 FPS to drive Compose UI gauges.

## 4. Voice Allocation Determinism
- Fixed polyphony pool of 64 or 128 voices allocated during initialization.
- Fast O(1) index-based free list or linear scan over small fixed array without vector resizing.
- Voice stealing algorithm calculates priority score = `(velocity * envelope_amplitude) + age_factor` in bounded constant time.
