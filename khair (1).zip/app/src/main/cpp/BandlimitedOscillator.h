#pragma once

#include <cmath>
#include <algorithm>

namespace workstation {

enum class OscillatorWaveform : uint8_t {
    SINE = 0,
    SAWTOOTH = 1,
    SQUARE = 2,
    TRIANGLE = 3
};

constexpr float TWO_PI = 6.28318530717958647692f;

// Bandlimited PolyBLEP Oscillator
// Implements Polynomial Band-Limited Step (PolyBLEP) to eliminate nyquist aliasing
// on Sawtooth, Square, and Triangle waveforms in real-time with zero table memory overhead.
class BandlimitedOscillator {
public:
    BandlimitedOscillator() = default;

    void setSampleRate(float sampleRate) noexcept {
        sampleRate_ = (sampleRate > 8000.0f) ? sampleRate : 48000.0f;
    }

    void setFrequency(float freqHz) noexcept {
        freqHz_ = std::clamp(freqHz, 5.0f, sampleRate_ * 0.48f);
        phaseIncrement_ = freqHz_ / sampleRate_; // normalized [0.0, 1.0)
    }

    void setWaveform(OscillatorWaveform waveform) noexcept {
        waveform_ = waveform;
    }

    void setPulseWidth(float pw) noexcept {
        pulseWidth_ = std::clamp(pw, 0.05f, 0.95f);
    }

    void reset() noexcept {
        phase_ = 0.0f;
    }

    // Process single sample - O(1), zero branching loops, zero allocations
    inline float process() noexcept {
        float sample = 0.0f;
        const float t = phase_;
        const float dt = phaseIncrement_;

        switch (waveform_) {
            case OscillatorWaveform::SINE: {
                // High precision approximation or Taylor series:
                // Fast sine approximation using normalized phase [0, 1)
                float p = t - 0.5f; // [-0.5, 0.5]
                // 4x(1 - 2|p|) parabolic sine approx:
                sample = 4.0f * (p * (1.0f - 2.0f * std::abs(p)) * 4.0f);
                break;
            }

            case OscillatorWaveform::SAWTOOTH: {
                // Raw naive sawtooth: 2 * t - 1
                sample = (2.0f * t) - 1.0f;
                // Subtract polyBLEP residual at transition (t = 0)
                sample -= polyBlep(t, dt);
                break;
            }

            case OscillatorWaveform::SQUARE: {
                // Raw square
                sample = (t < pulseWidth_) ? 1.0f : -1.0f;
                // PolyBLEP at rising edge (t = 0) and falling edge (t = pulseWidth_)
                sample += polyBlep(t, dt);
                sample -= polyBlep(std::fmod(t + (1.0f - pulseWidth_), 1.0f), dt);
                break;
            }

            case OscillatorWaveform::TRIANGLE: {
                // Integrated square or 2-segment line with BLEP
                float naive = (t < 0.5f) ? (4.0f * t - 1.0f) : (3.0f - 4.0f * t);
                sample = naive;
                break;
            }
        }

        // Advance phase
        phase_ += phaseIncrement_;
        if (phase_ >= 1.0f) {
            phase_ -= 1.0f;
        }

        return sample;
    }

    [[nodiscard]] inline float getPhase() const noexcept {
        return phase_;
    }

private:
    // PolyBLEP residual function: applies 2nd order polynomial smoothing near discontinuities
    static inline float polyBlep(float t, float dt) noexcept {
        if (dt <= 0.0f) return 0.0f;
        // 0 <= t < dt (just after discontinuity)
        if (t < dt) {
            const float ratio = t / dt;
            return ratio + ratio - ratio * ratio - 1.0f;
        }
        // 1 - dt < t <= 1 (just before discontinuity)
        if (t > 1.0f - dt) {
            const float ratio = (t - 1.0f) / dt;
            return ratio * ratio + ratio + ratio + 1.0f;
        }
        return 0.0f;
    }

    float sampleRate_{48000.0f};
    float freqHz_{440.0f};
    float phaseIncrement_{0.009166f};
    float phase_{0.0f};
    float pulseWidth_{0.5f};
    OscillatorWaveform waveform_{OscillatorWaveform::SAWTOOTH};
};

} // namespace workstation
