#pragma once

#include <memory>
#include <oboe/Oboe.h>
#include "LockFreeEventQueue.h"
#include "WorkstationVoicePool.h"
#include "AudioDiagnostics.h"

namespace workstation {

class OboeAudioEngine : public oboe::AudioStreamDataCallback, public oboe::AudioStreamErrorCallback {
public:
    OboeAudioEngine();
    ~OboeAudioEngine() override;

    // Stream lifecycle (called from Kotlin/JNI thread)
    bool start();
    void stop();
    void restart();

    // Event submission (called from UI / MIDI / Controller thread - LOCK FREE)
    bool pushEvent(const WorkstationEvent& event) noexcept;

    // Master controls
    void setMasterVolume(float volume) noexcept;
    void setPitchBend(float bendSemitones) noexcept;

    // PCM Sample Management (called off audio callback thread)
    bool loadPcmSample(
        int32_t slot,
        int32_t sampleRate,
        int32_t channels,
        int32_t rootKey,
        int32_t fineTuneCents,
        int32_t loopStart,
        int32_t loopEnd,
        bool isLooped,
        const float* data,
        int32_t totalFrames
    ) noexcept {
        return voicePool_.loadPcmSample(slot, sampleRate, channels, rootKey, fineTuneCents, loopStart, loopEnd, isLooped, data, totalFrames);
    }

    void clearPcmSamples() noexcept {
        voicePool_.clearPcmSamples();
    }

    bool isPcmSampleLoaded(int32_t slot) const noexcept {
        return voicePool_.isPcmSampleLoaded(slot);
    }

    void setActivePcmSlot(int32_t slot) noexcept {
        voicePool_.setActivePcmSlot(slot);
    }

    int32_t getActivePcmSlot() const noexcept {
        return voicePool_.getActivePcmSlot();
    }

    // Non-blocking telemetry metrics (safe to call on non-realtime JNI thread)
    int32_t updateAndGetXRunCount() noexcept;
    float updateAndGetHardwareLatencyMs() noexcept;

    // Telemetry & diagnostics
    AudioDiagnostics& getDiagnostics() noexcept { return diagnostics_; }

    // Oboe AudioStreamDataCallback
    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* audioStream,
        void* audioData,
        int32_t numFrames) override;

    // Oboe AudioStreamErrorCallback
    void onErrorAfterClose(oboe::AudioStream* audioStream, oboe::Result error) override;

private:
    std::shared_ptr<oboe::AudioStream> stream_{nullptr};
    LockFreeEventQueue<4096> eventQueue_{};
    WorkstationVoicePool voicePool_{};
    AudioDiagnostics diagnostics_{};
    std::atomic<bool> isRunning_{false};
    std::array<float, 2048> scratchFloatBuffer_{};
};

} // namespace workstation
