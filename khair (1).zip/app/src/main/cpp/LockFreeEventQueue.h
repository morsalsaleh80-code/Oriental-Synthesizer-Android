#pragma once

#include <cstdint>
#include <atomic>
#include <array>
#include <cstddef>

namespace workstation {

enum class EventType : uint8_t {
    NOTE_ON = 1,
    NOTE_OFF = 2,
    ALL_NOTES_OFF = 3,
    PITCH_BEND = 4,
    MODULATION = 5,
    SUSTAIN_PEDAL = 6,
    MASTER_VOLUME = 7,
    PAN_CHANGE = 8,
    PARAM_CHANGE = 9
};

struct alignas(16) WorkstationEvent {
    int64_t timestampNs{0};
    EventType type{EventType::NOTE_ON};
    uint8_t channel{0};
    uint8_t data1{0}; // Note number or CC number
    uint8_t data2{0}; // Velocity or CC value
    float floatValue{0.0f}; // Microtonal cent offset, pitch bend (-1.0 to 1.0), or normalized param
};

// Single-Producer Single-Consumer (SPSC) Lock-Free Circular Ring Buffer
// Capacity must be power of 2
template <size_t Capacity = 4096>
class LockFreeEventQueue {
    static_assert((Capacity & (Capacity - 1)) == 0, "Capacity must be a power of 2");

public:
    LockFreeEventQueue() : head_(0), tail_(0) {}

    // Producer (Kotlin / JNI / UI / MIDI Thread)
    // Returns true if successfully pushed, false if queue full (no blocking)
    bool push(const WorkstationEvent& event) noexcept {
        const size_t currentTail = tail_.load(std::memory_order_relaxed);
        const size_t currentHead = head_.load(std::memory_order_acquire);

        if ((currentTail - currentHead) >= Capacity) {
            // Queue full — drop event rather than blocking real-time thread
            return false;
        }

        buffer_[currentTail & (Capacity - 1)] = event;
        tail_.store(currentTail + 1, std::memory_order_release);
        return true;
    }

    // Consumer (Audio Callback Thread ONLY)
    // Returns true if item popped, false if queue empty
    bool pop(WorkstationEvent& event) noexcept {
        const size_t currentHead = head_.load(std::memory_order_relaxed);
        const size_t currentTail = tail_.load(std::memory_order_acquire);

        if (currentHead == currentTail) {
            // Empty
            return false;
        }

        event = buffer_[currentHead & (Capacity - 1)];
        head_.store(currentHead + 1, std::memory_order_release);
        return true;
    }

    [[nodiscard]] size_t size() const noexcept {
        const size_t currentTail = tail_.load(std::memory_order_relaxed);
        const size_t currentHead = head_.load(std::memory_order_relaxed);
        return (currentTail >= currentHead) ? (currentTail - currentHead) : 0;
    }

    [[nodiscard]] bool empty() const noexcept {
        return head_.load(std::memory_order_relaxed) == tail_.load(std::memory_order_relaxed);
    }

private:
    alignas(64) std::atomic<size_t> head_{0};
    alignas(64) std::atomic<size_t> tail_{0};
    std::array<WorkstationEvent, Capacity> buffer_{};
};

} // namespace workstation
