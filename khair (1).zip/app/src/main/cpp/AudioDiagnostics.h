#pragma once

#include <atomic>
#include <cstdint>

namespace workstation {

struct AudioDiagnostics {
    std::atomic<uint32_t> xrunCount{0};
    std::atomic<float> cpuLoad{0.0f};             // 0.0 to 1.0 (ratio of callback time to buffer duration)
    std::atomic<uint32_t> activeVoices{0};
    std::atomic<int32_t> bufferFrames{0};
    std::atomic<int32_t> sampleRate{48000};
    std::atomic<float> peakMeterL{0.0f};          // Linear amplitude 0.0 to 1.0
    std::atomic<float> peakMeterR{0.0f};          // Linear amplitude 0.0 to 1.0
    std::atomic<int64_t> lastCallbackDurationNs{0};
    std::atomic<uint64_t> totalFramesRendered{0};
    std::atomic<float> hardwareLatencyMs{0.0f};   // Hardware output latency in milliseconds

    void reset() noexcept {
        xrunCount.store(0, std::memory_order_relaxed);
        cpuLoad.store(0.0f, std::memory_order_relaxed);
        activeVoices.store(0, std::memory_order_relaxed);
        peakMeterL.store(0.0f, std::memory_order_relaxed);
        peakMeterR.store(0.0f, std::memory_order_relaxed);
        lastCallbackDurationNs.store(0, std::memory_order_relaxed);
        totalFramesRendered.store(0, std::memory_order_relaxed);
        hardwareLatencyMs.store(0.0f, std::memory_order_relaxed);
    }
};

} // namespace workstation
