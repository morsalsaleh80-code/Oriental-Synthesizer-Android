#pragma once

#include <cmath>
#include <algorithm>

namespace workstation {

enum class FilterType : uint8_t {
    LOW_PASS = 0,
    BAND_PASS = 1,
    HIGH_PASS = 2,
    BYPASS = 3
};

// 2-pole Resonant State-Variable Filter (SVF, Chamberlin / Hal Chamberlin digital model)
// Extremely stable, non-saturating, continuous resonance and cutoff tuning, 0 heap allocations
class StateVariableFilter {
public:
    StateVariableFilter() = default;

    void setSampleRate(float sampleRate) noexcept {
        sampleRate_ = (sampleRate > 8000.0f) ? sampleRate : 48000.0f;
        updateCoefficients();
    }

    void setCutoffAndResonance(float cutoffHz, float resonance) noexcept {
        cutoffHz_ = std::clamp(cutoffHz, 20.0f, sampleRate_ * 0.45f);
        // Resonance Q factor: 0.0 (damped) to 0.98 (high resonance without unstable self-oscillation)
        resonance_ = std::clamp(resonance, 0.0f, 0.98f);
        updateCoefficients();
    }

    void setType(FilterType type) noexcept {
        type_ = type;
    }

    void reset() noexcept {
        low_ = 0.0f;
        high_ = 0.0f;
        band_ = 0.0f;
        notch_ = 0.0f;
    }

    // Process single sample - O(1), zero trigonometry in loop, zero allocations
    inline float process(float input) noexcept {
        if (type_ == FilterType::BYPASS) {
            return input;
        }

        // 2x oversampled / double integration step for stability across full audio spectrum
        // First pass
        low_ += f_ * band_;
        high_ = input - low_ - q_ * band_;
        band_ += f_ * high_;
        notch_ = high_ + low_;

        // Second pass
        low_ += f_ * band_;
        high_ = input - low_ - q_ * band_;
        band_ += f_ * high_;

        // Soft clip the internal integrator state to prevent blow-ups at high resonance
        if (low_ > 3.0f) low_ = 3.0f; else if (low_ < -3.0f) low_ = -3.0f;
        if (band_ > 3.0f) band_ = 3.0f; else if (band_ < -3.0f) band_ = -3.0f;

        switch (type_) {
            case FilterType::LOW_PASS:
                return low_;
            case FilterType::BAND_PASS:
                return band_;
            case FilterType::HIGH_PASS:
                return high_;
            default:
                return input;
        }
    }

private:
    void updateCoefficients() noexcept {
        // f = 2 * sin(pi * cutoff / fs)
        // For fast stability: approximate sin(x) ~ x for small values, or std::sin during param update
        const float w = 3.14159265358979323846f * (cutoffHz_ / sampleRate_);
        f_ = 2.0f * std::sin(w);
        // Damping factor q = 1 - resonance (q in (0.02, 1.0))
        q_ = 1.0f - resonance_;
    }

    float sampleRate_{48000.0f};
    float cutoffHz_{2000.0f};
    float resonance_{0.2f};
    FilterType type_{FilterType::LOW_PASS};

    float f_{0.25f};
    float q_{0.8f};

    float low_{0.0f};
    float high_{0.0f};
    float band_{0.0f};
    float notch_{0.0f};
};

} // namespace workstation
