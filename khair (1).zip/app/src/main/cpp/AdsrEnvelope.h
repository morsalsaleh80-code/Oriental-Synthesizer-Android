#pragma once

#include <cstdint>
#include <cmath>
#include <algorithm>

namespace workstation {

enum class AdsrState : uint8_t {
    IDLE = 0,
    ATTACK = 1,
    DECAY = 2,
    SUNDOWN = 3, // Sustain stage
    RELEASE = 4
};

// 4-stage ADSR Envelope Generator with exponential decay/release curves
// Pre-computed per-sample coefficients for zero transcendental math in render loop
class AdsrEnvelope {
public:
    AdsrEnvelope() = default;

    void setSampleRate(float sampleRate) noexcept {
        sampleRate_ = (sampleRate > 8000.0f) ? sampleRate : 48000.0f;
        recalculateCoefficients();
    }

    void setParameters(float attackSec, float decaySec, float sustainLevel, float releaseSec) noexcept {
        attackSec_ = std::max(0.0005f, attackSec);   // Min 0.5ms to avoid click
        decaySec_ = std::max(0.001f, decaySec);
        sustainLevel_ = std::clamp(sustainLevel, 0.0f, 1.0f);
        releaseSec_ = std::max(0.001f, releaseSec);
        recalculateCoefficients();
    }

    void gateOn() noexcept {
        state_ = AdsrState::ATTACK;
        targetLevel_ = 1.0f;
    }

    void gateOff() noexcept {
        if (state_ != AdsrState::IDLE) {
            state_ = AdsrState::RELEASE;
            targetLevel_ = 0.0f;
        }
    }

    void reset() noexcept {
        state_ = AdsrState::IDLE;
        currentLevel_ = 0.0f;
        targetLevel_ = 0.0f;
    }

    // Single sample step - O(1), zero branching loops, zero allocations
    inline float process() noexcept {
        switch (state_) {
            case AdsrState::IDLE:
                currentLevel_ = 0.0f;
                break;

            case AdsrState::ATTACK:
                currentLevel_ += attackCoeff_;
                if (currentLevel_ >= 1.0f) {
                    currentLevel_ = 1.0f;
                    state_ = AdsrState::DECAY;
                    targetLevel_ = sustainLevel_;
                }
                break;

            case AdsrState::DECAY:
                currentLevel_ -= decayCoeff_ * (currentLevel_ - sustainLevel_ + 0.01f);
                if (currentLevel_ <= sustainLevel_) {
                    currentLevel_ = sustainLevel_;
                    state_ = AdsrState::SUNDOWN;
                }
                break;

            case AdsrState::SUNDOWN:
                currentLevel_ = sustainLevel_;
                break;

            case AdsrState::RELEASE:
                currentLevel_ -= releaseCoeff_ * (currentLevel_ + 0.005f);
                if (currentLevel_ <= 0.0001f) {
                    currentLevel_ = 0.0f;
                    state_ = AdsrState::IDLE;
                }
                break;
        }
        return currentLevel_;
    }

    [[nodiscard]] inline bool isIdle() const noexcept {
        return state_ == AdsrState::IDLE;
    }

    [[nodiscard]] inline bool isInRelease() const noexcept {
        return state_ == AdsrState::RELEASE;
    }

    [[nodiscard]] inline float getCurrentLevel() const noexcept {
        return currentLevel_;
    }

    [[nodiscard]] inline AdsrState getState() const noexcept {
        return state_;
    }

private:
    void recalculateCoefficients() noexcept {
        // Linear attack increment
        attackCoeff_ = 1.0f / (attackSec_ * sampleRate_);
        // Quasi-exponential decay step factor
        decayCoeff_ = 1.0f / (decaySec_ * sampleRate_ * 0.4f);
        // Quasi-exponential release step factor
        releaseCoeff_ = 1.0f / (releaseSec_ * sampleRate_ * 0.35f);
    }

    float sampleRate_{48000.0f};
    float attackSec_{0.005f};    // 5ms default
    float decaySec_{0.35f};      // 350ms default
    float sustainLevel_{0.7f};   // 70% sustain default
    float releaseSec_{0.25f};    // 250ms default

    float attackCoeff_{0.00416f};
    float decayCoeff_{0.00014f};
    float releaseCoeff_{0.00023f};

    float currentLevel_{0.0f};
    float targetLevel_{0.0f};
    AdsrState state_{AdsrState::IDLE};
};

} // namespace workstation
