#include <jni.h>
#include <memory>
#include <chrono>
#include <mutex>
#include <atomic>
#include "OboeAudioEngine.h"

// 8-State Native Lifecycle State Machine Representation (0: UNINITIALIZED, 1: INITIALIZED, 2: RUNNING, 3: STOPPED)
enum class EngineState : int32_t {
    UNINITIALIZED = 0,
    INITIALIZED = 1,
    RUNNING = 2,
    STOPPED = 3
};

static std::shared_ptr<workstation::OboeAudioEngine> gAudioEngine{nullptr};
static std::mutex gLifecycleMutex;
static std::atomic<int32_t> gEngineState{static_cast<int32_t>(EngineState::UNINITIALIZED)};

static int64_t getCurrentTimeNs() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_initEngine(JNIEnv* /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(gLifecycleMutex);
    if (!gAudioEngine) {
        gAudioEngine = std::make_shared<workstation::OboeAudioEngine>();
        gEngineState.store(static_cast<int32_t>(EngineState::INITIALIZED), std::memory_order_release);
    }
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_destroyEngine(JNIEnv* /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(gLifecycleMutex);
    gEngineState.store(static_cast<int32_t>(EngineState::UNINITIALIZED), std::memory_order_release);
    if (gAudioEngine) {
        gAudioEngine->stop();
        gAudioEngine.reset();
    }
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_startEngine(JNIEnv* /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(gLifecycleMutex);
    if (gAudioEngine) {
        bool started = gAudioEngine->start();
        if (started) {
            gEngineState.store(static_cast<int32_t>(EngineState::RUNNING), std::memory_order_release);
            return JNI_TRUE;
        }
    }
    return JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_stopEngine(JNIEnv* /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(gLifecycleMutex);
    if (gAudioEngine) {
        gAudioEngine->stop();
        gEngineState.store(static_cast<int32_t>(EngineState::STOPPED), std::memory_order_release);
    }
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendNoteOn(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jint note, jint velocity, jint channel, jfloat centOffset) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::NOTE_ON;
    ev.channel = static_cast<uint8_t>(channel);
    ev.data1 = static_cast<uint8_t>(note);
    ev.data2 = static_cast<uint8_t>(velocity);
    ev.floatValue = static_cast<float>(centOffset);

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendNoteOff(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jint note, jint channel) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::NOTE_OFF;
    ev.channel = static_cast<uint8_t>(channel);
    ev.data1 = static_cast<uint8_t>(note);
    ev.data2 = 0;
    ev.floatValue = 0.0f;

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendPitchBend(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jfloat bendSemitones) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::PITCH_BEND;
    ev.channel = 0;
    ev.data1 = 0;
    ev.data2 = 0;
    ev.floatValue = static_cast<float>(bendSemitones);

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendAllNotesOff(
    JNIEnv* /*env*/, jobject /*thiz*/) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::ALL_NOTES_OFF;
    ev.channel = 0;
    ev.data1 = 0;
    ev.data2 = 0;
    ev.floatValue = 0.0f;

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendModulation(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jfloat modValue) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::MODULATION;
    ev.channel = 0;
    ev.data1 = 1; // CC1 (Modulation Wheel)
    ev.data2 = static_cast<uint8_t>(std::clamp(modValue * 127.0f, 0.0f, 127.0f));
    ev.floatValue = static_cast<float>(modValue);

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_sendParamChange(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jint paramId, jint paramValueInt, jfloat paramValueFloat) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        if (gEngineState.load(std::memory_order_acquire) != static_cast<int32_t>(EngineState::RUNNING)) {
            return JNI_FALSE;
        }
        engine = gAudioEngine;
    }

    if (!engine) {
        return JNI_FALSE;
    }

    workstation::WorkstationEvent ev;
    ev.timestampNs = getCurrentTimeNs();
    ev.type = workstation::EventType::PARAM_CHANGE;
    ev.channel = 0;
    ev.data1 = static_cast<uint8_t>(paramId);
    ev.data2 = static_cast<uint8_t>(paramValueInt);
    ev.floatValue = static_cast<float>(paramValueFloat);

    return static_cast<jboolean>(engine->pushEvent(ev));
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_setMasterVolume(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jfloat volume) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (engine) {
        engine->setMasterVolume(static_cast<float>(volume));
    }
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_getDiagnostics(
    JNIEnv* env, jobject /*thiz*/,
    jfloatArray outArray) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (!engine || !outArray) return;

    // Safely update Oboe driver telemetry from the host/JNI thread (completely outside of real-time audio callback!)
    float xruns = static_cast<float>(engine->updateAndGetXRunCount());
    float latency = engine->updateAndGetHardwareLatencyMs();

    jfloat buf[9];
    auto& d = engine->getDiagnostics();
    buf[0] = xruns;
    buf[1] = static_cast<jfloat>(d.cpuLoad.load(std::memory_order_relaxed));
    buf[2] = static_cast<jfloat>(d.activeVoices.load(std::memory_order_relaxed));
    buf[3] = static_cast<jfloat>(d.bufferFrames.load(std::memory_order_relaxed));
    buf[4] = static_cast<jfloat>(d.sampleRate.load(std::memory_order_relaxed));
    buf[5] = static_cast<jfloat>(d.peakMeterL.load(std::memory_order_relaxed));
    buf[6] = static_cast<jfloat>(d.peakMeterR.load(std::memory_order_relaxed));
    buf[7] = static_cast<jfloat>(d.lastCallbackDurationNs.load(std::memory_order_relaxed));
    buf[8] = latency;

    env->SetFloatArrayRegion(outArray, 0, 9, buf);
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_loadPcmSample16(
    JNIEnv* env, jobject /*thiz*/,
    jint slot,
    jint sampleRate,
    jint channels,
    jint rootKey,
    jint fineTuneCents,
    jint loopStart,
    jint loopEnd,
    jboolean isLooped,
    jbyteArray pcmBytes) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (!engine || !pcmBytes) {
        return JNI_FALSE;
    }

    const jsize byteCount = env->GetArrayLength(pcmBytes);
    const int32_t numChannels = (channels == 2) ? 2 : 1;
    const int32_t bytesPerFrame = 2 * numChannels;
    if (byteCount < bytesPerFrame) {
        return JNI_FALSE;
    }

    const int32_t totalFrames = byteCount / bytesPerFrame;
    std::vector<float> floatData;
    floatData.resize(totalFrames * numChannels);

    jbyte* rawBytes = env->GetByteArrayElements(pcmBytes, nullptr);
    if (!rawBytes) {
        return JNI_FALSE;
    }

    for (int32_t i = 0; i < totalFrames * numChannels; ++i) {
        const int32_t byteIdx = i * 2;
        const int16_t sample16 = static_cast<int16_t>(
            (static_cast<uint8_t>(rawBytes[byteIdx + 1]) << 8) | 
            static_cast<uint8_t>(rawBytes[byteIdx])
        );
        floatData[i] = static_cast<float>(sample16) / 32768.0f;
    }

    env->ReleaseByteArrayElements(pcmBytes, rawBytes, JNI_ABORT);

    bool ok = engine->loadPcmSample(
        slot, sampleRate, numChannels, rootKey, fineTuneCents,
        loopStart, loopEnd, isLooped == JNI_TRUE,
        floatData.data(), totalFrames
    );
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_loadPcmSampleFloat(
    JNIEnv* env, jobject /*thiz*/,
    jint slot,
    jint sampleRate,
    jint channels,
    jint rootKey,
    jint fineTuneCents,
    jint loopStart,
    jint loopEnd,
    jboolean isLooped,
    jfloatArray sampleFloats) {

    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (!engine || !sampleFloats) {
        return JNI_FALSE;
    }

    const jsize floatCount = env->GetArrayLength(sampleFloats);
    const int32_t numChannels = (channels == 2) ? 2 : 1;
    const int32_t totalFrames = floatCount / numChannels;
    if (totalFrames <= 0) return JNI_FALSE;

    jfloat* floats = env->GetFloatArrayElements(sampleFloats, nullptr);
    if (!floats) return JNI_FALSE;

    bool ok = engine->loadPcmSample(
        slot, sampleRate, numChannels, rootKey, fineTuneCents,
        loopStart, loopEnd, isLooped == JNI_TRUE,
        floats, totalFrames
    );

    env->ReleaseFloatArrayElements(sampleFloats, floats, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_clearPcmSamples(JNIEnv* /*env*/, jobject /*thiz*/) {
    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (engine) engine->clearPcmSamples();
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeAudioBridge_isPcmSampleLoaded(JNIEnv* /*env*/, jobject /*thiz*/, jint slot) {
    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    return (engine && engine->isPcmSampleLoaded(slot)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeAudioBridge_setActivePcmSlot(JNIEnv* /*env*/, jobject /*thiz*/, jint slot) {
    std::shared_ptr<workstation::OboeAudioEngine> engine;
    {
        std::lock_guard<std::mutex> lock(gLifecycleMutex);
        engine = gAudioEngine;
    }
    if (engine) engine->setActivePcmSlot(slot);
}

} // extern "C"
