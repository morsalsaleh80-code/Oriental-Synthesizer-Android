#pragma once

#include <cstdint>
#include <algorithm>

namespace workstation {

enum class VelocityCurveType : uint8_t {
    LINEAR = 0,
    SOFT = 1,     // Easier to reach higher velocities
    HARD = 2,     // Requires heavier strike to reach higher velocities
    FIXED = 3     // Always constant (100) for organ/synth
};

class VelocityMapper {
public:
    static inline float mapVelocity(uint8_t midiVelocity, VelocityCurveType curve) noexcept {
        if (midiVelocity == 0) return 0.0f;
        const float v = std::clamp(static_cast<float>(midiVelocity) / 127.0f, 0.0f, 1.0f);

        switch (curve) {
            case VelocityCurveType::LINEAR:
                return v;
            case VelocityCurveType::SOFT:
                // Sqrt or convex response: v^(0.6)
                // Approximated quickly with polynomial: 1.5v - 0.5v^2
                return std::clamp(1.5f * v - 0.5f * v * v, 0.0f, 1.0f);
            case VelocityCurveType::HARD:
                // Concave response: v^2
                return v * v;
            case VelocityCurveType::FIXED:
                return 100.0f / 127.0f;
            default:
                return v;
        }
    }
};

} // namespace workstation
