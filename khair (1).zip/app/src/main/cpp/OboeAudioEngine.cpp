#include "OboeAudioEngine.h"
#include <android/log.h>
#include <time.h>

#define TAG "WorkstationNativeAudio"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace workstation {

OboeAudioEngine::OboeAudioEngine() = default;

OboeAudioEngine::~OboeAudioEngine() {
    stop();
}

bool OboeAudioEngine::start() {
    if (isRunning_.load(std::memory_order_relaxed)) {
        return true;
    }

    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
           ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
           ->setSharingMode(oboe::SharingMode::Shared)
           ->setFormat(oboe::AudioFormat::Float)
           ->setFormatConversionAllowed(true)
           ->setChannelConversionAllowed(true)
           ->setChannelCount(oboe::ChannelCount::Stereo)
           ->setDataCallback(this)
           ->setErrorCallback(this);

    oboe::Result result = builder.openStream(stream_);
    if (result != oboe::Result::OK) {
        LOGE("Failed to open Oboe audio stream: %s", oboe::convertToText(result));
        return false;
    }

    const int32_t sampleRate = stream_->getSampleRate();
    voicePool_.setSampleRate(static_cast<float>(sampleRate));
    diagnostics_.sampleRate.store(sampleRate, std::memory_order_relaxed);
    diagnostics_.bufferFrames.store(stream_->getFramesPerBurst(), std::memory_order_relaxed);

    result = stream_->requestStart();
    if (result != oboe::Result::OK) {
        LOGE("Failed to start Oboe audio stream: %s", oboe::convertToText(result));
        stream_->close();
        stream_.reset();
        return false;
    }

    isRunning_.store(true, std::memory_order_release);
    LOGI("Workstation Audio Engine started successfully. Format: %s, Sharing: %s, Sample rate: %d, Burst frames: %d",
         oboe::convertToText(stream_->getFormat()),
         oboe::convertToText(stream_->getSharingMode()),
         sampleRate,
         stream_->getFramesPerBurst());
    return true;
}

void OboeAudioEngine::stop() {
    if (!isRunning_.exchange(false, std::memory_order_acq_rel)) {
        return;
    }

    if (stream_) {
        stream_->stop();
        stream_->close();
        stream_.reset();
    }
    voicePool_.reset();
    LOGI("Workstation Audio Engine stopped.");
}

void OboeAudioEngine::restart() {
    stop();
    start();
}

bool OboeAudioEngine::pushEvent(const WorkstationEvent& event) noexcept {
    return eventQueue_.push(event);
}

void OboeAudioEngine::setMasterVolume(float volume) noexcept {
    voicePool_.setMasterVolume(volume);
}

void OboeAudioEngine::setPitchBend(float bendSemitones) noexcept {
    voicePool_.setPitchBend(bendSemitones);
}

int32_t OboeAudioEngine::updateAndGetXRunCount() noexcept {
    if (stream_) {
        auto xrunsResult = stream_->getXRunCount();
        if (xrunsResult) {
            diagnostics_.xrunCount.store(static_cast<uint32_t>(xrunsResult.value()), std::memory_order_relaxed);
        }
    }
    return diagnostics_.xrunCount.load(std::memory_order_relaxed);
}

float OboeAudioEngine::updateAndGetHardwareLatencyMs() noexcept {
    if (stream_) {
        auto latencyResult = stream_->calculateLatencyMillis();
        if (latencyResult) {
            diagnostics_.hardwareLatencyMs.store(static_cast<float>(latencyResult.value()), std::memory_order_relaxed);
        }
    }
    return diagnostics_.hardwareLatencyMs.load(std::memory_order_relaxed);
}

// REAL-TIME AUDIO CALLBACK (Hard real-time rules apply: zero allocations, zero mutexes, zero JNI, zero virtual driver queries)
oboe::DataCallbackResult OboeAudioEngine::onAudioReady(
    oboe::AudioStream* audioStream,
    void* audioData,
    int32_t numFrames) {

    struct timespec startTime, endTime;
    clock_gettime(CLOCK_MONOTONIC, &startTime);

    // 1. Drain pending events from lock-free queue (bounded loop: max 256 events per slice)
    WorkstationEvent event;
    int32_t eventsProcessed = 0;
    while (eventsProcessed < 256 && eventQueue_.pop(event)) {
        ++eventsProcessed;
        switch (event.type) {
            case EventType::NOTE_ON:
                voicePool_.noteOn(event.data1, event.data2, event.channel, event.floatValue);
                break;
            case EventType::NOTE_OFF:
                voicePool_.noteOff(event.data1, event.channel);
                break;
            case EventType::ALL_NOTES_OFF:
                voicePool_.allNotesOff();
                break;
            case EventType::PITCH_BEND:
                voicePool_.setPitchBend(event.floatValue);
                break;
            case EventType::MASTER_VOLUME:
                voicePool_.setMasterVolume(event.floatValue);
                break;
            case EventType::MODULATION:
                voicePool_.setModulation(event.floatValue);
                break;
            case EventType::PARAM_CHANGE:
                // Param IDs: 1: Cutoff, 2: Resonance, 3: Attack, 4: Decay, 5: Sustain, 6: Release, 7: VelocityCurve
                if (event.data1 == 1) {
                    voicePool_.setFilterCutoff(event.floatValue);
                } else if (event.data1 == 2) {
                    voicePool_.setFilterResonance(event.floatValue);
                } else if (event.data1 == 7) {
                    voicePool_.setVelocityCurve(static_cast<VelocityCurveType>(event.data2));
                }
                break;
            default:
                break;
        }
    }

    // 2. Render voices directly into audio buffer (Uses lookup table, 0 transcendental maths)
    const auto format = (audioStream != nullptr) ? audioStream->getFormat() : oboe::AudioFormat::Float;
    if (format == oboe::AudioFormat::Float) {
        auto* floatBuffer = static_cast<float*>(audioData);
        voicePool_.render(floatBuffer, numFrames, diagnostics_);
    } else if (format == oboe::AudioFormat::I16) {
        // Robust fallback if underlying AudioTrack delivers 16-bit PCM buffer
        auto* int16Buffer = static_cast<int16_t*>(audioData);
        int32_t remainingFrames = numFrames;
        int32_t offsetFrames = 0;
        while (remainingFrames > 0) {
            const int32_t chunkFrames = std::min(remainingFrames, 1024);
            voicePool_.render(scratchFloatBuffer_.data(), chunkFrames, diagnostics_);
            const int32_t sampleCount = chunkFrames * 2;
            for (int32_t i = 0; i < sampleCount; ++i) {
                float sample = std::clamp(scratchFloatBuffer_[i], -1.0f, 1.0f);
                int16Buffer[(offsetFrames * 2) + i] = static_cast<int16_t>(sample * 32767.0f);
            }
            offsetFrames += chunkFrames;
            remainingFrames -= chunkFrames;
        }
    } else {
        auto* floatBuffer = static_cast<float*>(audioData);
        voicePool_.render(floatBuffer, numFrames, diagnostics_);
    }

    // 3. Telemetry timing calculation
    clock_gettime(CLOCK_MONOTONIC, &endTime);
    const int64_t durationNs = (endTime.tv_sec - startTime.tv_sec) * 1000000000LL +
                               (endTime.tv_nsec - startTime.tv_nsec);
    diagnostics_.lastCallbackDurationNs.store(durationNs, std::memory_order_relaxed);

    const int32_t sampleRate = diagnostics_.sampleRate.load(std::memory_order_relaxed);
    if (sampleRate > 0 && numFrames > 0) {
        const double bufferDurationNs = (static_cast<double>(numFrames) / sampleRate) * 1e9;
        const float load = static_cast<float>(durationNs / bufferDurationNs);
        diagnostics_.cpuLoad.store(load, std::memory_order_relaxed);
    }

    return oboe::DataCallbackResult::Continue;
}

void OboeAudioEngine::onErrorAfterClose(oboe::AudioStream* /*audioStream*/, oboe::Result error) {
    LOGE("Oboe Audio Stream error occurred: %s", oboe::convertToText(error));
    // Stream has already been closed by Oboe at this point.
    // Reset our reference and flag without calling stream_->close() again.
    isRunning_.store(false, std::memory_order_release);
    if (stream_) {
        stream_.reset();
    }
    if (error == oboe::Result::ErrorDisconnected) {
        LOGI("Reopening audio stream after ErrorDisconnected...");
        start();
    }
}

} // namespace workstation
