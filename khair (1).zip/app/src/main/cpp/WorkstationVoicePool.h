#pragma once

#include <cstdint>
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
#include "AudioDiagnostics.h"
#include "BandlimitedOscillator.h"
#include "AdsrEnvelope.h"
#include "StateVariableFilter.h"
#include "LowFrequencyOscillator.h"
#include "VelocityMapper.h"

namespace workstation {

constexpr size_t MAX_POLYPHONY = 64;
constexpr float PI_2 = 6.28318530717958647692f;

struct PcmSample {
    int32_t id{0};
    int32_t sampleRate{44100};
    int32_t channels{1}; // 1 = mono, 2 = stereo
    int32_t rootKey{60};
    int32_t fineTuneCents{0};
    int32_t loopStart{0};
    int32_t loopEnd{0};
    int32_t totalFrames{0};
    bool isLooped{false};
    bool isLoaded{false};
    std::vector<float> sampleData{}; // interleaved normalized float samples [-1.0f, +1.0f]
};

struct SynthVoice {
    bool active{false};
    uint8_t note{0};
    uint8_t channel{0};
    float velocityGain{0.0f};

    // Advanced synthesis sub-components
    BandlimitedOscillator osc1{};
    BandlimitedOscillator osc2{};
    AdsrEnvelope ampEnvelope{};
    AdsrEnvelope filterEnvelope{};
    StateVariableFilter filter{};
    LowFrequencyOscillator vibratoLfo{};

    // Real PCM sample playback state
    bool isPcmVoice{false};
    int32_t pcmSlot{-1};
    float pcmPhase{0.0f};
    float pcmPhaseIncrement{1.0f};

    // Tuning & pitch
    float baseFrequency{440.0f};
    float centOffset{0.0f};
    float osc2DetuneSemitones{0.04f}; // Subtly detuned for rich unison/chorus analog warmth

    // Voice management
    uint64_t allocationAge{0};
    float pan{0.5f}; // 0.0 = Left, 1.0 = Right

    // Voice-Stealing micro-fade protocol (1.5ms quick fade out to prevent clicks)
    bool isStealFading{false};
    float stealFadeGain{1.0f};
    float stealFadeRate{0.0f};
    uint8_t targetNote{0};
    uint8_t targetVelocity{0};
    uint8_t targetChannel{0};
    float targetCentOffset{0.0f};
};

class WorkstationVoicePool {
public:
    WorkstationVoicePool() {
        // Precompute static wavetable for panning & fast sine lookups
        for (int i = 0; i < 4096; ++i) {
            sineTable_[i] = std::sin((static_cast<float>(i) / 4096.0f) * PI_2);
        }
        reset();
    }

    void reset() noexcept {
        for (auto& v : voices_) {
            v.active = false;
            v.isPcmVoice = false;
            v.pcmSlot = -1;
            v.pcmPhase = 0.0f;
            v.pcmPhaseIncrement = 1.0f;
            v.ampEnvelope.reset();
            v.filterEnvelope.reset();
            v.filter.reset();
            v.osc1.reset();
            v.osc2.reset();
            v.vibratoLfo.reset();
            v.allocationAge = 0;
            v.isStealFading = false;
            v.stealFadeGain = 1.0f;
            v.stealFadeRate = 0.0f;
        }
        globalAgeCounter_ = 0;
        pitchBendSemitones_ = 0.0f;
        masterVolume_ = 0.8f;
        filterCutoffHz_ = 4500.0f;
        filterResonance_ = 0.25f;
        velocityCurve_ = VelocityCurveType::LINEAR;
    }

    static constexpr size_t MAX_PCM_SLOTS = 16;

    bool loadPcmSample(
        int32_t slot,
        int32_t sampleRate,
        int32_t channels,
        int32_t rootKey,
        int32_t fineTuneCents,
        int32_t loopStart,
        int32_t loopEnd,
        bool isLooped,
        const float* data,
        int32_t totalFrames
    ) noexcept {
        if (slot < 0 || slot >= static_cast<int32_t>(MAX_PCM_SLOTS) || data == nullptr || totalFrames <= 0) {
            return false;
        }

        auto& s = pcmSamples_[slot];
        s.isLoaded = false;
        s.id = slot;
        s.sampleRate = (sampleRate > 4000) ? sampleRate : 44100;
        s.channels = (channels == 2) ? 2 : 1;
        s.rootKey = std::clamp(rootKey, 0, 127);
        s.fineTuneCents = std::clamp(fineTuneCents, -100, 100);
        s.totalFrames = totalFrames;
        s.loopStart = std::clamp(loopStart, 0, totalFrames);
        s.loopEnd = (loopEnd > s.loopStart && loopEnd <= totalFrames) ? loopEnd : totalFrames;
        s.isLooped = isLooped && (s.loopEnd > s.loopStart);

        try {
            const size_t totalFloats = static_cast<size_t>(totalFrames * s.channels);
            s.sampleData.assign(data, data + totalFloats);
            s.isLoaded = true;
            if (activePcmSlot_.load(std::memory_order_relaxed) < 0) {
                activePcmSlot_.store(slot, std::memory_order_release);
            }
            return true;
        } catch (...) {
            s.isLoaded = false;
            return false;
        }
    }

    void clearPcmSamples() noexcept {
        for (auto& s : pcmSamples_) {
            s.isLoaded = false;
            s.sampleData.clear();
        }
        activePcmSlot_.store(-1, std::memory_order_release);
    }

    bool isPcmSampleLoaded(int32_t slot) const noexcept {
        if (slot >= 0 && slot < static_cast<int32_t>(MAX_PCM_SLOTS)) {
            return pcmSamples_[slot].isLoaded;
        }
        return false;
    }

    void setActivePcmSlot(int32_t slot) noexcept {
        if (slot >= -1 && slot < static_cast<int32_t>(MAX_PCM_SLOTS)) {
            activePcmSlot_.store(slot, std::memory_order_release);
        }
    }

    int32_t getActivePcmSlot() const noexcept {
        return activePcmSlot_.load(std::memory_order_relaxed);
    }

    void setSampleRate(float sampleRate) noexcept {
        sampleRate_ = (sampleRate > 8000.0f) ? sampleRate : 48000.0f;
        for (auto& v : voices_) {
            v.osc1.setSampleRate(sampleRate_);
            v.osc2.setSampleRate(sampleRate_);
            v.ampEnvelope.setSampleRate(sampleRate_);
            v.filterEnvelope.setSampleRate(sampleRate_);
            v.filter.setSampleRate(sampleRate_);
            v.vibratoLfo.setSampleRate(sampleRate_);
        }
    }

    void setMasterVolume(float vol) noexcept {
        masterVolume_ = std::clamp(vol, 0.0f, 1.0f);
    }

    void setPitchBend(float bendSemitones) noexcept {
        pitchBendSemitones_ = std::clamp(bendSemitones, -12.0f, 12.0f);
        updateAllFrequencies();
    }

    void setFilterCutoff(float cutoffHz) noexcept {
        filterCutoffHz_ = std::clamp(cutoffHz, 20.0f, sampleRate_ * 0.45f);
        for (auto& v : voices_) {
            v.filter.setCutoffAndResonance(filterCutoffHz_, filterResonance_);
        }
    }

    void setFilterResonance(float res) noexcept {
        filterResonance_ = std::clamp(res, 0.0f, 0.95f);
        for (auto& v : voices_) {
            v.filter.setCutoffAndResonance(filterCutoffHz_, filterResonance_);
        }
    }

    void setVelocityCurve(VelocityCurveType curve) noexcept {
        velocityCurve_ = curve;
    }

    void setModulation(float modValue) noexcept {
        modulationDepth_ = std::clamp(modValue, 0.0f, 1.0f);
    }

    void setAdsr(float attack, float decay, float sustain, float release) noexcept {
        attackSec_ = attack;
        decaySec_ = decay;
        sustainLevel_ = sustain;
        releaseSec_ = release;
        for (auto& v : voices_) {
            v.ampEnvelope.setParameters(attackSec_, decaySec_, sustainLevel_, releaseSec_);
            v.filterEnvelope.setParameters(attackSec_ * 1.2f, decaySec_, sustainLevel_ * 0.8f, releaseSec_);
        }
    }

    void noteOn(uint8_t note, uint8_t velocity, uint8_t channel, float centOffset = 0.0f) noexcept {
        if (velocity == 0) {
            noteOff(note, channel);
            return;
        }

        const size_t voiceIdx = allocateVoice();
        auto& v = voices_[voiceIdx];

        if (v.active) {
            // Voice stealing micro-fade protocol: ramp down the currently active note over 1.5ms
            v.isStealFading = true;
            v.stealFadeGain = 1.0f;
            v.stealFadeRate = 1.0f / (sampleRate_ * 0.0015f); // 1.5ms decay duration
            v.targetNote = note;
            v.targetVelocity = velocity;
            v.targetChannel = channel;
            v.targetCentOffset = centOffset;
        } else {
            // Instant trigger for free voice
            initVoice(v, note, velocity, channel, centOffset);
        }
    }

    void noteOff(uint8_t note, uint8_t channel) noexcept {
        for (auto& v : voices_) {
            if (v.active && v.note == note && v.channel == channel && !v.ampEnvelope.isInRelease()) {
                v.ampEnvelope.gateOff();
                v.filterEnvelope.gateOff();
            }
        }
    }

    void allNotesOff() noexcept {
        for (auto& v : voices_) {
            if (v.active && !v.ampEnvelope.isInRelease()) {
                v.ampEnvelope.gateOff();
                v.filterEnvelope.gateOff();
            }
        }
    }

    // Real-time render loop: Bounded O(MAX_POLYPHONY * numFrames), zero allocations, zero sin/cos math
    void render(float* outputBuffer, int32_t numFrames, AudioDiagnostics& diagnostics) noexcept {
        uint32_t activeCount = 0;
        float peakL = 0.0f;
        float peakR = 0.0f;

        // Clear output buffer (interleaved stereo)
        const int32_t totalSamples = numFrames * 2;
        std::fill_n(outputBuffer, totalSamples, 0.0f);

        for (size_t i = 0; i < MAX_POLYPHONY; ++i) {
            auto& v = voices_[i];
            if (!v.active) continue;

            ++activeCount;

            // Panning gain using precomputed sinusoidal table
            const float panAngle = v.pan * 1.57079632f; // [0, pi/2]
            const float leftGain = lookupSine(panAngle + 1.57079632f) * v.velocityGain * masterVolume_;
            const float rightGain = lookupSine(panAngle) * v.velocityGain * masterVolume_;

            for (int32_t f = 0; f < numFrames; ++f) {
                // Micro-fade gain multiplier check
                float currentFadeGain = 1.0f;
                if (v.isStealFading) {
                    currentFadeGain = v.stealFadeGain;
                    v.stealFadeGain -= v.stealFadeRate;
                    if (v.stealFadeGain <= 0.0001f) {
                        // Fade completed, perform dynamic switchover inside callback
                        initVoice(v, v.targetNote, v.targetVelocity, v.targetChannel, v.targetCentOffset);
                        currentFadeGain = 1.0f;
                    }
                }

                // ADSR envelope step
                const float ampGain = v.ampEnvelope.process();
                if (v.ampEnvelope.isIdle()) {
                    v.active = false;
                    break;
                }

                float sampleL = 0.0f;
                float sampleR = 0.0f;

                if (v.isPcmVoice && v.pcmSlot >= 0 && pcmSamples_[v.pcmSlot].isLoaded) {
                    const auto& smp = pcmSamples_[v.pcmSlot];
                    const int32_t totalFrames = smp.totalFrames;
                    const int32_t channels = smp.channels;

                    int32_t idx0 = static_cast<int32_t>(v.pcmPhase);
                    int32_t idx1 = idx0 + 1;
                    const float frac = v.pcmPhase - static_cast<float>(idx0);

                    if (smp.isLooped && smp.loopEnd > smp.loopStart && smp.loopEnd <= totalFrames) {
                        const int32_t loopLen = smp.loopEnd - smp.loopStart;
                        if (idx0 >= smp.loopEnd) {
                            idx0 = smp.loopStart + ((idx0 - smp.loopStart) % loopLen);
                            idx1 = idx0 + 1;
                            if (idx1 >= smp.loopEnd) idx1 = smp.loopStart;
                        } else if (idx1 >= smp.loopEnd) {
                            idx1 = smp.loopStart;
                        }
                    } else {
                        if (idx0 >= totalFrames) {
                            v.ampEnvelope.gateOff();
                            v.active = false;
                            break;
                        }
                        if (idx1 >= totalFrames) {
                            idx1 = totalFrames - 1;
                        }
                    }

                    if (channels == 1) {
                        const float val0 = smp.sampleData[idx0];
                        const float val1 = smp.sampleData[idx1];
                        const float s = val0 + frac * (val1 - val0);
                        sampleL = s;
                        sampleR = s;
                    } else {
                        const float val0L = smp.sampleData[idx0 * 2];
                        const float val0R = smp.sampleData[idx0 * 2 + 1];
                        const float val1L = smp.sampleData[idx1 * 2];
                        const float val1R = smp.sampleData[idx1 * 2 + 1];
                        sampleL = val0L + frac * (val1L - val0L);
                        sampleR = val0R + frac * (val1R - val0R);
                    }

                    // Advance PCM phase pointer
                    v.pcmPhase += v.pcmPhaseIncrement;
                    if (smp.isLooped && smp.loopEnd > smp.loopStart) {
                        const int32_t loopLen = smp.loopEnd - smp.loopStart;
                        if (v.pcmPhase >= smp.loopEnd && loopLen > 0) {
                            v.pcmPhase -= static_cast<float>(loopLen);
                        }
                    }
                } else {
                    // Filter envelope modulation
                    const float filterEnv = v.filterEnvelope.process();
                    const float modulatedCutoff = std::clamp(
                        filterCutoffHz_ + (filterEnv * 3000.0f),
                        20.0f,
                        sampleRate_ * 0.45f
                    );
                    v.filter.setCutoffAndResonance(modulatedCutoff, filterResonance_);

                    // LFO Vibrato pitch modulation (mod depth from mod wheel or preset)
                    if (modulationDepth_ > 0.001f) {
                        const float lfoVal = v.vibratoLfo.process();
                        // Fast Taylor expansion for 2^(x/12) = exp(x * ln(2)/12) around 0 where x is small (cents)
                        // ln(2) / 12 = 0.057762265f
                        const float x = lfoVal * modulationDepth_ * 0.5f;
                        const float y = x * 0.057762265f;
                        const float vibratoPitchFactor = 1.0f + y + (0.5f * y * y);
                        v.osc1.setFrequency(v.baseFrequency * vibratoPitchFactor);
                        v.osc2.setFrequency(v.baseFrequency * vibratoPitchFactor * 1.0023f);
                    }

                    // Dual band-limited oscillators (Osc1 Saw + Osc2 Pulse)
                    const float o1 = v.osc1.process();
                    const float o2 = v.osc2.process();
                    const float mixed = (o1 * 0.6f + o2 * 0.4f);

                    // Filter pass
                    sampleL = v.filter.process(mixed);
                    sampleR = sampleL;
                }

                // Final scaled sample
                const float finalL = sampleL * ampGain * currentFadeGain;
                const float finalR = sampleR * ampGain * currentFadeGain;

                const int32_t outIdx = f * 2;
                outputBuffer[outIdx] += finalL * leftGain;
                outputBuffer[outIdx + 1] += finalR * rightGain;
            }
        }

        // Apply soft saturation / limiter and compute peak telemetry
        for (int32_t s = 0; s < numFrames; ++s) {
            const int32_t outIdx = s * 2;
            float l = outputBuffer[outIdx];
            float r = outputBuffer[outIdx + 1];

            // Soft-knee cubic saturation
            l = softLimit(l);
            r = softLimit(r);

            outputBuffer[outIdx] = l;
            outputBuffer[outIdx + 1] = r;

            const float absL = std::abs(l);
            const float absR = std::abs(r);
            if (absL > peakL) peakL = absL;
            if (absR > peakR) peakR = absR;
        }

        diagnostics.activeVoices.store(activeCount, std::memory_order_relaxed);
        diagnostics.peakMeterL.store(peakL, std::memory_order_relaxed);
        diagnostics.peakMeterR.store(peakR, std::memory_order_relaxed);
    }

private:
    void initVoice(SynthVoice& v, uint8_t note, uint8_t velocity, uint8_t channel, float centOffset) noexcept {
        v.active = true;
        v.note = note;
        v.channel = channel;
        v.velocityGain = VelocityMapper::mapVelocity(velocity, velocityCurve_);
        v.centOffset = centOffset;
        v.allocationAge = ++globalAgeCounter_;
        v.pan = 0.5f;
        v.isStealFading = false;
        v.stealFadeGain = 1.0f;
        v.stealFadeRate = 0.0f;

        const int32_t activeSlot = activePcmSlot_.load(std::memory_order_relaxed);
        if (channel == 0 && activeSlot >= 0 && activeSlot < static_cast<int32_t>(MAX_PCM_SLOTS) && pcmSamples_[activeSlot].isLoaded) {
            v.isPcmVoice = true;
            v.pcmSlot = activeSlot;
            v.pcmPhase = 0.0f;
            const auto& smp = pcmSamples_[activeSlot];
            const float semitoneDiff = static_cast<float>(note - smp.rootKey) + 
                                       ((centOffset + smp.fineTuneCents) / 100.0f) + 
                                       pitchBendSemitones_;
            const float pitchRatio = std::exp2(semitoneDiff / 12.0f);
            v.pcmPhaseIncrement = (static_cast<float>(smp.sampleRate) / sampleRate_) * pitchRatio;
            v.baseFrequency = 440.0f * std::exp2((note - 69.0f) / 12.0f);

            // Natural acoustic sample envelope: responsive attack, long natural sustain, clean release
            v.ampEnvelope.setSampleRate(sampleRate_);
            v.ampEnvelope.setParameters(0.002f, 2.5f, 0.75f, 0.35f);
            v.ampEnvelope.gateOn();

            v.filterEnvelope.setSampleRate(sampleRate_);
            v.filterEnvelope.setParameters(0.005f, 1.5f, 0.9f, 0.35f);
            v.filterEnvelope.gateOn();

            v.filter.setSampleRate(sampleRate_);
            v.filter.setType(FilterType::LOW_PASS);
            v.filter.setCutoffAndResonance(std::min(filterCutoffHz_, sampleRate_ * 0.45f), 0.0f);
            v.filter.reset();
            return;
        }

        v.isPcmVoice = false;
        v.pcmSlot = -1;

        // Channel-specific acoustic timbre voicing
        // Channel 9: Drums & Kits (Snappy percussion envelope, noise/square percussion)
        // Channel 8: Percussion (Tambourine/shakers)
        // Channel 10: Bass (Warm filtered triangle/saw)
        // Channel 13: Strings (Slow attack, long release)
        // Channels 0, 11, 12, 14, 15: Polyphonic Keyboards / Brass / Leads
        float voiceAttack = attackSec_;
        float voiceDecay = decaySec_;
        float voiceSustain = sustainLevel_;
        float voiceRelease = releaseSec_;
        float voiceCutoff = filterCutoffHz_;
        OscillatorWaveform osc1Wave = OscillatorWaveform::SAWTOOTH;
        OscillatorWaveform osc2Wave = OscillatorWaveform::SQUARE;

        if (channel == 9 || channel == 8) {
            // Percussion / Drum channel
            voiceAttack = 0.002f;
            voiceDecay = 0.18f;
            voiceSustain = 0.0f;
            voiceRelease = 0.05f;
            voiceCutoff = std::min(8000.0f, sampleRate_ * 0.45f);
            osc1Wave = OscillatorWaveform::SQUARE;
            osc2Wave = OscillatorWaveform::TRIANGLE;
            v.pan = (channel == 8) ? 0.4f : 0.5f;
        } else if (channel == 10) {
            // Bass channel (Punchy, mono-priority bass warmth)
            voiceAttack = 0.005f;
            voiceDecay = 0.45f;
            voiceSustain = 0.4f;
            voiceRelease = 0.15f;
            voiceCutoff = std::min(1800.0f, sampleRate_ * 0.45f);
            osc1Wave = OscillatorWaveform::SAWTOOTH;
            osc2Wave = OscillatorWaveform::TRIANGLE;
            v.pan = 0.5f;
        } else if (channel == 13) {
            // Strings pad (Gentle blooming envelope)
            voiceAttack = 0.12f;
            voiceDecay = 0.8f;
            voiceSustain = 0.85f;
            voiceRelease = 0.6f;
            voiceCutoff = std::min(5500.0f, sampleRate_ * 0.45f);
            v.pan = 0.55f;
        } else if (channel == 12) {
            // Guitar strumming
            voiceAttack = 0.008f;
            voiceDecay = 0.5f;
            voiceSustain = 0.3f;
            voiceRelease = 0.2f;
            v.pan = 0.65f;
        } else if (channel == 11) {
            // Piano accompaniment
            voiceAttack = 0.005f;
            voiceDecay = 0.7f;
            voiceSustain = 0.5f;
            voiceRelease = 0.25f;
            v.pan = 0.38f;
        }

        // Configure oscillators
        v.osc1.setSampleRate(sampleRate_);
        v.osc1.setWaveform(osc1Wave);
        v.osc2.setSampleRate(sampleRate_);
        v.osc2.setWaveform(osc2Wave);
        v.osc2.setPulseWidth(0.5f);

        // Configure Envelopes
        v.ampEnvelope.setSampleRate(sampleRate_);
        v.ampEnvelope.setParameters(voiceAttack, voiceDecay, voiceSustain, voiceRelease);
        v.ampEnvelope.gateOn();

        v.filterEnvelope.setSampleRate(sampleRate_);
        v.filterEnvelope.setParameters(voiceAttack * 1.2f, voiceDecay, voiceSustain * 0.8f, voiceRelease);
        v.filterEnvelope.gateOn();

        // Configure Filter
        v.filter.setSampleRate(sampleRate_);
        v.filter.setType(FilterType::LOW_PASS);
        v.filter.setCutoffAndResonance(voiceCutoff, filterResonance_);
        v.filter.reset();

        // Configure LFO
        v.vibratoLfo.setSampleRate(sampleRate_);
        v.vibratoLfo.setRateHz(5.5f);
        v.vibratoLfo.setWaveform(LfoWaveform::TRIANGLE);

        // Calculate pitch frequency
        calculateVoiceFrequency(v);
    }

    void calculateVoiceFrequency(SynthVoice& v) noexcept {
        const float effectiveMidi = static_cast<float>(v.note) + (v.centOffset / 100.0f) + pitchBendSemitones_;
        const float freq = 440.0f * std::pow(2.0f, (effectiveMidi - 69.0f) / 12.0f);
        v.baseFrequency = freq;
        v.osc1.setFrequency(freq);
        // Osc 2 subtle detune (+4 cents)
        const float osc2Freq = 440.0f * std::pow(2.0f, (effectiveMidi + v.osc2DetuneSemitones - 69.0f) / 12.0f);
        v.osc2.setFrequency(osc2Freq);
    }

    void updateAllFrequencies() noexcept {
        for (auto& v : voices_) {
            if (v.active) {
                if (v.isPcmVoice && v.pcmSlot >= 0 && pcmSamples_[v.pcmSlot].isLoaded) {
                    const auto& smp = pcmSamples_[v.pcmSlot];
                    const float semitoneDiff = static_cast<float>(v.note - smp.rootKey) + 
                                               ((v.centOffset + smp.fineTuneCents) / 100.0f) + 
                                               pitchBendSemitones_;
                    v.pcmPhaseIncrement = (static_cast<float>(smp.sampleRate) / sampleRate_) * std::exp2(semitoneDiff / 12.0f);
                } else {
                    calculateVoiceFrequency(v);
                }
            }
        }
    }

    inline float lookupSine(float phase) const noexcept {
        float p = phase;
        if (p < 0.0f) {
            p = std::fmod(p, PI_2) + PI_2;
        } else if (p >= PI_2) {
            p = std::fmod(p, PI_2);
        }

        const float indexFloat = (p / PI_2) * 4096.0f;
        const int32_t index0 = static_cast<int32_t>(indexFloat) & 4095;
        const int32_t index1 = (index0 + 1) & 4095;
        const float frac = indexFloat - static_cast<float>(index0);
        return sineTable_[index0] + frac * (sineTable_[index1] - sineTable_[index0]);
    }

    static float softLimit(float x) noexcept {
        if (x > 1.0f) return 1.0f;
        if (x < -1.0f) return -1.0f;
        return 1.5f * x - 0.5f * (x * x * x);
    }

    size_t allocateVoice() noexcept {
        // 1. Inactive voice
        for (size_t i = 0; i < MAX_POLYPHONY; ++i) {
            if (!voices_[i].active) {
                return i;
            }
        }

        // 2. Voice in release stage with lowest envelope
        size_t bestReleaseIdx = 0;
        float lowestEnv = 2.0f;
        bool foundRelease = false;

        for (size_t i = 0; i < MAX_POLYPHONY; ++i) {
            if (voices_[i].ampEnvelope.isInRelease() && voices_[i].ampEnvelope.getCurrentLevel() < lowestEnv) {
                lowestEnv = voices_[i].ampEnvelope.getCurrentLevel();
                bestReleaseIdx = i;
                foundRelease = true;
            }
        }

        if (foundRelease) {
            return bestReleaseIdx;
        }

        // 3. Oldest voice
        size_t oldestIdx = 0;
        uint64_t oldestAge = UINT64_MAX;

        for (size_t i = 0; i < MAX_POLYPHONY; ++i) {
            if (voices_[i].allocationAge < oldestAge) {
                oldestAge = voices_[i].allocationAge;
                oldestIdx = i;
            }
        }

        return oldestIdx;
    }

    std::array<SynthVoice, MAX_POLYPHONY> voices_{};
    std::array<float, 4096> sineTable_{};
    float sampleRate_{48000.0f};
    float masterVolume_{0.8f};
    float pitchBendSemitones_{0.0f};
    float filterCutoffHz_{4500.0f};
    float filterResonance_{0.25f};
    float modulationDepth_{0.0f};
    VelocityCurveType velocityCurve_{VelocityCurveType::LINEAR};

    float attackSec_{0.005f};
    float decaySec_{0.35f};
    float sustainLevel_{0.7f};
    float releaseSec_{0.25f};

    uint64_t globalAgeCounter_{0};

    std::array<PcmSample, MAX_PCM_SLOTS> pcmSamples_{};
    std::atomic<int32_t> activePcmSlot_{-1};
};

} // namespace workstation
