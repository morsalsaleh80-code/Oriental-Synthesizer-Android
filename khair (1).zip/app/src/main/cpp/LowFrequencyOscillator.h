#pragma once

#include <cmath>
#include <algorithm>

namespace workstation {

enum class LfoWaveform : uint8_t {
    TRIANGLE = 0,
    SINE = 1,
    SQUARE = 2,
    SAWTOOTH = 3
};

// Low Frequency Oscillator for real-time vibrato, filter sweep, and tremolo
class LowFrequencyOscillator {
public:
    LowFrequencyOscillator() = default;

    void setSampleRate(float sampleRate) noexcept {
        sampleRate_ = (sampleRate > 8000.0f) ? sampleRate : 48000.0f;
        updateIncrement();
    }

    void setRateHz(float rateHz) noexcept {
        rateHz_ = std::clamp(rateHz, 0.05f, 30.0f);
        updateIncrement();
    }

    void setWaveform(LfoWaveform waveform) noexcept {
        waveform_ = waveform;
    }

    void reset() noexcept {
        phase_ = 0.0f;
    }

    // Step LFO: returns normalized value in [-1.0, 1.0]
    inline float process() noexcept {
        float val = 0.0f;
        switch (waveform_) {
            case LfoWaveform::TRIANGLE:
                val = (phase_ < 0.5f) ? (4.0f * phase_ - 1.0f) : (3.0f - 4.0f * phase_);
                break;
            case LfoWaveform::SINE: {
                // Smooth sine approx: 4 * (p - 0.5) * (1 - 2|p-0.5|)
                float p = phase_ - 0.5f;
                val = 4.0f * (p * (1.0f - 2.0f * std::abs(p)) * 4.0f);
                break;
            }
            case LfoWaveform::SQUARE:
                val = (phase_ < 0.5f) ? 1.0f : -1.0f;
                break;
            case LfoWaveform::SAWTOOTH:
                val = (2.0f * phase_) - 1.0f;
                break;
        }

        phase_ += phaseIncrement_;
        if (phase_ >= 1.0f) {
            phase_ -= 1.0f;
        }
        return val;
    }

private:
    void updateIncrement() noexcept {
        phaseIncrement_ = rateHz_ / sampleRate_;
    }

    float sampleRate_{48000.0f};
    float rateHz_{5.0f}; // 5 Hz standard vibrato rate
    float phaseIncrement_{0.000104f};
    float phase_{0.0f};
    LfoWaveform waveform_{LfoWaveform::TRIANGLE};
};

} // namespace workstation
