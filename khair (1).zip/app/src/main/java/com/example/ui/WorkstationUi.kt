package com.example.ui

import android.view.MotionEvent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ArrangerSection
import com.example.engine.PerformanceController
import com.example.engine.ScalePreset
import com.example.engine.WorkstationState

// Workstation Pro Color Palette
private val CarbonBackground = Color(0xFF121417)
private val PanelSurface = Color(0xFF1C1F26)
private val PanelBorder = Color(0xFF2A2E39)
private val DisplayBackground = Color(0xFF090B0E)
private val NeonCyan = Color(0xFF00E5FF)
private val AmberActive = Color(0xFFFF9100)
private val EmeraldGood = Color(0xFF00E676)
private val RedAlert = Color(0xFFFF1744)
private val KeyWhite = Color(0xFFF0F3F7)
private val KeyWhitePressed = Color(0xFF80D8FF)
private val KeyBlack = Color(0xFF1E222A)
private val KeyBlackPressed = Color(0xFF0091EA)

@Composable
fun WorkstationScreen(
    controller: PerformanceController,
    modifier: Modifier = Modifier
) {
    val state by controller.uiState.collectAsState()

    Scaffold(
        containerColor = CarbonBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Top Master Header
            WorkstationHeader(controller = controller, state = state)

            // Scrollable Control Deck
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Real-time OLED Diagnostic Display HUD
                DiagnosticsHud(state = state)

                // Arranger Control Bar & Tempo
                ArrangerControlBar(controller = controller, state = state)

                // KORG Pa4X SET Compatibility & Style Library
                Pa4xSetManagerPanel(controller = controller, state = state)

                // Oriental Microtonal Quarter-Tone Matrix
                MicrotonalMatrixPanel(controller = controller, state = state)
            }

            // Bottom Performance Zone (Pitch Bend + Keyboard)
            PerformanceKeyboardZone(controller = controller, state = state)
        }
    }
}

@Composable
private fun WorkstationHeader(
    controller: PerformanceController,
    state: WorkstationState
) {
    Surface(
        color = PanelSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand & Engine Status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (state.isAudioEngineActive) EmeraldGood else RedAlert)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "ARRANGER WORKSTATION",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (state.isAudioEngineActive) "OBOE LOW-LATENCY [AAUDIO]" else "ENGINE OFF",
                        color = if (state.isAudioEngineActive) NeonCyan else Color.Gray,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Center: Master Volume
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.widthIn(max = 200.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = "Master Volume",
                    tint = Color.LightGray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Slider(
                    value = state.masterVolume,
                    onValueChange = { controller.onMasterVolumeChange(it) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("master_volume_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color.DarkGray
                    )
                )
            }

            // Right Actions: Engine Toggle & Panic
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { controller.toggleAudioEngine() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isAudioEngineActive) Color(0xFF263238) else Color(0xFFB71C1C)
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("engine_toggle_button")
                ) {
                    Text(
                        text = if (state.isAudioEngineActive) "STANDBY" else "START AUDIO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Button(
                    onClick = { controller.panicAllNotesOff() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF455A64)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("panic_button")
                ) {
                    Text("PANIC", fontSize = 10.sp, color = AmberActive, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsHud(state: WorkstationState) {
    val diag = state.diagnostics
    val computeTimeUs = diag.callbackDurationNs / 1000

    Surface(
        color = DisplayBackground,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF23303D)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REALTIME TELEMETRY (AAUDIO / OBOE)",
                    color = Color(0xFF64B5F6),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${diag.sampleRate} Hz | ${diag.bufferFrames} FRAMES/BURST",
                    color = Color.Gray,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(
                    label = "ACTIVE VOICES",
                    value = "${diag.activeVoices} / 64",
                    color = if (diag.activeVoices > 48) AmberActive else NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "CPU LOAD",
                    value = "%.1f %%".format(diag.cpuLoad * 100f),
                    color = if (diag.cpuLoad > 0.7f) RedAlert else EmeraldGood,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "COMPUTE TIME",
                    value = "${computeTimeUs} μs",
                    color = if (computeTimeUs > 2000) RedAlert else NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "EST. LATENCY",
                    value = "%.1f ms".format(diag.hardwareLatencyMs),
                    color = if (diag.hardwareLatencyMs > 20f) RedAlert else NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "XRUNS",
                    value = "${diag.xrunCount}",
                    color = if (diag.xrunCount > 0) RedAlert else EmeraldGood,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Stereo Peak Meter Bars
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("L", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                PeakMeterBar(level = diag.peakMeterL, modifier = Modifier.weight(1f))
                Text("R", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                PeakMeterBar(level = diag.peakMeterR, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Text(text = label, color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun PeakMeterBar(level: Float, modifier: Modifier = Modifier) {
    val clamped = level.coerceIn(0.0f, 1.0f)
    Box(
        modifier = modifier
            .height(8.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0xFF1E2228))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction = clamped)
                .background(
                    Brush.horizontalGradient(
                        listOf(EmeraldGood, AmberActive, RedAlert)
                    )
                )
        )
    }
}

@Composable
private fun ArrangerControlBar(
    controller: PerformanceController,
    state: WorkstationState
) {
    Surface(
        color = PanelSurface,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Tempo and Transport Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Arranger Core Info, Active Style & Recognized Chord Display
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "STYLE:",
                        color = Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = state.activeStyleName,
                        color = AmberActive,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("active_style_display")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CHORD:",
                        color = Color.LightGray,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = state.recognizedChord.formattedName,
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("recognized_chord_display")
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "(${state.recognizedChord.quality.displayName})",
                        color = AmberActive,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Tempo & Beat Box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { controller.onTempoChange(-1) },
                        modifier = Modifier.size(28.dp).testTag("tempo_down_button")
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Tempo Down", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "${state.tempoBpm} BPM",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(
                        onClick = { controller.onTempoChange(1) },
                        modifier = Modifier.size(28.dp).testTag("tempo_up_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Tempo Up", tint = Color.White, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    // Bar / Beat counter
                    Text(
                        text = "${state.sequencerBar}.${state.sequencerBeat}",
                        color = if (state.isArrangerPlaying) EmeraldGood else Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("arranger_beat_display")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Transport Buttons (Arranger Start/Stop, Synchro)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { controller.toggleArrangerPlayback() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isArrangerPlaying) EmeraldGood else Color(0xFF2E3842)
                    ),
                    modifier = Modifier.weight(1f).height(32.dp).testTag("arranger_play_button"),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = if (state.isArrangerPlaying) "STOP" else "START",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.isArrangerPlaying) Color.Black else Color.White
                    )
                }

                Button(
                    onClick = { controller.toggleSynchroStart() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isSynchroStartEnabled) AmberActive else Color(0xFF2E3842)
                    ),
                    modifier = Modifier.weight(1f).height(32.dp).testTag("synchro_start_button"),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "SYNC.ST",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.isSynchroStartEnabled) Color.Black else Color.White
                    )
                }

                Button(
                    onClick = { controller.toggleSynchroStop() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isSynchroStopEnabled) AmberActive else Color(0xFF2E3842)
                    ),
                    modifier = Modifier.weight(1f).height(32.dp).testTag("synchro_stop_button"),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "SYNC.SP",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.isSynchroStopEnabled) Color.Black else Color.White
                    )
                }

                // Section Variations
                ArrangerSectionButton("VAR 1", ArrangerSection.VARIATION_1, state.currentArrangerSection, "section_var_1") {
                    controller.setArrangerSection(ArrangerSection.VARIATION_1)
                }
                ArrangerSectionButton("VAR 2", ArrangerSection.VARIATION_2, state.currentArrangerSection, "section_var_2") {
                    controller.setArrangerSection(ArrangerSection.VARIATION_2)
                }
                ArrangerSectionButton("FILL 1", ArrangerSection.FILL_1, state.currentArrangerSection, "section_fill_1") {
                    controller.setArrangerSection(ArrangerSection.FILL_1)
                }
                ArrangerSectionButton("BREAK", ArrangerSection.BREAK, state.currentArrangerSection, "section_break") {
                    controller.setArrangerSection(ArrangerSection.BREAK)
                }
                ArrangerSectionButton("ENDING", ArrangerSection.ENDING_1, state.currentArrangerSection, "section_ending") {
                    controller.setArrangerSection(ArrangerSection.ENDING_1)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Chord Engine Mode & Memory Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Chord Mode selector
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "MODE:",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    com.example.engine.ChordRecognitionMode.values().forEach { mode ->
                        val isSel = state.chordRecognitionMode == mode
                        Button(
                            onClick = { controller.setChordRecognitionMode(mode) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) NeonCyan else Color(0xFF262C36)
                            ),
                            modifier = Modifier.height(26.dp).testTag("chord_mode_${mode.name.lowercase()}"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = when (mode) {
                                    com.example.engine.ChordRecognitionMode.FINGERED -> "FINGERED"
                                    com.example.engine.ChordRecognitionMode.ONE_FINGER -> "1-FINGER"
                                    com.example.engine.ChordRecognitionMode.FULL_KEYBOARD -> "FULL KB"
                                },
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.Black else Color.LightGray
                            )
                        }
                    }
                }

                // Split & Memory toggles
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = { controller.toggleSplit() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isSplitEnabled) AmberActive else Color(0xFF262C36)
                        ),
                        modifier = Modifier.height(26.dp).testTag("split_toggle_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = if (state.isSplitEnabled) "SPLIT: ON" else "SPLIT: OFF",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.isSplitEnabled) Color.Black else Color.LightGray
                        )
                    }

                    Button(
                        onClick = { controller.toggleChordMemory() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isChordMemoryEnabled) EmeraldGood else Color(0xFF262C36)
                        ),
                        modifier = Modifier.height(26.dp).testTag("chord_memory_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = if (state.isChordMemoryEnabled) "MEMORY: ON" else "MEMORY: OFF",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.isChordMemoryEnabled) Color.Black else Color.LightGray
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Pa4xSetManagerPanel(
    controller: PerformanceController,
    state: WorkstationState
) {
    val pkg = state.activeSetPackage

    Card(
        colors = CardDefaults.cardColors(containerColor = PanelSurface),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth().testTag("pa4x_set_manager_panel")
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Folder,
                        contentDescription = "SET Library",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "KORG Pa4X SET COMPATIBILITY",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Set Status Badge
                    Surface(
                        color = if (pkg?.validationReport?.isValid == true) EmeraldGood.copy(alpha = 0.2f) else AmberActive.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (pkg?.validationReport?.isValid == true) EmeraldGood else AmberActive)
                    ) {
                        Text(
                            text = if (pkg?.validationReport?.isValid == true) "PA4X VERIFIED" else "CHECK SET",
                            color = if (pkg?.validationReport?.isValid == true) EmeraldGood else AmberActive,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Reload demo set button
                    Button(
                        onClick = { controller.loadDemoPa4xSet() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262C36)),
                        modifier = Modifier.height(24.dp).testTag("reload_demo_set_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                    ) {
                        Text("RESET DEMO", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = NeonCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Metadata summary card
            Surface(
                color = DisplayBackground,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222630)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = pkg?.metadata?.name ?: "No Set Loaded",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${pkg?.metadata?.targetModel ?: "KORG Pa4X"} • ${pkg?.styles?.size ?: 0} Styles • ${pkg?.sounds?.size ?: 0} Sounds • ${pkg?.samples?.size ?: 0} Samples",
                            color = Color.LightGray,
                            fontSize = 9.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "DEPS: ${pkg?.dependencyReport?.resolvedCount ?: 0} OK / ${pkg?.dependencyReport?.fallbackCount ?: 0} GM",
                            color = AmberActive,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "NTT: Parallel/Fixed/Bass",
                            color = Color.Gray,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Styles Selector Row
            Text(
                text = "STYLES IN SET (TAP TO LOAD):",
                color = Color.Gray,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                pkg?.styles?.forEach { style ->
                    val isSelected = (style.id == state.activeStyleId)
                    Button(
                        onClick = { controller.selectStyle(style.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) AmberActive else Color(0xFF262C36)
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(30.dp)
                            .testTag("style_button_${style.id}"),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = style.name.replace("Pa4X ", ""),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else Color.White,
                                maxLines = 1
                            )
                            Text(
                                text = "${style.tempoBpm} BPM",
                                fontSize = 7.sp,
                                color = if (isSelected) Color(0xFF331E00) else NeonCyan
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArrangerSectionButton(
    title: String,
    section: ArrangerSection,
    currentSection: ArrangerSection,
    testTag: String,
    onClick: () -> Unit
) {
    val isSelected = section == currentSection
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) NeonCyan else Color(0xFF262C36)
        ),
        modifier = Modifier.height(32.dp).testTag(testTag),
        contentPadding = PaddingValues(horizontal = 6.dp)
    ) {
        Text(
            text = title,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isSelected) Color.Black else Color.LightGray
        )
    }
}

@Composable
private fun MicrotonalMatrixPanel(
    controller: PerformanceController,
    state: WorkstationState
) {
    val noteNames = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    Surface(
        color = PanelSurface,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ORIENTAL / MICROTONAL MATRIX (-50 CENT QUARTER-TONE)",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = state.activeScalePreset.displayName,
                    color = AmberActive,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 12 chromatic note quarter-tone toggle keys
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                noteNames.forEachIndexed { index, name ->
                    val isDetuned = state.microtonalOffsets.getOrElse(index) { 0 } == -50
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .padding(horizontal = 1.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isDetuned) AmberActive else Color(0xFF252B35))
                            .border(1.dp, if (isDetuned) Color.White else PanelBorder, RoundedCornerShape(3.dp))
                            .clickable { controller.toggleMicrotonalKey(index) }
                            .testTag("quarter_tone_key_$index"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDetuned) Color.Black else Color.White
                            )
                            if (isDetuned) {
                                Text(
                                    text = "-50c",
                                    fontSize = 7.sp,
                                    color = Color.Black,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Scale Presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ScalePreset.values().forEach { preset ->
                    val isSelected = state.activeScalePreset == preset
                    AssistChip(
                        onClick = { controller.applyScalePreset(preset) },
                        label = { Text(preset.displayName.substringBefore(" ("), fontSize = 9.sp) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (isSelected) Color(0xFF37474F) else Color(0xFF1E232A),
                            labelColor = if (isSelected) NeonCyan else Color.Gray
                        ),
                        modifier = Modifier.height(26.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PerformanceKeyboardZone(
    controller: PerformanceController,
    state: WorkstationState
) {
    Surface(
        color = PanelSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Control Strip (Octave Shift & Pitch Wheel)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Octave controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { controller.onOctaveShiftChange(-1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3842)),
                        modifier = Modifier.size(36.dp).testTag("octave_down_button"),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-1", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "OCTAVE: ${if (state.octaveShift >= 0) "+${state.octaveShift}" else "${state.octaveShift}"}",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { controller.onOctaveShiftChange(1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E3842)),
                        modifier = Modifier.size(36.dp).testTag("octave_up_button"),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+1", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Wheels: Pitch Bend & Modulation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PitchBendWheel(
                        normalizedBend = state.pitchBendNormalized,
                        onBendChange = { controller.onPitchBendChange(it) },
                        onBendRelease = { controller.onPitchBendChange(0.0f) },
                        modifier = Modifier.testTag("pitch_bend_wheel")
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    ModulationWheel(
                        modulation = state.modulationWheel,
                        onModulationChange = { controller.onModulationChange(it) },
                        modifier = Modifier.testTag("modulation_wheel")
                    )
                }
            }

            // Piano Keys (2 Octaves: MIDI 60 to 83, shifted by octaveShift)
            WorkstationPiano(
                controller = controller,
                baseMidiNote = 60 + (state.octaveShift * 12),
                activeNotes = state.activeMidiNotes,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )
        }
    }
}

@Composable
private fun PitchBendWheel(
    normalizedBend: Float,
    onBendChange: (Float) -> Unit,
    onBendRelease: () -> Unit,
    modifier: Modifier = Modifier
) {
    var bendOffset by remember { mutableFloatStateOf(0f) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Text("PITCH", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(4.dp))
        Box(
            modifier = Modifier
                .width(100.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF15191E))
                .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        bendOffset = (bendOffset + delta / 50f).coerceIn(-1.0f, 1.0f)
                        onBendChange(bendOffset)
                    },
                    onDragStopped = {
                        bendOffset = 0f
                        onBendRelease()
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            // Center detent line
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color(0xFF37474F))
            )
            // Thumb
            Box(
                modifier = Modifier
                    .offset(x = (normalizedBend * 40).dp)
                    .size(width = 16.dp, height = 22.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AmberActive)
            )
        }
    }
}

@Composable
private fun ModulationWheel(
    modulation: Float,
    onModulationChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var modVal by remember { mutableFloatStateOf(modulation) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Text("MOD", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(4.dp))
        Box(
            modifier = Modifier
                .width(100.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF15191E))
                .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        modVal = (modVal + delta / 80f).coerceIn(0.0f, 1.0f)
                        onModulationChange(modVal)
                    }
                ),
            contentAlignment = Alignment.CenterStart
        ) {
            // Fill level
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = modulation.coerceIn(0.0f, 1.0f))
                    .background(Color(0xFF00ACC1).copy(alpha = 0.35f))
            )
            // Thumb
            Box(
                modifier = Modifier
                    .offset(x = (modulation * 80).dp)
                    .size(width = 16.dp, height = 22.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(NeonCyan)
            )
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun WorkstationPiano(
    controller: PerformanceController,
    baseMidiNote: Int,
    activeNotes: Set<Int>,
    modifier: Modifier = Modifier
) {
    // 2 octaves = 24 semitones (14 white keys: C, D, E, F, G, A, B, C, D, E, F, G, A, B)
    val whiteOffsets = listOf(0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 23)
    val blackKeyPositions = mapOf(
        0 to 1,   // C#
        1 to 3,   // D#
        3 to 6,   // F#
        4 to 8,   // G#
        5 to 10,  // A#
        7 to 13,  // C# (octave 2)
        8 to 15,  // D# (octave 2)
        10 to 18, // F# (octave 2)
        11 to 20, // G# (octave 2)
        12 to 22  // A# (octave 2)
    )

    // Centralized Pointer Registry to prevent stuck keys and ensure perfect Note-On/Off lifecycle routing
    val activePointers = remember { mutableStateMapOf<Int, Int>() }
    val octaveShift = (baseMidiNote - 60) / 12

    BoxWithConstraints(
        modifier = modifier
            .background(Color(0xFF0F1115))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        val totalWhiteKeys = whiteOffsets.size
        val whiteKeyWidth = maxWidth / totalWhiteKeys
        val blackKeyWidth = whiteKeyWidth * 0.65f
        val blackKeyHeight = maxHeight * 0.62f

        val density = LocalDensity.current
        val totalWidthPx = with(density) { maxWidth.toPx() }
        val totalHeightPx = with(density) { maxHeight.toPx() }
        val whiteKeyWidthPx = totalWidthPx / 14f
        val blackKeyWidthPx = whiteKeyWidthPx * 0.65f
        val blackKeyHeightPx = totalHeightPx * 0.62f

        // One centralized PointerInput box on top of the key drawings that intercepts and processes coordinates
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInteropFilter { motionEvent ->
                    // Coordinate resolver: maps (x, y) coordinates in pixels to MIDI notes
                    fun resolveMidiNoteAt(x: Float, y: Float): Int {
                        if (y >= 0f && y <= blackKeyHeightPx) {
                            for ((whiteIndex, semitoneOffset) in blackKeyPositions) {
                                val xOffsetPx = (whiteKeyWidthPx * (whiteIndex + 1)) - (blackKeyWidthPx / 2f)
                                if (x >= xOffsetPx && x <= xOffsetPx + blackKeyWidthPx) {
                                    return baseMidiNote + semitoneOffset
                                }
                            }
                        }
                        val whiteIndex = (x / whiteKeyWidthPx).toInt().coerceIn(0, 13)
                        return baseMidiNote + whiteOffsets[whiteIndex]
                    }

                    when (motionEvent.actionMasked) {
                        MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                            val index = motionEvent.actionIndex
                            val pointerId = motionEvent.getPointerId(index)
                            val x = motionEvent.getX(index)
                            val y = motionEvent.getY(index)
                            val note = resolveMidiNoteAt(x, y)
                            val unshiftedNote = note - octaveShift * 12

                            // Centralized filtering: only trigger Note-On if not already held by another pointer
                            val isAlreadyHeld = activePointers.values.contains(unshiftedNote)
                            activePointers[pointerId] = unshiftedNote

                            if (!isAlreadyHeld) {
                                val velocity = 90 + ((y / totalHeightPx) * 35).toInt().coerceIn(0, 37)
                                controller.onNoteOn(unshiftedNote, velocity)
                            }
                        }
                        MotionEvent.ACTION_MOVE -> {
                            for (i in 0 until motionEvent.pointerCount) {
                                val pointerId = motionEvent.getPointerId(i)
                                val x = motionEvent.getX(i)
                                val y = motionEvent.getY(i)
                                val note = resolveMidiNoteAt(x, y)
                                val unshiftedNote = note - octaveShift * 12
                                val oldUnshiftedNote = activePointers[pointerId]

                                if (oldUnshiftedNote != null && oldUnshiftedNote != unshiftedNote) {
                                    // Glissando transition: update registry first
                                    activePointers[pointerId] = unshiftedNote

                                    // Release old note ONLY if no other active pointer is holding it
                                    val isOldStillHeld = activePointers.values.contains(oldUnshiftedNote)
                                    if (!isOldStillHeld) {
                                        controller.onNoteOff(oldUnshiftedNote)
                                    }

                                    // Trigger new note ONLY if no other active pointer is already holding it
                                    val isNewAlreadyHeld = activePointers.any { (id, n) -> id != pointerId && n == unshiftedNote }
                                    if (!isNewAlreadyHeld) {
                                        val velocity = 90 + ((y / totalHeightPx) * 35).toInt().coerceIn(0, 37)
                                        controller.onNoteOn(unshiftedNote, velocity)
                                    }
                                } else if (oldUnshiftedNote == null) {
                                    val isNewAlreadyHeld = activePointers.values.contains(unshiftedNote)
                                    activePointers[pointerId] = unshiftedNote
                                    if (!isNewAlreadyHeld) {
                                        val velocity = 90 + ((y / totalHeightPx) * 35).toInt().coerceIn(0, 37)
                                        controller.onNoteOn(unshiftedNote, velocity)
                                    }
                                }
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                            val index = motionEvent.actionIndex
                            val pointerId = motionEvent.getPointerId(index)
                            val unshiftedNote = activePointers[pointerId]
                            if (unshiftedNote != null) {
                                activePointers.remove(pointerId)
                                // Release note ONLY if no other active pointer is holding it
                                val isStillHeld = activePointers.values.contains(unshiftedNote)
                                if (!isStillHeld) {
                                    controller.onNoteOff(unshiftedNote)
                                }
                            }
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            // Turn off all notes currently registered across all active pointers
                            activePointers.values.distinct().forEach { unshiftedNote ->
                                controller.onNoteOff(unshiftedNote)
                            }
                            activePointers.clear()
                        }
                    }
                    true
                }
        ) {
            // 1. Render White Keys
            Row(modifier = Modifier.fillMaxSize()) {
                whiteOffsets.forEachIndexed { index, semitoneOffset ->
                    val midiNote = baseMidiNote + semitoneOffset
                    val isPressed = activeNotes.contains(midiNote)
                    val keyColor by animateColorAsState(if (isPressed) KeyWhitePressed else KeyWhite, label = "white_key")

                    Box(
                        modifier = Modifier
                            .width(whiteKeyWidth)
                            .fillMaxHeight()
                            .padding(horizontal = 1.dp)
                            .clip(RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                            .background(keyColor)
                            .border(1.dp, Color(0xFFB0BEC5), RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                            .testTag("keyboard_key_$midiNote"),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        val noteLabel = getMidiNoteName(midiNote)
                        Text(
                            text = noteLabel,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF37474F),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
            }

            // 2. Render Black Keys (positioned on top)
            blackKeyPositions.forEach { (whiteKeyIndex, semitoneOffset) ->
                val midiNote = baseMidiNote + semitoneOffset
                val isPressed = activeNotes.contains(midiNote)
                val keyColor by animateColorAsState(if (isPressed) KeyBlackPressed else KeyBlack, label = "black_key")

                val xOffset = (whiteKeyWidth * (whiteKeyIndex + 1)) - (blackKeyWidth / 2)

                Box(
                    modifier = Modifier
                        .offset(x = xOffset)
                        .width(blackKeyWidth)
                        .height(blackKeyHeight)
                        .clip(RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                        .background(keyColor)
                        .border(1.dp, Color(0xFF37474F), RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                        .testTag("keyboard_key_$midiNote"),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    if (isPressed) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(NeonCyan)
                                .padding(bottom = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun getMidiNoteName(midiNote: Int): String {
    val names = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val octave = (midiNote / 12) - 1
    val name = names[midiNote % 12]
    return "$name$octave"
}
