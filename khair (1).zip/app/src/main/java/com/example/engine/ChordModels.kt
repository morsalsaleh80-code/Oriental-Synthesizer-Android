package com.example.engine

/**
 * Root note enumeration for musical chords with standard chromatic representations.
 */
enum class NoteName(val pitchClass: Int, val standardName: String) {
    C(0, "C"),
    C_SHARP(1, "C#"),
    D(2, "D"),
    D_SHARP(3, "D#"),
    E(4, "E"),
    F(5, "F"),
    F_SHARP(6, "F#"),
    G(7, "G"),
    G_SHARP(8, "G#"),
    A(9, "A"),
    A_SHARP(10, "A#"),
    B(11, "B");

    companion object {
        fun fromPitchClass(pitchClass: Int): NoteName {
            val normalized = ((pitchClass % 12) + 12) % 12
            return values()[normalized]
        }
    }
}

/**
 * Harmonic qualities recognized by the Workstation Arranger Chord Engine.
 */
enum class ChordQuality(
    val symbol: String,
    val intervals: IntArray,
    val displayName: String
) {
    MAJOR("", intArrayOf(0, 4, 7), "Major"),
    MINOR("m", intArrayOf(0, 3, 7), "Minor"),
    DOMINANT_7TH("7", intArrayOf(0, 4, 7, 10), "7th"),
    MAJOR_7TH("Maj7", intArrayOf(0, 4, 7, 11), "Major 7th"),
    MINOR_7TH("m7", intArrayOf(0, 3, 7, 10), "Minor 7th"),
    DIMINISHED("dim", intArrayOf(0, 3, 6), "Diminished"),
    DIMINISHED_7TH("dim7", intArrayOf(0, 3, 6, 9), "Diminished 7th"),
    HALF_DIMINISHED("m7b5", intArrayOf(0, 3, 6, 10), "Half-Diminished"),
    AUGMENTED("aug", intArrayOf(0, 4, 8), "Augmented"),
    SUSPENDED_4TH("sus4", intArrayOf(0, 5, 7), "Sus4"),
    SUSPENDED_2ND("sus2", intArrayOf(0, 2, 7), "Sus2"),
    ADD_9TH("add9", intArrayOf(0, 4, 7, 14), "Add9"),
    MAJOR_6TH("6", intArrayOf(0, 4, 7, 9), "6th"),
    MINOR_6TH("m6", intArrayOf(0, 3, 7, 9), "Minor 6th"),
    POWER_5TH("5", intArrayOf(0, 7), "Power 5th");

    /**
     * Bitmask representation of relative pitch classes within an octave (0..11)
     */
    val intervalMask: Int = intervals.fold(0) { mask, interval ->
        mask or (1 shl (interval % 12))
    }
}

/**
 * Recognized Chord specification with root, quality, and bass note for slash chords.
 */
data class RecognizedChord(
    val root: NoteName,
    val quality: ChordQuality,
    val bass: NoteName = root,
    val activeNotes: List<Int> = emptyList()
) {
    val isSlashChord: Boolean = root != bass

    val formattedName: String
        get() = if (isSlashChord) {
            "${root.standardName}${quality.symbol}/${bass.standardName}"
        } else {
            "${root.standardName}${quality.symbol}"
        }

    val fullDisplayName: String
        get() = if (isSlashChord) {
            "${root.standardName} ${quality.displayName} / ${bass.standardName}"
        } else {
            "${root.standardName} ${quality.displayName}"
        }

    companion object {
        val NO_CHORD = RecognizedChord(
            root = NoteName.C,
            quality = ChordQuality.MAJOR,
            bass = NoteName.C,
            activeNotes = emptyList()
        )
    }
}

/**
 * Operating mode for arranger chord detection.
 */
enum class ChordRecognitionMode(val displayName: String) {
    FINGERED("Fingered (Standard)"),
    ONE_FINGER("One-Finger (EZ)"),
    FULL_KEYBOARD("Full Keyboard")
}
