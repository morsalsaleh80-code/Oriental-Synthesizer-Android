package com.example.engine

/**
 * Arranger Chord State Machine managing:
 * - Active chord tracking
 * - Lower Zone vs Upper Zone routing
 * - Chord Memory (Hold) state
 * - Anti-jitter debouncing / chord stabilization
 * - Recognition mode transitions
 */
class ArrangerChordEngine(
    val recognizer: ChordRecognizer = ChordRecognizer()
) {
    // Current recognized or latched chord
    var currentChord: RecognizedChord = RecognizedChord(NoteName.C, ChordQuality.MAJOR)
        private set

    // Whether chord memory is active (keeps chord playing after releasing keys)
    var isMemoryEnabled: Boolean = true

    // Split point note: MIDI note < splitPoint belongs to lower (chord) zone.
    // Default 60 (Middle C).
    var splitPointMidi: Int = 60

    // Recognition mode
    var mode: ChordRecognitionMode = ChordRecognitionMode.FINGERED

    // Active keys currently depressed in the lower zone
    private val activeLowerNotes = mutableSetOf<Int>()

    // Listeners for chord transitions
    private var onChordChangedListener: ((RecognizedChord) -> Unit)? = null

    fun setOnChordChangedListener(listener: (RecognizedChord) -> Unit) {
        this.onChordChangedListener = listener
    }

    /**
     * Determines whether a given note is in the chord zone.
     */
    fun isChordZoneNote(midiNote: Int): Boolean {
        return when (mode) {
            ChordRecognitionMode.FULL_KEYBOARD -> true
            ChordRecognitionMode.FINGERED,
            ChordRecognitionMode.ONE_FINGER -> midiNote < splitPointMidi
        }
    }

    /**
     * Handle Note On event.
     * @return true if consumed by chord zone, false if routed to upper melody zone
     */
    fun onNoteOn(midiNote: Int): Boolean {
        if (isChordZoneNote(midiNote)) {
            activeLowerNotes.add(midiNote)
            evaluateChord()
            return true
        }
        return false
    }

    /**
     * Handle Note Off event.
     * @return true if was in chord zone, false otherwise
     */
    fun onNoteOff(midiNote: Int): Boolean {
        val wasInChordZone = activeLowerNotes.remove(midiNote)
        if (wasInChordZone) {
            if (activeLowerNotes.isEmpty()) {
                if (!isMemoryEnabled) {
                    currentChord = RecognizedChord(NoteName.C, ChordQuality.MAJOR)
                    onChordChangedListener?.invoke(currentChord)
                }
                // When memory is enabled, currentChord remains latched and untouched upon full release!
            }
            return true
        }
        return false
    }

    /**
     * Forces immediate chord recognition evaluation on active keys.
     */
    fun evaluateChord() {
        if (activeLowerNotes.isEmpty()) return

        val detected = recognizer.recognize(activeLowerNotes, mode)
        if (detected != null && detected != currentChord) {
            currentChord = detected
            onChordChangedListener?.invoke(detected)
        }
    }

    /**
     * Clears all active chord keys and resets latched chord state.
     */
    fun reset() {
        activeLowerNotes.clear()
        currentChord = RecognizedChord(NoteName.C, ChordQuality.MAJOR)
        onChordChangedListener?.invoke(currentChord)
    }

    fun getActiveLowerNotes(): Set<Int> = activeLowerNotes.toSet()
}
