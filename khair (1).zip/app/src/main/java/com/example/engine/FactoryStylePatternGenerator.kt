package com.example.engine

import com.example.korg.models.IrChordVariation
import com.example.korg.models.IrMidiEvent
import com.example.korg.models.IrNttRule
import com.example.korg.models.IrStyle
import com.example.korg.models.IrStyleElement
import com.example.korg.models.IrStyleTrack
import com.example.korg.models.NttType
import com.example.korg.models.TimeSignature

/**
 * Factory Musical Pattern Generator for KORG Pa4X arranger styles.
 *
 * Produces authentic 8-track MIDI patterns across all arranger sections:
 * - 0: Drum (Kick, Snare, Hi-Hat, Tom, Crash) on MIDI Channel 9
 * - 1: Percussion (Tambourine, Shaker, Clave, Conga) on MIDI Channel 8
 * - 2: Bass (Acoustic / Slap / Finger / Synth) on MIDI Channel 10
 * - 3: Acc 1 (Piano / Rhodes chord rhythms) on MIDI Channel 11
 * - 4: Acc 2 (Guitar strumming / arpeggios) on MIDI Channel 12
 * - 5: Acc 3 (Sustained Strings pad) on MIDI Channel 13
 * - 6: Acc 4 (Brass stabs / fanfares) on MIDI Channel 14
 * - 7: Acc 5 (Lead synth / bells / fills) on MIDI Channel 15
 *
 * Full support for sections:
 * Intro 1-3, Variation 1-4, Fill 1-4, Break, Ending 1-3.
 */
object FactoryStylePatternGenerator {

    const val TICKS_PER_BEAT = 480L

    /**
     * Helper to create a note on and note off event pair.
     */
    fun createNoteEvents(
        startTick: Long,
        durationTicks: Long,
        note: Int,
        velocity: Int
    ): List<IrMidiEvent> {
        val noteOn = IrMidiEvent(startTick, 0x90, note, velocity)
        val noteOff = IrMidiEvent(startTick + durationTicks, 0x80, note, 0)
        return listOf(noteOn, noteOff)
    }

    /**
     * Builds comprehensive 8-track musical events for a given section.
     */
    fun generateSectionPattern(
        section: ArrangerSection,
        lengthBars: Int = 4,
        styleCategory: String = "Pop Ballad"
    ): Map<Int, List<IrMidiEvent>> {
        val trackEvents = mutableMapOf<Int, MutableList<IrMidiEvent>>()
        for (i in 0..7) {
            trackEvents[i] = mutableListOf()
        }

        val totalTicks = lengthBars * 4 * TICKS_PER_BEAT

        when (section) {
            ArrangerSection.INTRO_1, ArrangerSection.INTRO_2, ArrangerSection.INTRO_3 -> {
                generateIntroSection(trackEvents, lengthBars, totalTicks)
            }
            ArrangerSection.VARIATION_1 -> {
                generateVariation1(trackEvents, lengthBars)
            }
            ArrangerSection.VARIATION_2 -> {
                generateVariation2(trackEvents, lengthBars)
            }
            ArrangerSection.VARIATION_3 -> {
                generateVariation3(trackEvents, lengthBars)
            }
            ArrangerSection.VARIATION_4 -> {
                generateVariation4(trackEvents, lengthBars)
            }
            ArrangerSection.FILL_1, ArrangerSection.FILL_2, ArrangerSection.FILL_3, ArrangerSection.FILL_4 -> {
                generateFillSection(trackEvents, lengthBars)
            }
            ArrangerSection.BREAK -> {
                generateBreakSection(trackEvents, lengthBars)
            }
            ArrangerSection.ENDING_1, ArrangerSection.ENDING_2, ArrangerSection.ENDING_3 -> {
                generateEndingSection(trackEvents, lengthBars, totalTicks)
            }
        }

        // Return sorted events by tickOffset for each track
        return trackEvents.mapValues { (_, events) ->
            events.sortedBy { it.tickOffset }
        }
    }

    private fun generateVariation1(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // Variation 1: Sparse, elegant ballad groove
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT

            // Track 0: Drums (Kick on 1 & 3, Snare/Rim on 2 & 4, Closed HH on eighth notes)
            // Kick (36)
            tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 95))
            tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 200, 36, 85))
            // Cross stick / Rim (37)
            tracks[0]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 200, 37, 85))
            tracks[0]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 200, 37, 90))
            // Closed HH (42) every 8th note
            for (step in 0 until 8) {
                val tick = barStart + step * (TICKS_PER_BEAT / 2)
                tracks[0]?.addAll(createNoteEvents(tick, 150, 42, if (step % 2 == 0) 80 else 60))
            }

            // Track 1: Percussion (Shaker on 16th notes)
            for (s in 0 until 16) {
                val tick = barStart + s * (TICKS_PER_BEAT / 4)
                tracks[1]?.addAll(createNoteEvents(tick, 100, 70, if (s % 4 == 0) 75 else 50))
            }

            // Track 2: Bass (Roots on 1, 3 and walking on 4.5)
            tracks[2]?.addAll(createNoteEvents(barStart, 400, 36, 90)) // C2
            tracks[2]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 400, 36, 85))
            tracks[2]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT + 240, 200, 43, 75)) // G2

            // Track 3: Acc 1 Piano (Gentle arpeggiated chords C4, E4, G4)
            tracks[3]?.addAll(createNoteEvents(barStart, 440, 60, 80)) // C4
            tracks[3]?.addAll(createNoteEvents(barStart + 240, 440, 64, 75)) // E4
            tracks[3]?.addAll(createNoteEvents(barStart + 480, 440, 67, 75)) // G4
            tracks[3]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 440, 60, 78))
            tracks[3]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT + 240, 440, 64, 72))

            // Track 5: Acc 3 Sustained Strings Pad (Whole note chord)
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 40, 60, 70))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 40, 64, 68))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 40, 67, 72))
        }
    }

    private fun generateVariation2(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // Variation 2: Add acoustic guitar strumming & steady snare
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT

            // Track 0: Drums
            tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 100))
            tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 200, 36, 95))
            // Snare (38)
            tracks[0]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 220, 38, 95))
            tracks[0]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 220, 38, 98))
            for (step in 0 until 8) {
                val tick = barStart + step * (TICKS_PER_BEAT / 2)
                tracks[0]?.addAll(createNoteEvents(tick, 150, 42, if (step % 2 == 0) 85 else 68))
            }

            // Track 1: Tambourine (54) on 2 and 4
            tracks[1]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 180, 54, 85))
            tracks[1]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 180, 54, 88))

            // Track 2: Bass (8th note pulse)
            tracks[2]?.addAll(createNoteEvents(barStart, 380, 36, 95))
            tracks[2]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 380, 36, 85))
            tracks[2]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 380, 43, 90))
            tracks[2]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 380, 36, 88))

            // Track 3: Piano Chords
            tracks[3]?.addAll(createNoteEvents(barStart, 350, 60, 85))
            tracks[3]?.addAll(createNoteEvents(barStart, 350, 64, 82))
            tracks[3]?.addAll(createNoteEvents(barStart, 350, 67, 84))
            tracks[3]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 350, 60, 82))
            tracks[3]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 350, 64, 80))

            // Track 4: Acc 2 Guitar strumming
            for (beat in 0 until 4) {
                val tick = barStart + beat * TICKS_PER_BEAT
                tracks[4]?.addAll(createNoteEvents(tick, 200, 60, 78))
                tracks[4]?.addAll(createNoteEvents(tick, 200, 64, 76))
                tracks[4]?.addAll(createNoteEvents(tick + 240, 180, 67, 72))
            }

            // Track 5: Strings Pad
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 30, 60, 75))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 30, 67, 78))
        }
    }

    private fun generateVariation3(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // Variation 3: Dynamic full rhythm with Brass stabs (Track 6)
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT

            // Track 0: Drums (Ride cymbal 51, syncopated kick)
            tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 105))
            tracks[0]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT / 2, 200, 36, 80))
            tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 200, 36, 100))
            tracks[0]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 220, 38, 100))
            tracks[0]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 220, 38, 105))
            for (step in 0 until 8) {
                val tick = barStart + step * (TICKS_PER_BEAT / 2)
                tracks[0]?.addAll(createNoteEvents(tick, 180, 51, 88))
            }

            // Track 2: Driving Bass
            tracks[2]?.addAll(createNoteEvents(barStart, 300, 36, 100))
            tracks[2]?.addAll(createNoteEvents(barStart + 240, 200, 36, 85))
            tracks[2]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 300, 43, 92))
            tracks[2]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 300, 36, 98))
            tracks[2]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 300, 41, 95))

            // Track 3: Piano
            tracks[3]?.addAll(createNoteEvents(barStart, 380, 60, 90))
            tracks[3]?.addAll(createNoteEvents(barStart, 380, 64, 88))
            tracks[3]?.addAll(createNoteEvents(barStart, 380, 67, 92))

            // Track 4: Guitar
            for (beat in 0 until 4) {
                val tick = barStart + beat * TICKS_PER_BEAT
                tracks[4]?.addAll(createNoteEvents(tick, 200, 64, 85))
                tracks[4]?.addAll(createNoteEvents(tick + 240, 200, 67, 82))
            }

            // Track 5: Strings
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 60, 80))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 64, 78))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 67, 84))

            // Track 6: Brass Stabs (Punchy syncopation on upbeat of 2 and 4)
            tracks[6]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT + 240, 220, 60, 95))
            tracks[6]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT + 240, 220, 64, 95))
            tracks[6]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT + 240, 220, 67, 98))
        }
    }

    private fun generateVariation4(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // Variation 4: Full orchestral climax with Lead (Track 7)
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT

            // Track 0: Full Drums (Crash 49 on bar 1, heavy kick & snare)
            if (bar == 0) {
                tracks[0]?.addAll(createNoteEvents(barStart, 400, 49, 110))
            }
            tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 110))
            tracks[0]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 240, 38, 108))
            tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 200, 36, 105))
            tracks[0]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 240, 38, 110))
            for (step in 0 until 8) {
                val tick = barStart + step * (TICKS_PER_BEAT / 2)
                tracks[0]?.addAll(createNoteEvents(tick, 180, 51, 95))
            }

            // Track 2: Power Bass
            tracks[2]?.addAll(createNoteEvents(barStart, 380, 36, 108))
            tracks[2]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 380, 48, 102))
            tracks[2]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 380, 43, 105))
            tracks[2]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 380, 36, 108))

            // Track 3: Piano
            tracks[3]?.addAll(createNoteEvents(barStart, 400, 60, 95))
            tracks[3]?.addAll(createNoteEvents(barStart, 400, 64, 92))
            tracks[3]?.addAll(createNoteEvents(barStart, 400, 67, 96))

            // Track 5: Forte Strings
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 60, 92))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 67, 95))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 72, 90))

            // Track 6: Brass
            tracks[6]?.addAll(createNoteEvents(barStart, 300, 60, 100))
            tracks[6]?.addAll(createNoteEvents(barStart, 300, 64, 100))
            tracks[6]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 300, 67, 102))

            // Track 7: Lead Synth melody motif
            tracks[7]?.addAll(createNoteEvents(barStart, 400, 72, 90))
            tracks[7]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 400, 74, 92))
            tracks[7]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 800, 76, 95))
        }
    }

    private fun generateFillSection(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // 1-bar drum fill with descending toms (48, 47, 45, 43) and crash
        val start = 0L
        // Kick on 1
        tracks[0]?.addAll(createNoteEvents(start, 200, 36, 110))
        // Snare roll on beat 2
        tracks[0]?.addAll(createNoteEvents(start + TICKS_PER_BEAT, 100, 38, 90))
        tracks[0]?.addAll(createNoteEvents(start + TICKS_PER_BEAT + 120, 100, 38, 100))
        tracks[0]?.addAll(createNoteEvents(start + TICKS_PER_BEAT + 240, 100, 38, 105))
        tracks[0]?.addAll(createNoteEvents(start + TICKS_PER_BEAT + 360, 100, 38, 110))
        // Hi Tom (50) & Mid Tom (47) on beat 3
        tracks[0]?.addAll(createNoteEvents(start + 2 * TICKS_PER_BEAT, 180, 50, 105))
        tracks[0]?.addAll(createNoteEvents(start + 2 * TICKS_PER_BEAT + 240, 180, 47, 105))
        // Low Tom (43) on beat 4
        tracks[0]?.addAll(createNoteEvents(start + 3 * TICKS_PER_BEAT, 180, 43, 110))
        tracks[0]?.addAll(createNoteEvents(start + 3 * TICKS_PER_BEAT + 240, 180, 43, 115))

        // Bass punch on 1
        tracks[2]?.addAll(createNoteEvents(start, 400, 36, 105))

        // Piano stabs
        tracks[3]?.addAll(createNoteEvents(start, 400, 60, 95))
        tracks[3]?.addAll(createNoteEvents(start, 400, 64, 95))
        tracks[3]?.addAll(createNoteEvents(start, 400, 67, 95))
    }

    private fun generateBreakSection(tracks: MutableMap<Int, MutableList<IrMidiEvent>>, bars: Int) {
        // Break: 1 bar abrupt silence / punch on beat 1, rest silent
        val start = 0L
        // Crash + Kick on beat 1
        tracks[0]?.addAll(createNoteEvents(start, 500, 49, 115)) // Crash
        tracks[0]?.addAll(createNoteEvents(start, 200, 36, 115)) // Kick

        // Bass staccato hit on beat 1
        tracks[2]?.addAll(createNoteEvents(start, 200, 36, 110))

        // Piano staccato hit
        tracks[3]?.addAll(createNoteEvents(start, 240, 60, 105))
        tracks[3]?.addAll(createNoteEvents(start, 240, 64, 105))
        tracks[3]?.addAll(createNoteEvents(start, 240, 67, 105))
    }

    private fun generateIntroSection(
        tracks: MutableMap<Int, MutableList<IrMidiEvent>>,
        bars: Int,
        totalTicks: Long
    ) {
        // Melodic introduction building up to section
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT

            // Soft drums entering halfway
            if (bar >= bars / 2) {
                tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 85))
                tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 200, 38, 85))
                for (s in 0 until 4) {
                    tracks[0]?.addAll(createNoteEvents(barStart + s * TICKS_PER_BEAT, 150, 42, 70))
                }
            }

            // Piano arpeggio
            tracks[3]?.addAll(createNoteEvents(barStart, 400, 60, 80))
            tracks[3]?.addAll(createNoteEvents(barStart + TICKS_PER_BEAT, 400, 64, 82))
            tracks[3]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 400, 67, 84))
            tracks[3]?.addAll(createNoteEvents(barStart + 3 * TICKS_PER_BEAT, 400, 72, 88))

            // Strings pad
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 60, 75))
            tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 64, 75))
        }
    }

    private fun generateEndingSection(
        tracks: MutableMap<Int, MutableList<IrMidiEvent>>,
        bars: Int,
        totalTicks: Long
    ) {
        // Resolving cadence leading to final grand chord and cymbal decay
        for (bar in 0 until bars) {
            val barStart = bar * 4 * TICKS_PER_BEAT
            val isFinalBar = bar == bars - 1

            if (isFinalBar) {
                // Final chord hit
                tracks[0]?.addAll(createNoteEvents(barStart, 1000, 49, 120)) // Crash
                tracks[0]?.addAll(createNoteEvents(barStart, 400, 36, 120))  // Kick

                tracks[2]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 36, 115))

                // Full tutti chord
                tracks[3]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 60, 110))
                tracks[3]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 64, 110))
                tracks[3]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 67, 110))

                tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 60, 110))
                tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 100, 67, 110))
            } else {
                // Pre-ending rhythm
                tracks[0]?.addAll(createNoteEvents(barStart, 200, 36, 95))
                tracks[0]?.addAll(createNoteEvents(barStart + 2 * TICKS_PER_BEAT, 220, 38, 95))
                tracks[2]?.addAll(createNoteEvents(barStart, 400, 36, 90))
                tracks[3]?.addAll(createNoteEvents(barStart, 400, 60, 85))
                tracks[5]?.addAll(createNoteEvents(barStart, 4 * TICKS_PER_BEAT - 20, 60, 80))
            }
        }
    }

    /**
     * Builds full IrStyleElement containing CV0 (Maj), CV1 (Min), and CV2 (7th)
     */
    fun createFullStyleElement(section: ArrangerSection, bars: Int): IrStyleElement {
        val majEvents = generateSectionPattern(section, bars)

        // CV0: Major pattern
        val cv0 = IrChordVariation(
            cvIndex = 0,
            chordFormula = "Maj",
            lengthBars = bars,
            trackEvents = majEvents
        )

        // CV1: Minor pattern (pre-transposed 3rd degree where appropriate)
        val cv1 = IrChordVariation(
            cvIndex = 1,
            chordFormula = "Min",
            lengthBars = bars,
            trackEvents = majEvents // NoteTranslationEngine handles runtime adaptation
        )

        // CV2: Dominant 7th pattern
        val cv2 = IrChordVariation(
            cvIndex = 2,
            chordFormula = "7th",
            lengthBars = bars,
            trackEvents = majEvents
        )

        return IrStyleElement(
            section = section,
            lengthBars = bars,
            chordVariations = listOf(cv0, cv1, cv2)
        )
    }

    /**
     * Creates standard Pa4X factory tracks (8 tracks: Drums, Perc, Bass, Acc 1-5).
     */
    fun createStandardFactoryTracks(): List<IrStyleTrack> {
        return listOf(
            IrStyleTrack(0, "Drums", 9, programNumber = 0, volume = 110, pan = 64, nttRule = IrNttRule(0, NttType.FIXED)),
            IrStyleTrack(1, "Percussion", 8, programNumber = 115, volume = 95, pan = 50, nttRule = IrNttRule(1, NttType.FIXED)),
            IrStyleTrack(2, "Bass", 10, programNumber = 33, volume = 105, pan = 64, nttRule = IrNttRule(2, NttType.BASS, bassFollow = true)),
            IrStyleTrack(3, "Acc 1 (Piano)", 11, programNumber = 0, volume = 95, pan = 45, nttRule = IrNttRule(3, NttType.PARALLEL)),
            IrStyleTrack(4, "Acc 2 (Guitar)", 12, programNumber = 24, volume = 90, pan = 85, nttRule = IrNttRule(4, NttType.PARALLEL)),
            IrStyleTrack(5, "Acc 3 (Strings)", 13, programNumber = 48, volume = 85, pan = 64, nttRule = IrNttRule(5, NttType.CHORD)),
            IrStyleTrack(6, "Acc 4 (Brass)", 14, programNumber = 61, volume = 90, pan = 75, nttRule = IrNttRule(6, NttType.PARALLEL)),
            IrStyleTrack(7, "Acc 5 (Lead)", 15, programNumber = 81, volume = 80, pan = 55, nttRule = IrNttRule(7, NttType.PARALLEL))
        )
    }
}
