package com.example.engine

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioDiagnosticsData
import com.example.audio.NativeAudioBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ArrangerSection {
    INTRO_1, INTRO_2, INTRO_3,
    VARIATION_1, VARIATION_2, VARIATION_3, VARIATION_4,
    FILL_1, FILL_2, FILL_3, FILL_4,
    BREAK,
    ENDING_1, ENDING_2, ENDING_3
}

enum class ScalePreset(val displayName: String, val offsets: IntArray) {
    EQUAL_TEMPERAMENT("12-TET (Standard)", intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
    BAYATI_D("Bayati on D (E & B -50c)", intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, 0, -50)),
    RAST_C("Rast on C (E & B -50c)", intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, 0, -50)),
    HIJAZ_D("Hijaz on D", intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
    SIKAH_E("Sikah on E (E & B -50c)", intArrayOf(0, 0, 0, 0, -50, 0, 0, 0, 0, 0, 0, -50))
}

data class WorkstationState(
    val isAudioEngineActive: Boolean = false,
    val masterVolume: Float = 0.8f,
    val octaveShift: Int = 0,
    val pitchBendNormalized: Float = 0.0f,
    val microtonalOffsets: List<Int> = List(12) { 0 },
    val activeScalePreset: ScalePreset = ScalePreset.EQUAL_TEMPERAMENT,
    val activeMidiNotes: Set<Int> = emptySet(),
    val tempoBpm: Int = 120,
    val currentArrangerSection: ArrangerSection = ArrangerSection.VARIATION_1,
    val isSynchroStartEnabled: Boolean = false,
    val isSynchroStopEnabled: Boolean = false,
    val isArrangerPlaying: Boolean = false,
    val sequencerBar: Int = 1,
    val sequencerBeat: Int = 1,
    val modulationWheel: Float = 0.0f,
    val filterCutoffHz: Float = 4500.0f,
    val filterResonance: Float = 0.25f,
    val velocityCurve: Int = 0, // 0: Linear, 1: Soft, 2: Hard, 3: Fixed
    val diagnostics: AudioDiagnosticsData = AudioDiagnosticsData(),
    // Phase 4: Chord & Arranger Core State
    val recognizedChord: RecognizedChord = RecognizedChord(NoteName.C, ChordQuality.MAJOR),
    val chordRecognitionMode: ChordRecognitionMode = ChordRecognitionMode.FINGERED,
    val isChordMemoryEnabled: Boolean = true,
    val splitPointMidi: Int = 60,
    val isSplitEnabled: Boolean = true,
    // Phase 5: Pa4X SET & Style Resource State
    val loadedSets: List<com.example.korg.models.SetSummary> = emptyList(),
    val activeSetPackage: com.example.korg.models.Pa4xSetPackage? = null,
    val activeStyleId: String = "style_pop_ballad",
    val activeStyleName: String = "Pa4X Pop Ballad",
    val importProgress: com.example.korg.models.ImportProgress? = null,
    val isSetManagerOpen: Boolean = false,
    val isPcmPlaybackActive: Boolean = false
)

class PerformanceController(
    val audioBridge: com.example.audio.AudioEventDispatcher = NativeAudioBridge
) : ViewModel() {

    private val chordEngine = ArrangerChordEngine()
    val setRepository: com.example.korg.repository.SetRepository = com.example.korg.repository.SetRepositoryImpl()
    val sequencer = StyleSequencer(
        audioBridge = audioBridge,
        nttEngine = NoteTranslationEngine(),
        scope = viewModelScope
    )

    private val _uiState = MutableStateFlow(WorkstationState())
    val uiState: StateFlow<WorkstationState> = _uiState.asStateFlow()

    init {
        initEngine()
        initChordEngine()
        initSequencerObservers()
        initSetRepositoryObserver()
        startTelemetryLoop()
    }

    private fun initSequencerObservers() {
        viewModelScope.launch {
            sequencer.isPlaying.collect { playing ->
                _uiState.value = _uiState.value.copy(isArrangerPlaying = playing)
            }
        }
        viewModelScope.launch {
            sequencer.currentSection.collect { section ->
                _uiState.value = _uiState.value.copy(currentArrangerSection = section)
            }
        }
        viewModelScope.launch {
            sequencer.currentBar.collect { bar ->
                _uiState.value = _uiState.value.copy(sequencerBar = bar)
            }
        }
        viewModelScope.launch {
            sequencer.currentBeat.collect { beat ->
                _uiState.value = _uiState.value.copy(sequencerBeat = beat)
            }
        }
    }

    private fun initSetRepositoryObserver() {
        viewModelScope.launch {
            setRepository.loadedSets.collect { sets ->
                _uiState.value = _uiState.value.copy(loadedSets = sets)
            }
        }
        viewModelScope.launch {
            setRepository.activeSetPackage.collect { pkg ->
                if (pkg != null) {
                    val firstStyle = pkg.styles.firstOrNull()
                    val currentStyleValid = pkg.styles.any { it.id == _uiState.value.activeStyleId }
                    val newStyle = if (currentStyleValid) {
                        pkg.styles.first { it.id == _uiState.value.activeStyleId }
                    } else {
                        firstStyle
                    }
                    if (newStyle != null) {
                        sequencer.setStyle(newStyle)
                    }
                    val pcmSample = pkg.samples.firstOrNull { it.pcmData != null }
                    var pcmLoaded = false
                    if (pcmSample != null && audioBridge is NativeAudioBridge && NativeAudioBridge.isAvailable) {
                        pcmLoaded = NativeAudioBridge.loadIrSample(pcmSample, slot = 0)
                    }
                    _uiState.value = _uiState.value.copy(
                        activeSetPackage = pkg,
                        activeStyleId = newStyle?.id ?: "default",
                        activeStyleName = newStyle?.name ?: "Standard Style",
                        tempoBpm = newStyle?.tempoBpm ?: _uiState.value.tempoBpm,
                        isPcmPlaybackActive = pcmLoaded
                    )
                }
            }
        }
        viewModelScope.launch {
            setRepository.importProgress.collect { progress ->
                _uiState.value = _uiState.value.copy(importProgress = progress)
            }
        }
    }

    private fun initChordEngine() {
        chordEngine.splitPointMidi = _uiState.value.splitPointMidi
        chordEngine.mode = _uiState.value.chordRecognitionMode
        chordEngine.isMemoryEnabled = _uiState.value.isChordMemoryEnabled
        chordEngine.setOnChordChangedListener { chord ->
            _uiState.value = _uiState.value.copy(recognizedChord = chord)
            sequencer.setChord(chord)
        }
        sequencer.setChord(chordEngine.currentChord)
    }

    fun initEngine() {
        if (audioBridge is NativeAudioBridge && NativeAudioBridge.isAvailable) {
            NativeAudioBridge.initEngine()
            val started = NativeAudioBridge.startEngine()
            _uiState.value = _uiState.value.copy(isAudioEngineActive = started)
            audioBridge.setMasterVolume(_uiState.value.masterVolume)

            val pcmSample = _uiState.value.activeSetPackage?.samples?.firstOrNull { it.pcmData != null }
            if (pcmSample != null) {
                val pcmLoaded = NativeAudioBridge.loadIrSample(pcmSample, slot = 0)
                _uiState.value = _uiState.value.copy(isPcmPlaybackActive = pcmLoaded)
            }
        } else if (audioBridge.isAvailable) {
            _uiState.value = _uiState.value.copy(isAudioEngineActive = true)
            audioBridge.setMasterVolume(_uiState.value.masterVolume)
        }
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                if (_uiState.value.isAudioEngineActive) {
                    val diag = NativeAudioBridge.pollDiagnostics()
                    _uiState.value = _uiState.value.copy(diagnostics = diag)
                }
                delay(33L) // ~30 Hz UI refresh rate
            }
        }
    }

    fun toggleAudioEngine() {
        val currentState = _uiState.value.isAudioEngineActive
        if (currentState) {
            if (audioBridge is NativeAudioBridge && NativeAudioBridge.isAvailable) {
                NativeAudioBridge.stopEngine()
            }
            _uiState.value = _uiState.value.copy(isAudioEngineActive = false)
        } else {
            val started = if (audioBridge is NativeAudioBridge && NativeAudioBridge.isAvailable) {
                NativeAudioBridge.startEngine()
            } else {
                audioBridge.isAvailable
            }
            _uiState.value = _uiState.value.copy(isAudioEngineActive = started)
        }
    }

    fun onNoteOn(noteNumber: Int, velocity: Int) {
        val shiftedNote = (noteNumber + _uiState.value.octaveShift * 12).coerceIn(0, 127)
        val noteClass = shiftedNote % 12
        val centOffset = _uiState.value.microtonalOffsets.getOrElse(noteClass) { 0 }.toFloat()

        // Track chord detection in arranger engine
        if (_uiState.value.isSplitEnabled) {
            val isChordKey = chordEngine.onNoteOn(shiftedNote)
            // Synchro Start: if enabled and sequencer is stopped, striking a chord key triggers playback
            if (isChordKey && _uiState.value.isSynchroStartEnabled && !_uiState.value.isArrangerPlaying) {
                startArrangerPlayback()
            }
        }

        audioBridge.sendNoteOn(shiftedNote, velocity, channel = 0, centOffset = centOffset)

        val updatedNotes = _uiState.value.activeMidiNotes + shiftedNote
        _uiState.value = _uiState.value.copy(activeMidiNotes = updatedNotes)
    }

    fun onNoteOff(noteNumber: Int) {
        val shiftedNote = (noteNumber + _uiState.value.octaveShift * 12).coerceIn(0, 127)

        if (_uiState.value.isSplitEnabled) {
            val wasChordKey = chordEngine.onNoteOff(shiftedNote)
            // Synchro Stop: if enabled and all chord keys released, stop playback
            if (wasChordKey && _uiState.value.isSynchroStopEnabled && _uiState.value.isArrangerPlaying && chordEngine.getActiveLowerNotes().isEmpty()) {
                stopArrangerPlayback()
            }
        }

        audioBridge.sendNoteOff(shiftedNote, channel = 0)

        val updatedNotes = _uiState.value.activeMidiNotes - shiftedNote
        _uiState.value = _uiState.value.copy(activeMidiNotes = updatedNotes)
    }

    fun setChordRecognitionMode(mode: ChordRecognitionMode) {
        chordEngine.mode = mode
        _uiState.value = _uiState.value.copy(chordRecognitionMode = mode)
        chordEngine.evaluateChord()
    }

    fun toggleChordMemory() {
        val nextMemory = !_uiState.value.isChordMemoryEnabled
        chordEngine.isMemoryEnabled = nextMemory
        _uiState.value = _uiState.value.copy(isChordMemoryEnabled = nextMemory)
    }

    fun toggleSplit() {
        val nextSplit = !_uiState.value.isSplitEnabled
        _uiState.value = _uiState.value.copy(isSplitEnabled = nextSplit)
    }

    fun setSplitPoint(splitNote: Int) {
        val clamped = splitNote.coerceIn(36, 84)
        chordEngine.splitPointMidi = clamped
        _uiState.value = _uiState.value.copy(splitPointMidi = clamped)
    }

    fun onPitchBendChange(bendNormalized: Float) {
        val clamped = bendNormalized.coerceIn(-1.0f, 1.0f)
        _uiState.value = _uiState.value.copy(pitchBendNormalized = clamped)
        // 2 semitone range
        audioBridge.sendPitchBend(clamped * 2.0f)
    }

    fun onModulationChange(modValue: Float) {
        val clamped = modValue.coerceIn(0.0f, 1.0f)
        _uiState.value = _uiState.value.copy(modulationWheel = clamped)
        audioBridge.sendModulation(clamped)
    }

    fun onFilterCutoffChange(cutoffHz: Float) {
        val clamped = cutoffHz.coerceIn(50.0f, 16000.0f)
        _uiState.value = _uiState.value.copy(filterCutoffHz = clamped)
        audioBridge.sendParamChange(paramId = 1, paramValueInt = 0, paramValueFloat = clamped)
    }

    fun onFilterResonanceChange(resonance: Float) {
        val clamped = resonance.coerceIn(0.0f, 0.95f)
        _uiState.value = _uiState.value.copy(filterResonance = clamped)
        audioBridge.sendParamChange(paramId = 2, paramValueInt = 0, paramValueFloat = clamped)
    }

    fun onVelocityCurveChange(curveType: Int) {
        val clamped = curveType.coerceIn(0, 3)
        _uiState.value = _uiState.value.copy(velocityCurve = clamped)
        audioBridge.sendParamChange(paramId = 7, paramValueInt = clamped, paramValueFloat = 0.0f)
    }

    fun onOctaveShiftChange(delta: Int) {
        val newOctave = (_uiState.value.octaveShift + delta).coerceIn(-3, 3)
        if (newOctave != _uiState.value.octaveShift) {
            panicAllNotesOff()
            _uiState.value = _uiState.value.copy(octaveShift = newOctave)
        }
    }

    fun onMasterVolumeChange(volume: Float) {
        val clamped = volume.coerceIn(0.0f, 1.0f)
        _uiState.value = _uiState.value.copy(masterVolume = clamped)
        audioBridge.setMasterVolume(clamped)
    }

    fun toggleMicrotonalKey(keyIndex: Int) {
        if (keyIndex !in 0..11) return
        val currentOffsets = _uiState.value.microtonalOffsets.toMutableList()
        val currentVal = currentOffsets[keyIndex]
        // Toggle between 0 and -50 cents (quarter-tone flat)
        currentOffsets[keyIndex] = if (currentVal == 0) -50 else 0
        _uiState.value = _uiState.value.copy(
            microtonalOffsets = currentOffsets,
            activeScalePreset = ScalePreset.EQUAL_TEMPERAMENT
        )
    }

    fun applyScalePreset(preset: ScalePreset) {
        _uiState.value = _uiState.value.copy(
            microtonalOffsets = preset.offsets.toList(),
            activeScalePreset = preset
        )
    }

    fun onTempoChange(delta: Int) {
        val newTempo = (_uiState.value.tempoBpm + delta).coerceIn(40, 280)
        _uiState.value = _uiState.value.copy(tempoBpm = newTempo)
        sequencer.setTempo(newTempo)
    }

    fun setArrangerSection(section: ArrangerSection) {
        _uiState.value = _uiState.value.copy(currentArrangerSection = section)
        sequencer.selectSection(section)
    }

    fun startArrangerPlayback() {
        if (!_uiState.value.isAudioEngineActive && audioBridge.isAvailable) {
            initEngine()
        }
        val activePkg = _uiState.value.activeSetPackage
        val style = activePkg?.styles?.firstOrNull { it.id == _uiState.value.activeStyleId }
            ?: activePkg?.styles?.firstOrNull()
        if (style != null) {
            sequencer.setStyle(style)
        }
        sequencer.setChord(_uiState.value.recognizedChord)
        sequencer.setTempo(_uiState.value.tempoBpm)
        sequencer.selectSection(_uiState.value.currentArrangerSection, immediate = true)
        sequencer.start()
        _uiState.value = _uiState.value.copy(isArrangerPlaying = true)
    }

    fun stopArrangerPlayback() {
        sequencer.stop()
        _uiState.value = _uiState.value.copy(isArrangerPlaying = false)
    }

    fun toggleArrangerPlayback() {
        if (_uiState.value.isArrangerPlaying) {
            stopArrangerPlayback()
        } else {
            startArrangerPlayback()
        }
    }

    fun toggleSynchroStart() {
        _uiState.value = _uiState.value.copy(isSynchroStartEnabled = !_uiState.value.isSynchroStartEnabled)
    }

    fun toggleSynchroStop() {
        _uiState.value = _uiState.value.copy(isSynchroStopEnabled = !_uiState.value.isSynchroStopEnabled)
    }

    // Phase 5: SET Management Actions
    fun toggleSetManager(open: Boolean? = null) {
        val nextOpen = open ?: !_uiState.value.isSetManagerOpen
        _uiState.value = _uiState.value.copy(isSetManagerOpen = nextOpen)
    }

    fun selectStyle(styleId: String) {
        val style = setRepository.getActiveStyle(styleId)
        if (style != null) {
            sequencer.setStyle(style)
            _uiState.value = _uiState.value.copy(
                activeStyleId = style.id,
                activeStyleName = style.name,
                tempoBpm = style.tempoBpm,
                currentArrangerSection = ArrangerSection.VARIATION_1
            )
        }
    }

    fun loadDemoPa4xSet() {
        viewModelScope.launch(Dispatchers.IO) {
            setRepository.loadDemoPa4xSet()
        }
    }

    fun loadSetFromDirectory(directory: java.io.File) {
        viewModelScope.launch(Dispatchers.IO) {
            setRepository.loadSetFromDirectory(directory)
        }
    }

    fun panicAllNotesOff() {
        sequencer.stop()
        audioBridge.sendAllNotesOff()
        chordEngine.reset()
        _uiState.value = _uiState.value.copy(
            isArrangerPlaying = false,
            activeMidiNotes = emptySet(),
            pitchBendNormalized = 0.0f
        )
    }

    override fun onCleared() {
        super.onCleared()
        sequencer.stop()
        audioBridge.sendAllNotesOff()
        NativeAudioBridge.stopEngine()
        NativeAudioBridge.destroyEngine()
    }
}
