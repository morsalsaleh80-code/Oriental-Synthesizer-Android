package com.example.engine

import com.example.audio.NativeAudioBridge
import com.example.korg.models.IrMidiEvent
import com.example.korg.models.IrStyle
import com.example.korg.models.IrStyleTrack
import com.example.korg.models.NttType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Real-time Arranger Style Sequencer.
 *
 * Implements:
 * - High-precision musical clock (PPQN = 480).
 * - Drift-compensated nano-time delta accumulation.
 * - Dynamic Section changes (Immediate, On-Bar, On-Beat).
 * - Automatic transition from Fill/Break back to the previous Variation.
 * - Note Translation Table (NTT) integration with Chord recognition.
 * - Dispatching multi-channel Note On / Note Off events to NativeAudioBridge.
 * - Active sounding voice tracking with guaranteed stuck-note prevention.
 */
class StyleSequencer(
    private val audioBridge: com.example.audio.AudioEventDispatcher = NativeAudioBridge,
    private val nttEngine: NoteTranslationEngine = NoteTranslationEngine(),
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    companion object {
        const val PPQN = 480L // Ticks per quarter note
    }

    private var playbackJob: Job? = null

    // Transport and playback state
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentTempoBpm = MutableStateFlow(120)
    val currentTempoBpm: StateFlow<Int> = _currentTempoBpm.asStateFlow()

    private val _currentSection = MutableStateFlow(ArrangerSection.VARIATION_1)
    val currentSection: StateFlow<ArrangerSection> = _currentSection.asStateFlow()

    private val _currentBar = MutableStateFlow(1)
    val currentBar: StateFlow<Int> = _currentBar.asStateFlow()

    private val _currentBeat = MutableStateFlow(1)
    val currentBeat: StateFlow<Int> = _currentBeat.asStateFlow()

    // Active loaded style
    private var activeStyle: IrStyle? = null

    // Currently recognized chord for NTT re-voicing
    private var activeChord: RecognizedChord = RecognizedChord(NoteName.C, ChordQuality.MAJOR)

    // Queued next section for bar-boundary transition
    private var pendingSection: ArrangerSection? = null

    // Fallback variation when a one-shot Fill or Break finishes
    private var previousVariation: ArrangerSection = ArrangerSection.VARIATION_1

    // Sequencer clock tracking
    private var currentTick: Long = 0L
    private var totalSectionTicks: Long = 4 * 4 * PPQN

    // Active note tracking for NoteOff dispatch and panic silence:
    // Key: Pair(midiChannel, midiNote) -> scheduled offTick
    private val activePlayingNotes = ConcurrentHashMap<Pair<Int, Int>, Long>()

    // Track mute/solo states (Track index 0..7)
    private val trackMuted = BooleanArray(8) { false }
    private val trackSoloed = BooleanArray(8) { false }

    fun setTempo(bpm: Int) {
        _currentTempoBpm.value = bpm.coerceIn(40, 300)
    }

    fun setStyle(style: IrStyle) {
        this.activeStyle = style
        _currentTempoBpm.value = style.tempoBpm
        updateSectionTicks(_currentSection.value)
    }

    fun setChord(chord: RecognizedChord) {
        this.activeChord = chord
    }

    fun isTrackMuted(trackIndex: Int): Boolean = if (trackIndex in 0..7) trackMuted[trackIndex] else false

    fun setTrackMute(trackIndex: Int, muted: Boolean) {
        if (trackIndex in 0..7) {
            trackMuted[trackIndex] = muted
            if (muted) {
                silenceTrack(trackIndex)
            }
        }
    }

    fun setTrackSolo(trackIndex: Int, solo: Boolean) {
        if (trackIndex in 0..7) {
            trackSoloed[trackIndex] = solo
        }
    }

    /**
     * Request section transition.
     * Fill and Break trigger immediate bar-boundary switch, reverting back to Variation afterward.
     */
    fun selectSection(section: ArrangerSection, immediate: Boolean = false) {
        if (section.isVariation()) {
            previousVariation = section
        }

        if (immediate || !_isPlaying.value) {
            silenceAllActiveNotes()
            _currentSection.value = section
            pendingSection = null
            currentTick = 0L
            updateSectionTicks(section)
        } else {
            // Queue section for the next bar boundary
            pendingSection = section
        }
    }

    fun start() {
        if (_isPlaying.value) return
        _isPlaying.value = true
        currentTick = 0L
        _currentBar.value = 1
        _currentBeat.value = 1
        updateSectionTicks(_currentSection.value)

        playbackJob = scope.launch {
            runSequencerLoop()
        }
    }

    fun stop() {
        if (!_isPlaying.value) return
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
        silenceAllActiveNotes()
        audioBridge.sendAllNotesOff()
        currentTick = 0L
        _currentBar.value = 1
        _currentBeat.value = 1
    }

    private fun updateSectionTicks(section: ArrangerSection) {
        val element = activeStyle?.elements?.get(section)
        val bars = element?.lengthBars ?: when (section) {
            ArrangerSection.FILL_1, ArrangerSection.FILL_2, ArrangerSection.FILL_3, ArrangerSection.FILL_4, ArrangerSection.BREAK -> 1
            ArrangerSection.INTRO_1, ArrangerSection.ENDING_1 -> 8
            else -> 4
        }
        totalSectionTicks = bars * 4 * PPQN
    }

    private suspend fun runSequencerLoop() {
        var lastNanoTime = System.nanoTime()
        var accumulatedTickFraction = 0.0

        // Sub-slice resolution (advance ~4ms per step)
        val sleepIntervalMs = 4L

        while (scope.isActive && _isPlaying.value) {
            delay(sleepIntervalMs)

            val now = System.nanoTime()
            val deltaSeconds = (now - lastNanoTime) / 1_000_000_000.0
            lastNanoTime = now

            val bpm = _currentTempoBpm.value
            // Ticks per second = (bpm / 60) * PPQN
            val ticksPerSecond = (bpm / 60.0) * PPQN
            val ticksToAdd = deltaSeconds * ticksPerSecond + accumulatedTickFraction
            val wholeTicks = ticksToAdd.toLong()
            accumulatedTickFraction = ticksToAdd - wholeTicks

            if (wholeTicks > 0) {
                advanceClock(wholeTicks)
            }
        }
    }

    /**
     * Advances sequencer clock by whole ticks, evaluating note events and bar boundaries.
     */
    fun advanceClock(ticks: Long) {
        val startTick = currentTick
        val endTick = currentTick + ticks

        // Check active note-offs that expired within this slice
        checkNoteOffs(endTick)

        // Dispatch MIDI events falling between [startTick, endTick)
        dispatchSliceEvents(startTick, endTick)

        currentTick = endTick

        // Update bar and beat counters
        val tickInBar = currentTick % (4 * PPQN)
        _currentBeat.value = ((tickInBar / PPQN).toInt() + 1).coerceIn(1, 4)
        _currentBar.value = ((currentTick / (4 * PPQN)).toInt() + 1)

        // Check section completion / loop boundary
        if (currentTick >= totalSectionTicks) {
            onSectionBoundaryReached()
        }
    }

    private fun onSectionBoundaryReached() {
        val currentSec = _currentSection.value

        // Check if there's a pending section or if Fill/Break is finished
        val nextSec = when {
            pendingSection != null -> {
                val next = pendingSection!!
                pendingSection = null
                next
            }
            currentSec.isFillOrBreak() -> {
                // Fills & Breaks automatically return to previous variation
                previousVariation
            }
            currentSec.isEnding() -> {
                // Ending stops the arranger
                stop()
                return
            }
            else -> currentSec // Loop current section
        }

        silenceAllActiveNotes()
        _currentSection.value = nextSec
        currentTick = 0L
        updateSectionTicks(nextSec)
        _currentBar.value = 1
        _currentBeat.value = 1
    }

    private fun dispatchSliceEvents(startTick: Long, endTick: Long) {
        val style = activeStyle ?: return
        val currentSec = _currentSection.value
        val element = style.elements[currentSec] ?: return
        val chordVar = element.chordVariations.firstOrNull() ?: return

        val tracks = style.tracks
        val isAnySoloed = trackSoloed.any { it }

        for (track in tracks) {
            val tIdx = track.trackIndex
            if (trackMuted.getOrElse(tIdx) { false }) continue
            if (isAnySoloed && !trackSoloed.getOrElse(tIdx) { false }) continue

            val events = chordVar.trackEvents[tIdx] ?: continue
            val channel = track.midiChannel

            for (ev in events) {
                if (ev.tickOffset in startTick until endTick) {
                    processEvent(ev, track, channel)
                }
            }
        }
    }

    private fun processEvent(ev: IrMidiEvent, track: IrStyleTrack, channel: Int) {
        val status = ev.status and 0xF0
        when (status) {
            0x90 -> { // Note On
                val rawNote = ev.data1
                val rawVelocity = ev.data2
                if (rawVelocity > 0) {
                    // Check NTT rule: Drum (ch 9) and Perc (ch 8) pass through directly
                    val translatedNote = if (channel == 9 || channel == 8 || track.nttRule.nttType == NttType.FIXED && channel == 9) {
                        rawNote
                    } else {
                        nttEngine.transformNote(
                            originalNote = rawNote,
                            originalVelocity = rawVelocity,
                            nttType = track.nttRule.nttType,
                            sourceRoot = track.nttRule.rootKey,
                            sourceQuality = track.nttRule.chordType,
                            targetRoot = activeChord.root,
                            targetQuality = activeChord.quality,
                            targetBass = activeChord.bass,
                            bassFollow = track.nttRule.bassFollow
                        )
                    }

                    // Apply track volume scaling (0..127)
                    val effectiveVelocity = ((rawVelocity * (track.volume / 127.0f))).toInt().coerceIn(1, 127)

                    // Dispatch to Native Audio Engine
                    audioBridge.sendNoteOn(translatedNote, effectiveVelocity, channel, 0.0f)
                    activePlayingNotes[Pair(channel, translatedNote)] = currentTick + 240L
                } else {
                    // Note On with vel 0 is Note Off
                    audioBridge.sendNoteOff(ev.data1, channel)
                    activePlayingNotes.remove(Pair(channel, ev.data1))
                }
            }
            0x80 -> { // Note Off
                audioBridge.sendNoteOff(ev.data1, channel)
                activePlayingNotes.remove(Pair(channel, ev.data1))
            }
        }
    }

    private fun checkNoteOffs(currentTick: Long) {
        val expired = mutableListOf<Pair<Int, Int>>()
        for ((key, offTick) in activePlayingNotes) {
            if (currentTick >= offTick) {
                audioBridge.sendNoteOff(key.second, key.first)
                expired.add(key)
            }
        }
        expired.forEach { activePlayingNotes.remove(it) }
    }

    private fun silenceTrack(trackIndex: Int) {
        val style = activeStyle ?: return
        val track = style.tracks.getOrNull(trackIndex) ?: return
        val channel = track.midiChannel
        val toRemove = mutableListOf<Pair<Int, Int>>()
        for ((key, _) in activePlayingNotes) {
            if (key.first == channel) {
                audioBridge.sendNoteOff(key.second, channel)
                toRemove.add(key)
            }
        }
        toRemove.forEach { activePlayingNotes.remove(it) }
    }

    fun silenceAllActiveNotes() {
        for ((key, _) in activePlayingNotes) {
            audioBridge.sendNoteOff(key.second, key.first)
        }
        activePlayingNotes.clear()
    }

    private fun ArrangerSection.isVariation(): Boolean {
        return this == ArrangerSection.VARIATION_1 ||
               this == ArrangerSection.VARIATION_2 ||
               this == ArrangerSection.VARIATION_3 ||
               this == ArrangerSection.VARIATION_4
    }

    private fun ArrangerSection.isFillOrBreak(): Boolean {
        return this == ArrangerSection.FILL_1 ||
               this == ArrangerSection.FILL_2 ||
               this == ArrangerSection.FILL_3 ||
               this == ArrangerSection.FILL_4 ||
               this == ArrangerSection.BREAK
    }

    private fun ArrangerSection.isEnding(): Boolean {
        return this == ArrangerSection.ENDING_1 ||
               this == ArrangerSection.ENDING_2 ||
               this == ArrangerSection.ENDING_3
    }
}
