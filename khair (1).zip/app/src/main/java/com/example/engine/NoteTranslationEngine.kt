package com.example.engine

import com.example.korg.models.NttType

/**
 * Note Translation Table (NTT) Transformation Engine.
 *
 * Implements KORG Pa4X / Mobile Arranger note translation rules:
 * - PARALLEL: Transposes notes by root interval (targetRoot - sourceRoot).
 * - FIXED: Keeps chord degree notes fixed or maps to target quality scale tones without octave jumps.
 * - BASS: Strictly tracks root or slash-bass note, maintaining low octave placement (E1..E3 / 28..52).
 * - CHORD: Intelligent degree-based re-voicing adapting Maj, Min, 7th, m7, Maj7, Dim, Aug, Sus4, etc.
 *
 * Also guarantees:
 * - MIDI note bounds clamping (0..127).
 * - Velocity preservation and humanization weighting.
 * - Drum and percussion tracks bypass NTT (always transparent pass-through).
 */
class NoteTranslationEngine {

    /**
     * Translates a MIDI note from a style pattern based on the NTT rule, source chord, and target chord.
     *
     * @param originalNote Original MIDI note number (0..127)
     * @param originalVelocity Original MIDI velocity (1..127)
     * @param nttType The NTT transformation mode (PARALLEL, FIXED, CHORD, BASS)
     * @param sourceRoot The root pitch class of the pattern (0=C, 1=C#, ..., default C=0)
     * @param sourceQuality The quality of the pattern (e.g. "Maj" or ChordQuality.MAJOR)
     * @param targetRoot The target root NoteName detected from the lower keyboard
     * @param targetQuality The detected chord quality
     * @param targetBass The target bass NoteName (for slash chords, defaults to targetRoot)
     * @param bassFollow Whether the track follows slash bass
     * @return Transformed MIDI note (clamped 0..127)
     */
    fun transformNote(
        originalNote: Int,
        originalVelocity: Int = 100,
        nttType: NttType,
        sourceRoot: Int = 0, // C
        sourceQuality: String = "Maj",
        targetRoot: NoteName,
        targetQuality: ChordQuality,
        targetBass: NoteName = targetRoot,
        bassFollow: Boolean = false
    ): Int {
        if (originalNote !in 0..127) return originalNote.coerceIn(0, 127)

        val targetRootPitch = targetRoot.pitchClass
        val rootShift = targetRootPitch - (sourceRoot % 12)

        return when (nttType) {
            NttType.PARALLEL -> {
                // Strict parallel transposition
                (originalNote + rootShift).coerceIn(0, 127)
            }

            NttType.BASS -> {
                // Bass note tracking: prioritize targetBass if bassFollow is enabled or slash chord is present
                val effectiveBassPitch = if (bassFollow) targetBass.pitchClass else targetRootPitch
                val currentOctave = (originalNote / 12)
                var bassMidi = currentOctave * 12 + effectiveBassPitch

                // Ensure bass remains in natural acoustic bass range (MIDI 28..52: E1 to E3)
                while (bassMidi < 28) bassMidi += 12
                while (bassMidi > 55) bassMidi -= 12

                bassMidi.coerceIn(0, 127)
            }

            NttType.FIXED -> {
                // Fixed degree mapping: notes stay close to original register
                // Only shift if the note clashes with the target chord scale
                val notePitchClass = originalNote % 12
                val octave = originalNote / 12

                // Target chord pitch classes
                val targetIntervals = targetQuality.intervals
                val targetPitchClasses = targetIntervals.map { (targetRootPitch + it) % 12 }.toSet()

                if (notePitchClass in targetPitchClasses) {
                    // Fits target chord perfectly, keep original note
                    originalNote
                } else {
                    // Find closest matching chord tone in target chord
                    val closestInterval = targetIntervals.minByOrNull { interval ->
                        val candidatePitch = (targetRootPitch + interval) % 12
                        val diff = Math.abs(candidatePitch - notePitchClass)
                        Math.min(diff, 12 - diff)
                    } ?: 0

                    val targetPitch = (targetRootPitch + closestInterval) % 12
                    var resultNote = octave * 12 + targetPitch

                    // Minimize distance to original note
                    if (resultNote - originalNote > 6) resultNote -= 12
                    if (originalNote - resultNote > 6) resultNote += 12

                    resultNote.coerceIn(0, 127)
                }
            }

            NttType.CHORD -> {
                // Intelligent degree re-voicing
                val sourceIntervals = getSourceIntervals(sourceQuality)
                val notePitchClass = (originalNote % 12 + 12) % 12
                val noteDegreeInterval = ((notePitchClass - sourceRoot) % 12 + 12) % 12

                // Identify which chord degree index the original note was (root, 3rd, 5th, 7th...)
                val degreeIndex = sourceIntervals.indexOfFirst { (it % 12) == noteDegreeInterval }

                val targetIntervals = targetQuality.intervals
                val octave = originalNote / 12

                val targetInterval = if (degreeIndex in targetIntervals.indices) {
                    targetIntervals[degreeIndex]
                } else {
                    // If not an exact degree, map to closest available target degree
                    targetIntervals.minByOrNull { Math.abs((it % 12) - noteDegreeInterval) } ?: 0
                }

                val targetPitchClass = (targetRootPitch + targetInterval) % 12
                var resultNote = octave * 12 + targetPitchClass

                // Ensure voice leading is smooth (minimal movement from original note)
                if (resultNote - originalNote > 6) resultNote -= 12
                if (originalNote - resultNote > 6) resultNote += 12

                resultNote.coerceIn(0, 127)
            }
        }
    }

    private fun getSourceIntervals(sourceQuality: String): IntArray {
        return when (sourceQuality.lowercase()) {
            "min", "m", "minor" -> intArrayOf(0, 3, 7)
            "7", "7th", "dom7" -> intArrayOf(0, 4, 7, 10)
            "maj7", "m7th" -> intArrayOf(0, 4, 7, 11)
            "dim" -> intArrayOf(0, 3, 6)
            "aug" -> intArrayOf(0, 4, 8)
            "sus4" -> intArrayOf(0, 5, 7)
            else -> intArrayOf(0, 4, 7) // Default Major
        }
    }
}
