package com.example.engine

/**
 * Polyphonic Real-time Chord Recognizer Engine for Mobile Arranger Workstation.
 *
 * Implements clean-room chord recognition algorithms:
 * 1. Pitch-Class Set Masking with inversion-invariant root detection.
 * 2. Bass-note extraction to support slash chords (e.g. C/E, G/B, Dm/F).
 * 3. EZ One-Finger chord detection (Yamaha/Korg style single-key triggering with modifier keys).
 * 4. Harmonic priority ranking to prevent false detections from passing transient notes.
 */
class ChordRecognizer {

    // Sorted priority list of chords to test against: higher harmonic complexity tested first
    private val chordPriorities: List<ChordQuality> = listOf(
        ChordQuality.ADD_9TH,
        ChordQuality.MAJOR_7TH,
        ChordQuality.DOMINANT_7TH,
        ChordQuality.MINOR_7TH,
        ChordQuality.HALF_DIMINISHED,
        ChordQuality.DIMINISHED_7TH,
        ChordQuality.MAJOR_6TH,
        ChordQuality.MINOR_6TH,
        ChordQuality.SUSPENDED_4TH,
        ChordQuality.SUSPENDED_2ND,
        ChordQuality.AUGMENTED,
        ChordQuality.DIMINISHED,
        ChordQuality.MAJOR,
        ChordQuality.MINOR,
        ChordQuality.POWER_5TH
    )

    /**
     * Detect chord from a collection of active MIDI notes according to the selected recognition mode.
     *
     * @param activeNotes Set or list of active MIDI notes in the chord zone (e.g. 0..127)
     * @param mode Mode of detection (FINGERED, ONE_FINGER, FULL_KEYBOARD)
     * @return RecognizedChord or null if insufficient notes or ambiguous harmony
     */
    fun recognize(activeNotes: Collection<Int>, mode: ChordRecognitionMode): RecognizedChord? {
        if (activeNotes.isEmpty()) return null

        val sortedNotes = activeNotes.sorted()

        return when (mode) {
            ChordRecognitionMode.ONE_FINGER -> recognizeOneFinger(sortedNotes)
            ChordRecognitionMode.FINGERED,
            ChordRecognitionMode.FULL_KEYBOARD -> recognizeFingered(sortedNotes)
        }
    }

    /**
     * Standard Fingered Recognition.
     * Computes pitch classes, lowest bass note, and analyzes pitch-class bitmasks.
     */
    fun recognizeFingered(sortedNotes: List<Int>): RecognizedChord? {
        if (sortedNotes.isEmpty()) return null

        val lowestMidi = sortedNotes.first()
        val bassPitchClass = lowestMidi % 12
        val bassNoteName = NoteName.fromPitchClass(bassPitchClass)

        // Compute unique pitch classes present
        val pitchClasses = sortedNotes.map { it % 12 }.distinct()

        // 1 note: in fingered mode, single note returns simple Major on that root
        if (pitchClasses.size == 1) {
            val rootNote = NoteName.fromPitchClass(pitchClasses[0])
            return RecognizedChord(
                root = rootNote,
                quality = ChordQuality.MAJOR,
                bass = rootNote,
                activeNotes = sortedNotes
            )
        }

        // Build 12-bit mask: bit N is set if pitch class N is present
        var actualMask = 0
        for (pc in pitchClasses) {
            actualMask = actualMask or (1 shl pc)
        }

        // Search for best matching root and chord quality
        var bestMatch: RecognizedChord? = null
        var bestMatchScore = -1

        // Evaluate all 12 candidate roots
        for (rootPc in 0..11) {
            val rootNote = NoteName.fromPitchClass(rootPc)

            for (quality in chordPriorities) {
                // Compute expected mask rotated for this root
                val expectedMask = rotateMask(quality.intervalMask, rootPc)

                // Exact match:
                if (actualMask == expectedMask) {
                    val score = scoreMatch(quality, rootPc == bassPitchClass, isExact = true)
                    if (score > bestMatchScore) {
                        bestMatchScore = score
                        bestMatch = RecognizedChord(
                            root = rootNote,
                            quality = quality,
                            bass = bassNoteName,
                            activeNotes = sortedNotes
                        )
                    }
                }
                // Subset/Superset match for 2-note or 4-note voicings with omitted 5th (e.g. Root + 3rd + 7th):
                else if (pitchClasses.size >= 2) {
                    // Check if all played notes belong to the chord and chord contains root & 3rd
                    val matchesAllPlayed = (actualMask and expectedMask) == actualMask
                    val containsRoot = (actualMask and (1 shl rootPc)) != 0

                    if (matchesAllPlayed && containsRoot) {
                        val score = scoreMatch(quality, rootPc == bassPitchClass, isExact = false)
                        if (score > bestMatchScore) {
                            bestMatchScore = score
                            bestMatch = RecognizedChord(
                                root = rootNote,
                                quality = quality,
                                bass = bassNoteName,
                                activeNotes = sortedNotes
                            )
                        }
                    }
                }
            }
        }

        // Fallback for 2 notes: root + 5th (Power Chord) or intervals
        if (bestMatch == null && pitchClasses.size == 2) {
            val p0 = pitchClasses[0]
            val p1 = pitchClasses[1]
            val interval = ((p1 - p0) + 12) % 12
            if (interval == 7) {
                // Perfect 5th: Root is p0
                val rootNote = NoteName.fromPitchClass(p0)
                return RecognizedChord(root = rootNote, quality = ChordQuality.POWER_5TH, bass = bassNoteName, activeNotes = sortedNotes)
            } else if (interval == 5) {
                // Inverted 5th (4th): Root is p1
                val rootNote = NoteName.fromPitchClass(p1)
                return RecognizedChord(root = rootNote, quality = ChordQuality.POWER_5TH, bass = bassNoteName, activeNotes = sortedNotes)
            } else if (interval == 4) {
                // Major 3rd: root is p0
                val rootNote = NoteName.fromPitchClass(p0)
                return RecognizedChord(root = rootNote, quality = ChordQuality.MAJOR, bass = bassNoteName, activeNotes = sortedNotes)
            } else if (interval == 3) {
                // Minor 3rd: root is p0
                val rootNote = NoteName.fromPitchClass(p0)
                return RecognizedChord(root = rootNote, quality = ChordQuality.MINOR, bass = bassNoteName, activeNotes = sortedNotes)
            }
        }

        return bestMatch
    }

    /**
     * EZ One-Finger Chord Recognition (Arranger Standard):
     *
     * Rules:
     * - Highest note played in the zone is considered the root note.
     * - Any key to the left of the root modifies chord quality:
     *   * No extra keys: Major chord
     *   * Black key to the left: Minor chord
     *   * White key to the left: Dominant 7th chord
     *   * White AND Black key to the left: Minor 7th chord
     */
    fun recognizeOneFinger(sortedNotes: List<Int>): RecognizedChord? {
        if (sortedNotes.isEmpty()) return null

        val rootMidi = sortedNotes.last()
        val rootNote = NoteName.fromPitchClass(rootMidi % 12)
        val modifiers = sortedNotes.dropLast(1)

        if (modifiers.isEmpty()) {
            return RecognizedChord(
                root = rootNote,
                quality = ChordQuality.MAJOR,
                bass = rootNote,
                activeNotes = sortedNotes
            )
        }

        var hasBlackModifier = false
        var hasWhiteModifier = false

        for (modMidi in modifiers) {
            val pc = modMidi % 12
            val isBlack = pc in listOf(1, 3, 6, 8, 10)
            if (isBlack) {
                hasBlackModifier = true
            } else {
                hasWhiteModifier = true
            }
        }

        val quality = when {
            hasBlackModifier && hasWhiteModifier -> ChordQuality.MINOR_7TH
            hasBlackModifier -> ChordQuality.MINOR
            hasWhiteModifier -> ChordQuality.DOMINANT_7TH
            else -> ChordQuality.MAJOR
        }

        return RecognizedChord(
            root = rootNote,
            quality = quality,
            bass = rootNote,
            activeNotes = sortedNotes
        )
    }

    private fun rotateMask(intervalMask: Int, rootPitchClass: Int): Int {
        var rotated = 0
        for (i in 0..11) {
            if ((intervalMask and (1 shl i)) != 0) {
                val newPos = (i + rootPitchClass) % 12
                rotated = rotated or (1 shl newPos)
            }
        }
        return rotated
    }

    private fun scoreMatch(quality: ChordQuality, isRootInBass: Boolean, isExact: Boolean): Int {
        var score = 100
        if (isExact) score += 50
        if (isRootInBass) score += 20

        score += when (quality) {
            ChordQuality.MAJOR, ChordQuality.MINOR -> 15
            ChordQuality.DOMINANT_7TH, ChordQuality.MAJOR_7TH, ChordQuality.MINOR_7TH -> 12
            ChordQuality.ADD_9TH, ChordQuality.SUSPENDED_4TH, ChordQuality.SUSPENDED_2ND -> 10
            ChordQuality.DIMINISHED, ChordQuality.DIMINISHED_7TH, ChordQuality.HALF_DIMINISHED, ChordQuality.AUGMENTED -> 8
            ChordQuality.MAJOR_6TH, ChordQuality.MINOR_6TH -> 7
            ChordQuality.POWER_5TH -> 4
        }
        return score
    }
}
