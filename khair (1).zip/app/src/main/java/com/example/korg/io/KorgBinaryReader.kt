package com.example.korg.io

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/**
 * Exception thrown when reading binary KORG data encounters malformed or truncated streams.
 */
class KorgBinaryReadException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Robust, bounds-checked binary reader designed for parsing KORG Pa4X binary structures
 * (IFF/RIFF chunks, SMF tracks, PCG program chunks, and PCM wave headers).
 *
 * Supports both Big-Endian (Motorola/SMF standard) and Little-Endian (Intel/KORG WAV standard).
 */
class KorgBinaryReader private constructor(
    private val buffer: ByteBuffer
) {
    companion object {
        fun fromByteArray(data: ByteArray, offset: Int = 0, length: Int = data.size): KorgBinaryReader {
            val buf = ByteBuffer.wrap(data, offset, length)
            return KorgBinaryReader(buf)
        }

        fun fromByteBuffer(buffer: ByteBuffer): KorgBinaryReader {
            return KorgBinaryReader(buffer.duplicate())
        }
    }

    val capacity: Int get() = buffer.capacity()
    val position: Int get() = buffer.position()
    fun position(): Int = buffer.position()
    val remaining: Int get() = buffer.remaining()
    val hasRemaining: Boolean get() = buffer.hasRemaining()

    fun setOrder(order: ByteOrder): KorgBinaryReader {
        buffer.order(order)
        return this
    }

    fun seek(newPosition: Int): KorgBinaryReader {
        if (newPosition < 0 || newPosition > buffer.limit()) {
            throw KorgBinaryReadException("Invalid seek position: $newPosition (limit: ${buffer.limit()})")
        }
        buffer.position(newPosition)
        return this
    }

    fun skip(bytes: Int): KorgBinaryReader {
        if (bytes < 0 || bytes > remaining) {
            throw KorgBinaryReadException("Cannot skip $bytes bytes, only $remaining remaining")
        }
        buffer.position(buffer.position() + bytes)
        return this
    }

    private fun ensureRemaining(count: Int) {
        if (remaining < count) {
            throw KorgBinaryReadException("Buffer underflow: needed $count bytes, but only $remaining remaining (pos: $position)")
        }
    }

    fun readByte(): Byte {
        ensureRemaining(1)
        return buffer.get()
    }

    fun readUByte(): Int {
        return readByte().toInt() and 0xFF
    }

    fun readShortBE(): Short {
        ensureRemaining(2)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.BIG_ENDIAN)
        val value = buffer.short
        buffer.order(oldOrder)
        return value
    }

    fun readShortLE(): Short {
        ensureRemaining(2)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.LITTLE_ENDIAN)
        val value = buffer.short
        buffer.order(oldOrder)
        return value
    }

    fun readUShortBE(): Int {
        return readShortBE().toInt() and 0xFFFF
    }

    fun readUShortLE(): Int {
        return readShortLE().toInt() and 0xFFFF
    }

    fun readIntBE(): Int {
        ensureRemaining(4)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.BIG_ENDIAN)
        val value = buffer.int
        buffer.order(oldOrder)
        return value
    }

    fun readIntLE(): Int {
        ensureRemaining(4)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.LITTLE_ENDIAN)
        val value = buffer.int
        buffer.order(oldOrder)
        return value
    }

    fun readUIntBE(): Long {
        return readIntBE().toLong() and 0xFFFFFFFFL
    }

    fun readUIntLE(): Long {
        return readIntLE().toLong() and 0xFFFFFFFFL
    }

    fun readFloatBE(): Float {
        ensureRemaining(4)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.BIG_ENDIAN)
        val value = buffer.float
        buffer.order(oldOrder)
        return value
    }

    fun readFloatLE(): Float {
        ensureRemaining(4)
        val oldOrder = buffer.order()
        buffer.order(ByteOrder.LITTLE_ENDIAN)
        val value = buffer.float
        buffer.order(oldOrder)
        return value
    }

    fun readBytes(count: Int): ByteArray {
        ensureRemaining(count)
        val dest = ByteArray(count)
        buffer.get(dest)
        return dest
    }

    /**
     * Reads a four-character ASCII FourCC identifier (e.g. 'RIFF', 'KORG', 'MThd').
     */
    fun readFourCC(): String {
        ensureRemaining(4)
        val bytes = ByteArray(4)
        buffer.get(bytes)
        return String(bytes, Charsets.US_ASCII)
    }

    /**
     * Reads a fixed-length string, trimming trailing nulls and whitespace.
     */
    fun readFixedString(length: Int, charset: Charset = Charsets.ISO_8859_1): String {
        ensureRemaining(length)
        val bytes = ByteArray(length)
        buffer.get(bytes)
        var actualLen = length
        for (i in 0 until length) {
            if (bytes[i] == 0.toByte()) {
                actualLen = i
                break
            }
        }
        return String(bytes, 0, actualLen, charset).trim()
    }

    /**
     * Reads a null-terminated C-string up to a maximum number of bytes.
     */
    fun readNullTerminatedString(maxBytes: Int = remaining, charset: Charset = Charsets.ISO_8859_1): String {
        val startPos = buffer.position()
        var len = 0
        while (len < maxBytes && buffer.hasRemaining()) {
            if (buffer.get() == 0.toByte()) {
                break
            }
            len++
        }
        val endPos = buffer.position()
        buffer.position(startPos)
        val bytes = ByteArray(len)
        buffer.get(bytes)
        buffer.position(endPos) // advance past the null terminator
        return String(bytes, charset)
    }

    /**
     * Creates a sliced child reader restricted to the specified length.
     * Advances the parent reader past the sliced region.
     */
    fun slice(length: Int): KorgBinaryReader {
        ensureRemaining(length)
        val currentLimit = buffer.limit()
        val currentPos = buffer.position()
        
        buffer.limit(currentPos + length)
        val childSlice = buffer.slice()
        childSlice.order(buffer.order())
        
        // Restore parent limit and advance position past slice
        buffer.limit(currentLimit)
        buffer.position(currentPos + length)
        
        return KorgBinaryReader(childSlice)
    }

    /**
     * Reads a MIDI variable-length quantity (VLQ) as used in SMF tracks.
     */
    fun readVariableLength(): Long {
        var value = 0L
        var byteCount = 0
        while (true) {
            if (byteCount >= 4) {
                throw KorgBinaryReadException("Malformed variable-length quantity: exceeds 4 bytes")
            }
            val b = readUByte()
            value = (value shl 7) or (b and 0x7F).toLong()
            byteCount++
            if ((b and 0x80) == 0) {
                break
            }
        }
        return value
    }
}
