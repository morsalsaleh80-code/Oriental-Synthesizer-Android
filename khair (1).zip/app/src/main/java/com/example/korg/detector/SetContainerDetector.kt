package com.example.korg.detector

import com.example.korg.models.SetInspectionReport
import com.example.korg.models.SetResourceType
import com.example.korg.models.SetValidationIssue
import com.example.korg.models.ValidationSeverity
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * High-performance container detector and structure inspector for KORG Pa4X .SET folders
 * and zipped archives (.SET.zip / .zip).
 */
class SetContainerDetector {

    /**
     * Inspects a given file or directory path.
     */
    fun inspectPath(path: String): SetInspectionReport {
        val file = File(path)
        if (!file.exists()) {
            return SetInspectionReport(
                isValidSet = false,
                rootPath = path,
                setName = file.name,
                isZipArchive = false,
                issues = listOf(
                    SetValidationIssue(
                        ValidationSeverity.ERROR,
                        "FileSystem",
                        "Target path does not exist: $path"
                    )
                )
            )
        }

        return if (file.isDirectory) {
            inspectDirectory(file)
        } else if (file.isFile && (file.name.endsWith(".zip", ignoreCase = true) || file.name.endsWith(".set.zip", ignoreCase = true))) {
            inspectZipArchive(file)
        } else {
            SetInspectionReport(
                isValidSet = false,
                rootPath = path,
                setName = file.name,
                isZipArchive = false,
                issues = listOf(
                    SetValidationIssue(
                        ValidationSeverity.ERROR,
                        "Container",
                        "File is neither a directory (.SET) nor a supported zip archive"
                    )
                )
            )
        }
    }

    /**
     * Inspects an uncompressed .SET directory tree on the filesystem.
     */
    fun inspectDirectory(directory: File): SetInspectionReport {
        val issues = mutableListOf<SetValidationIssue>()
        val detectedFolders = mutableMapOf<SetResourceType, String>()
        val resourceCounts = mutableMapOf<SetResourceType, Int>()

        val rawName = directory.name
        val cleanName = if (rawName.endsWith(".SET", ignoreCase = true)) {
            rawName.substring(0, rawName.length - 4)
        } else {
            rawName
        }

        val childFiles = directory.listFiles() ?: emptyArray()
        if (childFiles.isEmpty()) {
            issues.add(
                SetValidationIssue(
                    ValidationSeverity.ERROR,
                    "Directory",
                    "Directory is empty: ${directory.absolutePath}"
                )
            )
            return SetInspectionReport(
                isValidSet = false,
                rootPath = directory.absolutePath,
                setName = cleanName,
                isZipArchive = false,
                issues = issues
            )
        }

        // Scan subdirectories
        for (sub in childFiles) {
            if (sub.isDirectory) {
                val subUpper = sub.name.uppercase()
                for (resType in SetResourceType.values()) {
                    if (subUpper == resType.folderName || subUpper.startsWith("${resType.folderName}.")) {
                        detectedFolders[resType] = sub.absolutePath
                        // Count files matching extension inside this folder
                        val matchingFiles = sub.walkTopDown().filter { f ->
                            f.isFile && f.name.endsWith(resType.extension, ignoreCase = true)
                        }.count()
                        resourceCounts[resType] = matchingFiles
                    }
                }
            } else if (sub.isFile) {
                // Also check if resources are placed directly in root
                for (resType in SetResourceType.values()) {
                    if (sub.name.endsWith(resType.extension, ignoreCase = true)) {
                        val current = resourceCounts.getOrDefault(resType, 0)
                        resourceCounts[resType] = current + 1
                    }
                }
            }
        }

        val hasStyles = (resourceCounts[SetResourceType.STYLE] ?: 0) > 0
        val hasSounds = (resourceCounts[SetResourceType.SOUND] ?: 0) > 0
        val hasPcm = (resourceCounts[SetResourceType.PCM] ?: 0) > 0

        // Minimum requirement for a valid KORG SET: Must have at least a Style, Sound, or PCM folder
        val isValid = hasStyles || hasSounds || hasPcm

        if (!isValid) {
            issues.add(
                SetValidationIssue(
                    ValidationSeverity.ERROR,
                    "Resources",
                    "No valid KORG Pa4X resources (.STY, .PCG, or .PCM) found in directory"
                )
            )
        } else {
            if (!hasStyles) {
                issues.add(
                    SetValidationIssue(
                        ValidationSeverity.WARNING,
                        "STYLE",
                        "SET does not contain any .STY style resources"
                    )
                )
            }
            if (!hasSounds) {
                issues.add(
                    SetValidationIssue(
                        ValidationSeverity.INFO,
                        "SOUND",
                        "SET does not contain custom .PCG sounds; will use GM/GS fallback synthesis"
                    )
                )
            }
        }

        return SetInspectionReport(
            isValidSet = isValid,
            rootPath = directory.absolutePath,
            setName = cleanName,
            isZipArchive = false,
            detectedFolders = detectedFolders,
            resourceCounts = resourceCounts,
            issues = issues
        )
    }

    /**
     * Inspects a ZIP archive containing a .SET without extracting everything to disk.
     */
    fun inspectZipArchive(zipFile: File): SetInspectionReport {
        val issues = mutableListOf<SetValidationIssue>()
        val detectedFolders = mutableMapOf<SetResourceType, String>()
        val resourceCounts = mutableMapOf<SetResourceType, Int>()

        var foundSetFolderInZip: String? = null

        val cleanName = zipFile.name
            .replace(".set.zip", "", ignoreCase = true)
            .replace(".zip", "", ignoreCase = true)
            .replace(".set", "", ignoreCase = true)

        try {
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    val segments = name.split('/').filter { it.isNotBlank() }

                    for (seg in segments) {
                        if (seg.endsWith(".SET", ignoreCase = true) && foundSetFolderInZip == null) {
                            foundSetFolderInZip = seg
                        }
                        for (resType in SetResourceType.values()) {
                            if (seg.equals(resType.folderName, ignoreCase = true)) {
                                detectedFolders[resType] = name
                            }
                        }
                    }

                    if (!entry.isDirectory) {
                        for (resType in SetResourceType.values()) {
                            if (name.endsWith(resType.extension, ignoreCase = true)) {
                                val current = resourceCounts.getOrDefault(resType, 0)
                                resourceCounts[resType] = current + 1
                            }
                        }
                    }

                    entry = zis.nextEntry
                }
            }
        } catch (e: Exception) {
            issues.add(
                SetValidationIssue(
                    ValidationSeverity.ERROR,
                    "ZipArchive",
                    "Failed to read ZIP archive: ${e.message}"
                )
            )
            return SetInspectionReport(
                isValidSet = false,
                rootPath = zipFile.absolutePath,
                setName = cleanName,
                isZipArchive = true,
                issues = issues
            )
        }

        val hasStyles = (resourceCounts[SetResourceType.STYLE] ?: 0) > 0
        val hasSounds = (resourceCounts[SetResourceType.SOUND] ?: 0) > 0
        val hasPcm = (resourceCounts[SetResourceType.PCM] ?: 0) > 0
        val isValid = hasStyles || hasSounds || hasPcm

        if (!isValid) {
            issues.add(
                SetValidationIssue(
                    ValidationSeverity.ERROR,
                    "ZipResources",
                    "No recognizable KORG Pa4X resources found inside archive: ${zipFile.name}"
                )
            )
        }

        return SetInspectionReport(
            isValidSet = isValid,
            rootPath = zipFile.absolutePath,
            setName = cleanName,
            isZipArchive = true,
            detectedFolders = detectedFolders,
            resourceCounts = resourceCounts,
            issues = issues
        )
    }
}
