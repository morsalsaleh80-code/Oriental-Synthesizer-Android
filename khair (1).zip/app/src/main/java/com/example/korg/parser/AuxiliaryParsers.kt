package com.example.korg.parser

import com.example.korg.io.KorgBinaryReader
import com.example.korg.models.IrKeyboardSet
import com.example.korg.models.IrPad
import com.example.korg.models.IrSongBookEntry
import java.io.File

/**
 * Parsers for Auxiliary KORG Pa4X resources:
 * - Multi-Pad sequences (.PAD)
 * - Keyboard Sets / STS registrations (.KST)
 * - SongBook entries (.SBD / .SBL)
 */
class AuxiliaryParsers {

    fun parsePadFile(file: File): IrPad {
        val name = file.nameWithoutExtension
        val bytes = file.readBytes()
        val reader = KorgBinaryReader.fromByteArray(bytes)

        var padName = name
        var isLooping = false
        var syncedToTempo = true

        if (reader.remaining >= 16) {
            try {
                val fourCC = reader.readFourCC()
                if (fourCC == "PAD1" || fourCC == "KORG") {
                    val flags = reader.readUByte()
                    isLooping = (flags and 0x01) != 0
                    syncedToTempo = (flags and 0x02) != 0
                    val str = reader.readFixedString(12)
                    if (str.isNotBlank()) padName = str
                }
            } catch (e: Exception) {
                // Keep default metadata
            }
        }

        return IrPad(
            id = "pad_${name.lowercase().replace(" ", "_")}",
            name = padName,
            padIndex = 1,
            syncedToTempo = syncedToTempo,
            isLooping = isLooping
        )
    }

    fun parseKeyboardSetFile(file: File): IrKeyboardSet {
        val name = file.nameWithoutExtension
        val bytes = file.readBytes()
        val reader = KorgBinaryReader.fromByteArray(bytes)

        var ksetName = name
        var splitPoint = 60
        var upper1Sound = "snd_grand_piano"
        var upper2Sound: String? = null
        var lowerSound: String? = "snd_warm_strings"

        if (reader.remaining >= 16) {
            try {
                val fourCC = reader.readFourCC()
                if (fourCC == "KST1" || fourCC == "KORG") {
                    splitPoint = reader.readUByte().coerceIn(0, 127)
                    val str = reader.readFixedString(12)
                    if (str.isNotBlank()) ksetName = str
                }
            } catch (e: Exception) {
                // Keep default registration
            }
        }

        return IrKeyboardSet(
            id = "kst_${name.lowercase().replace(" ", "_")}",
            name = ksetName,
            upper1SoundId = upper1Sound,
            upper2SoundId = upper2Sound,
            lowerSoundId = lowerSound,
            splitPointMidi = splitPoint,
            upper1Volume = 1.0f,
            lowerVolume = 0.75f
        )
    }

    fun parseSongBookFile(file: File): List<IrSongBookEntry> {
        val entries = mutableListOf<IrSongBookEntry>()
        val name = file.nameWithoutExtension
        val bytes = file.readBytes()
        val reader = KorgBinaryReader.fromByteArray(bytes)

        if (reader.remaining < 16) {
            entries.add(
                IrSongBookEntry(
                    id = "sb_entry_1",
                    title = name,
                    artist = "Traditional",
                    genre = "Pop",
                    tempoBpm = 120,
                    meter = "4/4"
                )
            )
            return entries
        }

        try {
            val fourCC = reader.readFourCC()
            val entryCount = reader.readShortBE().toInt().coerceIn(1, 100)

            for (i in 0 until entryCount) {
                if (reader.remaining < 32) break
                val title = reader.readFixedString(16).ifBlank { "Song ${i + 1}" }
                val genre = reader.readFixedString(8).ifBlank { "Standard" }
                val tempo = reader.readShortBE().toInt().coerceIn(30, 280)
                val meterNum = reader.readUByte().coerceIn(2, 12)
                val meterDenom = reader.readUByte().coerceIn(2, 16)

                entries.add(
                    IrSongBookEntry(
                        id = "sb_${name.lowercase()}_$i",
                        title = title,
                        genre = genre,
                        tempoBpm = tempo,
                        meter = "$meterNum/$meterDenom"
                    )
                )
            }
        } catch (e: Exception) {
            if (entries.isEmpty()) {
                entries.add(
                    IrSongBookEntry(
                        id = "sb_${name.lowercase()}_fallback",
                        title = name,
                        tempoBpm = 120
                    )
                )
            }
        }

        return entries
    }
}
