package com.example.korg.resolver

/**
 * Standard General MIDI (GM1 / GM2) sound map and fallback resolver.
 * Provides musical fallback mapping for missing or custom KORG Pa4X sounds and drum kits.
 */
object GmSoundMap {

    // General MIDI standard instruments (Program Numbers 0..127)
    val GM_PROGRAM_NAMES = arrayOf(
        // 0-7: Piano
        "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano",
        "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavi",
        // 8-15: Chromatic Percussion
        "Celesta", "Glockenspiel", "Music Box", "Vibraphone",
        "Marimba", "Xylophone", "Tubular Bells", "Dulcimer",
        // 16-23: Organ
        "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ",
        "Reed Organ", "Accordion", "Harmonica", "Tango Accordion",
        // 24-31: Guitar
        "Acoustic Guitar (nylon)", "Acoustic Guitar (steel)", "Electric Guitar (jazz)", "Electric Guitar (clean)",
        "Electric Guitar (muted)", "Overdriven Guitar", "Distortion Guitar", "Guitar harmonics",
        // 32-39: Bass
        "Acoustic Bass", "Electric Bass (finger)", "Electric Bass (pick)", "Fretless Bass",
        "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2",
        // 40-47: Strings
        "Violin", "Viola", "Cello", "Contrabass",
        "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani",
        // 48-55: Ensemble
        "String Ensemble 1", "String Ensemble 2", "SynthStrings 1", "SynthStrings 2",
        "Choir Aahs", "Voice Oohs", "Synth Voice", "Orchestra Hit",
        // 56-63: Brass
        "Trumpet", "Trombone", "Tuba", "Muted Trumpet",
        "French Horn", "Brass Section", "SynthBrass 1", "SynthBrass 2",
        // 64-71: Reed
        "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax",
        "Oboe", "English Horn", "Bassoon", "Clarinet",
        // 72-79: Pipe
        "Piccolo", "Flute", "Recorder", "Pan Flute",
        "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
        // 80-87: Synth Lead
        "Lead 1 (square)", "Lead 2 (sawtooth)", "Lead 3 (calliope)", "Lead 4 (chiff)",
        "Lead 5 (charang)", "Lead 6 (voice)", "Lead 7 (fifths)", "Lead 8 (bass + lead)",
        // 88-95: Synth Pad
        "Pad 1 (new age)", "Pad 2 (warm)", "Pad 3 (polysynth)", "Pad 4 (choir)",
        "Pad 5 (bowed)", "Pad 6 (metallic)", "Pad 7 (halo)", "Pad 8 (sweep)",
        // 96-103: Synth Effects
        "FX 1 (rain)", "FX 2 (soundtrack)", "FX 3 (crystal)", "FX 4 (atmosphere)",
        "FX 5 (brightness)", "FX 6 (goblins)", "FX 7 (echoes)", "FX 8 (sci-fi)",
        // 104-111: Ethnic
        "Sitar", "Banjo", "Shamisen", "Koto",
        "Kalimba", "Bagpipe", "Fiddle", "Shanai",
        // 112-119: Percussive
        "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock",
        "Taiko Drum", "Melodic Tom", "Synth Drum", "Reverse Cymbal",
        // 120-127: Sound Effects
        "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird Tweet",
        "Telephone Ring", "Helicopter", "Applause", "Gunshot"
    )

    fun getProgramName(programNumber: Int): String {
        val safeIndex = programNumber.coerceIn(0, 127)
        return GM_PROGRAM_NAMES[safeIndex]
    }

    /**
     * Resolves appropriate GM program number based on track index/role.
     */
    fun resolveFallbackForTrack(trackIndex: Int): Int {
        return when (trackIndex) {
            0 -> 0     // Drum track -> Standard Kit
            1 -> 115   // Percussion track -> Steel Drums / Agogo / Percussion
            2 -> 33    // Bass track -> Fingered Electric Bass (PC 33)
            3 -> 0     // Acc 1 -> Acoustic Grand Piano (PC 0)
            4 -> 24    // Acc 2 -> Acoustic Guitar nylon (PC 24)
            5 -> 48    // Acc 3 -> String Ensemble 1 (PC 48)
            6 -> 61    // Acc 4 -> Brass Section (PC 61)
            7 -> 81    // Acc 5 -> Synth Saw Lead (PC 81)
            else -> 0
        }
    }

    /**
     * Maps KORG Bank MSB/LSB to a standard GM fallback program number.
     */
    fun mapKorgToGmProgram(bankMsb: Int, bankLsb: Int, programNumber: Int, isDrumKit: Boolean): Int {
        if (isDrumKit) return 0 // Standard Drum Kit
        return programNumber.coerceIn(0, 127)
    }
}
