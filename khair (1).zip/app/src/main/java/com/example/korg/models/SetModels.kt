package com.example.korg.models

import com.example.engine.ArrangerSection

/**
 * Standard KORG SET resource types.
 */
enum class SetResourceType(val folderName: String, val extension: String, val description: String) {
    STYLE("STYLE", ".STY", "Accompaniment Styles"),
    SOUND("SOUND", ".PCG", "Sound Programs & Drum Kits"),
    PCM("PCM", ".PCM", "Sample Audio & Keymaps"),
    PAD("PAD", ".PAD", "Multi-Pad Sequences"),
    KEYBOARD_SET("KEYBOARDSET", ".KST", "Keyboard Registrations"),
    SONG_BOOK("SONGBOOK", ".SBD", "SongBook Database"),
    GLOBAL("GLOBAL", ".GLB", "Global Preferences")
}

/**
 * Note Translation Table (NTT) chord transformation rules for arranger tracks.
 */
enum class NttType {
    PARALLEL,   // Transpose all notes in parallel with root shift
    FIXED,      // Inversion-invariant fixed scale degree mapping
    CHORD,      // Re-voice notes based on detected chord quality
    BASS        // Root bass note tracking with Slash-chord following
}

/**
 * Severity level of validation and diagnostic issues.
 */
enum class ValidationSeverity {
    INFO,
    WARNING,
    ERROR
}

/**
 * Specific validation issue found during SET inspection or import.
 */
data class SetValidationIssue(
    val severity: ValidationSeverity,
    val component: String,
    val message: String,
    val context: String = ""
)

/**
 * Inspection report produced by SetContainerDetector.
 */
data class SetInspectionReport(
    val isValidSet: Boolean,
    val rootPath: String,
    val setName: String,
    val isZipArchive: Boolean,
    val detectedFolders: Map<SetResourceType, String> = emptyMap(),
    val resourceCounts: Map<SetResourceType, Int> = emptyMap(),
    val issues: List<SetValidationIssue> = emptyList()
)

/**
 * Time signature for musical styles.
 */
data class TimeSignature(
    val numerator: Int = 4,
    val denominator: Int = 4
) {
    override fun toString(): String = "$numerator/$denominator"
}

/**
 * Timestamped internal MIDI event representation.
 */
data class IrMidiEvent(
    val tickOffset: Long,
    val status: Int,
    val data1: Int,
    val data2: Int
)

/**
 * Note Translation Table rule definition for a style track.
 */
data class IrNttRule(
    val trackIndex: Int,
    val nttType: NttType = NttType.PARALLEL,
    val rootKey: Int = 0,         // 0 = C, 1 = C#, ...
    val chordType: String = "Maj",
    val bassFollow: Boolean = false,
    val melodyRetrigger: Boolean = true
)

/**
 * Single Chord Variation (CV) within a Style Element.
 */
data class IrChordVariation(
    val cvIndex: Int,
    val chordFormula: String,     // e.g. "Maj", "Min", "7th"
    val lengthBars: Int = 2,
    val trackEvents: Map<Int, List<IrMidiEvent>> = emptyMap() // Track index -> events
)

/**
 * Single Style Element (e.g. Variation 1, Intro 2, Ending 1).
 */
data class IrStyleElement(
    val section: ArrangerSection,
    val lengthBars: Int = 4,
    val chordVariations: List<IrChordVariation> = emptyList()
)

/**
 * Individual track configuration within a Style (Drums, Bass, Accompaniment 1-5).
 */
data class IrStyleTrack(
    val trackIndex: Int,          // 0: Drum, 1: Perc, 2: Bass, 3..7: Acc 1..5
    val name: String,
    val midiChannel: Int,         // 9..15
    val bankMsb: Int = 0,
    val bankLsb: Int = 0,
    val programNumber: Int = 0,
    val volume: Int = 100,        // 0..127
    val pan: Int = 64,            // 0..127 (64 = Center)
    val reverbSend: Int = 40,     // 0..127
    val chorusSend: Int = 0,      // 0..127
    val nttRule: IrNttRule = IrNttRule(trackIndex)
)

/**
 * Internal Representation of a KORG Style.
 */
data class IrStyle(
    val id: String,
    val name: String,
    val category: String,
    val tempoBpm: Int = 120,
    val timeSignature: TimeSignature = TimeSignature(4, 4),
    val elements: Map<ArrangerSection, IrStyleElement> = emptyMap(),
    val tracks: List<IrStyleTrack> = emptyList()
)

/**
 * Internal Representation of a Sound Program or Drum Kit.
 */
data class IrSound(
    val id: String,
    val name: String,
    val category: String,
    val bankMsb: Int,
    val bankLsb: Int,
    val programNumber: Int,
    val isDrumKit: Boolean = false,
    val gmFallbackProgram: Int = 0, // General MIDI standard fallback (0..127)
    val multisampleRefs: List<String> = emptyList(),
    val filterCutoff: Float = 1.0f, // 0.0..1.0
    val filterResonance: Float = 0.0f,
    val attackSec: Float = 0.01f,
    val decaySec: Float = 0.3f,
    val sustainLevel: Float = 0.8f,
    val releaseSec: Float = 0.2f
)

/**
 * Internal Representation of a PCM audio sample or multisample zone.
 */
data class IrSample(
    val id: String,
    val name: String,
    val sampleRate: Int = 44100,
    val channels: Int = 1,
    val bitDepth: Int = 16,
    val rootKey: Int = 60,         // Middle C
    val fineTuneCents: Int = 0,
    val loopStartSample: Long = 0,
    val loopEndSample: Long = 0,
    val totalSamples: Long = 0,
    val isLooped: Boolean = false,
    val pcmData: ByteArray? = null,
    val sourceFilePath: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as IrSample
        return id == other.id
    }

    override fun hashCode(): Int = id.hashCode()
}

/**
 * Internal Representation of a Pad sequence.
 */
data class IrPad(
    val id: String,
    val name: String,
    val padIndex: Int,             // 1..4
    val syncedToTempo: Boolean = true,
    val isLooping: Boolean = false,
    val events: List<IrMidiEvent> = emptyList()
)

/**
 * Internal Representation of a Keyboard Set (registrations for Upper 1-3 & Lower).
 */
data class IrKeyboardSet(
    val id: String,
    val name: String,
    val upper1SoundId: String,
    val upper2SoundId: String? = null,
    val upper3SoundId: String? = null,
    val lowerSoundId: String? = null,
    val splitPointMidi: Int = 60,
    val upper1Volume: Float = 1.0f,
    val upper2Volume: Float = 0.8f,
    val upper3Volume: Float = 0.0f,
    val lowerVolume: Float = 0.8f
)

/**
 * Internal Representation of a SongBook entry.
 */
data class IrSongBookEntry(
    val id: String,
    val title: String,
    val artist: String = "",
    val genre: String = "",
    val tempoBpm: Int = 120,
    val meter: String = "4/4",
    val styleRefId: String = "",
    val key: String = "C"
)

/**
 * Dependency resolution diagnostics report.
 */
data class SetDependencyReport(
    val totalDependencies: Int = 0,
    val resolvedCount: Int = 0,
    val missingCount: Int = 0,
    val fallbackCount: Int = 0,
    val unresolvedReferences: List<String> = emptyList(),
    val fallbackMappings: Map<String, String> = emptyMap()
)

/**
 * Quality & constraint validation report.
 */
data class SetValidationReport(
    val isValid: Boolean = true,
    val warnings: List<String> = emptyList(),
    val errors: List<String> = emptyList()
)

/**
 * Overall metadata for an imported KORG SET.
 */
data class Pa4xSetMetadata(
    val name: String,
    val sourcePath: String,
    val author: String = "Unknown",
    val targetModel: String = "KORG Pa4X",
    val creationTimestamp: Long = System.currentTimeMillis(),
    val setVersion: String = "1.0",
    val description: String = "",
    val totalStyles: Int = 0,
    val totalSounds: Int = 0,
    val totalSamples: Int = 0,
    val totalPads: Int = 0,
    val totalKeyboardSets: Int = 0,
    val totalSongBookEntries: Int = 0
)

/**
 * The complete, versioned, application-owned Internal Representation of a KORG SET.
 */
data class Pa4xSetPackage(
    val metadata: Pa4xSetMetadata,
    val styles: List<IrStyle> = emptyList(),
    val sounds: List<IrSound> = emptyList(),
    val samples: List<IrSample> = emptyList(),
    val pads: List<IrPad> = emptyList(),
    val keyboardSets: List<IrKeyboardSet> = emptyList(),
    val songBook: List<IrSongBookEntry> = emptyList(),
    val dependencyReport: SetDependencyReport = SetDependencyReport(),
    val validationReport: SetValidationReport = SetValidationReport()
)

/**
 * Lightweight summary for display in library / preset selectors.
 */
data class SetSummary(
    val id: String,
    val name: String,
    val path: String,
    val styleCount: Int,
    val soundCount: Int,
    val isDemo: Boolean = false,
    val isValid: Boolean = true
)

/**
 * Import progress state for UI feedback during background SET ingestion.
 */
data class ImportProgress(
    val phase: String,
    val currentStep: Int,
    val totalSteps: Int,
    val progressPercent: Float,
    val currentItemName: String = "",
    val isComplete: Boolean = false,
    val errorMessage: String? = null
)
