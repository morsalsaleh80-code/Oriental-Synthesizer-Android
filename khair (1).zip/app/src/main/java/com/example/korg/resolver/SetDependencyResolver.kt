package com.example.korg.resolver

import com.example.korg.models.*

/**
 * Cross-resource dependency resolver and fallback mapper for KORG Pa4X SET resources.
 *
 * Resolves relationships between:
 * 1. Style tracks -> Sound Programs / Drum Kits (falling back to GM/GS when absent)
 * 2. Sound Programs -> PCM audio samples & Multisamples (falling back to synthesizer oscillators)
 * 3. Keyboard Sets -> Sounds
 * 4. SongBook entries -> Styles
 */
class SetDependencyResolver {

    fun resolveDependencies(
        styles: List<IrStyle>,
        sounds: List<IrSound>,
        samples: List<IrSample>,
        keyboardSets: List<IrKeyboardSet>,
        songBook: List<IrSongBookEntry>
    ): SetDependencyReport {
        var totalDeps = 0
        var resolvedCount = 0
        var fallbackCount = 0
        var missingCount = 0
        val unresolvedList = mutableListOf<String>()
        val fallbackMappings = mutableMapOf<String, String>()

        val soundMap = sounds.associateBy { it.id }
        val soundByProgram = sounds.associateBy { it.programNumber }
        val sampleMap = samples.associateBy { it.id }
        val styleMap = styles.associateBy { it.id }

        // 1. Resolve Style Track -> Sound dependencies
        for (style in styles) {
            for (track in style.tracks) {
                totalDeps++
                val directSound = soundByProgram[track.programNumber]
                if (directSound != null) {
                    resolvedCount++
                } else {
                    // Fallback to General MIDI
                    fallbackCount++
                    val gmProgram = GmSoundMap.resolveFallbackForTrack(track.trackIndex)
                    val gmName = GmSoundMap.getProgramName(gmProgram)
                    val refKey = "${style.name}:Track[${track.name}] Prog ${track.programNumber}"
                    fallbackMappings[refKey] = "GM Program $gmProgram ($gmName)"
                }
            }
        }

        // 2. Resolve Sound -> Sample/Multisample dependencies
        for (sound in sounds) {
            for (sampleRef in sound.multisampleRefs) {
                totalDeps++
                if (sampleMap.containsKey(sampleRef) || sampleMap.containsKey("smp_$sampleRef")) {
                    resolvedCount++
                } else {
                    // Fallback to synthesized oscillator
                    fallbackCount++
                    val refKey = "Sound[${sound.name}] SampleRef $sampleRef"
                    fallbackMappings[refKey] = "Synthesizer Oscillator Fallback"
                }
            }
        }

        // 3. Resolve Keyboard Set -> Sound dependencies
        for (kset in keyboardSets) {
            totalDeps++
            if (soundMap.containsKey(kset.upper1SoundId) || soundByProgram.containsKey(0)) {
                resolvedCount++
            } else {
                missingCount++
                unresolvedList.add("KeyboardSet[${kset.name}] missing Upper1 Sound: ${kset.upper1SoundId}")
            }
        }

        // 4. Resolve SongBook -> Style dependencies
        for (entry in songBook) {
            if (entry.styleRefId.isNotBlank()) {
                totalDeps++
                if (styleMap.containsKey(entry.styleRefId)) {
                    resolvedCount++
                } else {
                    fallbackCount++
                    val refKey = "SongBook[${entry.title}] Style ${entry.styleRefId}"
                    fallbackMappings[refKey] = "Default Factory Style (${styles.firstOrNull()?.name ?: "Pop"})"
                }
            }
        }

        return SetDependencyReport(
            totalDependencies = totalDeps,
            resolvedCount = resolvedCount,
            missingCount = missingCount,
            fallbackCount = fallbackCount,
            unresolvedReferences = unresolvedList,
            fallbackMappings = fallbackMappings
        )
    }
}
