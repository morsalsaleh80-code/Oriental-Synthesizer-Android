package com.example.korg.repository

import com.example.engine.ArrangerSection
import com.example.korg.detector.SetContainerDetector
import com.example.korg.models.*
import com.example.korg.parser.AuxiliaryParsers
import com.example.korg.parser.PcmParser
import com.example.korg.parser.SoundParser
import com.example.korg.parser.StyleParser
import com.example.korg.resolver.SetDependencyResolver
import com.example.korg.validator.SetValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Repository interface for managing and loading KORG Pa4X SET packages.
 */
interface SetRepository {
    val loadedSets: StateFlow<List<SetSummary>>
    val activeSetPackage: StateFlow<Pa4xSetPackage?>
    val importProgress: StateFlow<ImportProgress?>

    suspend fun loadSetFromDirectory(directory: File): Result<Pa4xSetPackage>
    suspend fun loadDemoPa4xSet(): Pa4xSetPackage
    fun selectActiveSet(setId: String): Boolean
    fun getActiveStyle(styleId: String): IrStyle?
}

/**
 * Production implementation of SetRepository.
 *
 * Runs all parsing and disk I/O on Dispatchers.IO to maintain hard real-time safety.
 */
class SetRepositoryImpl(
    private val detector: SetContainerDetector = SetContainerDetector(),
    private val styleParser: StyleParser = StyleParser(),
    private val soundParser: SoundParser = SoundParser(),
    private val pcmParser: PcmParser = PcmParser(),
    private val auxiliaryParsers: AuxiliaryParsers = AuxiliaryParsers(),
    private val dependencyResolver: SetDependencyResolver = SetDependencyResolver(),
    private val validator: SetValidator = SetValidator()
) : SetRepository {

    private val cachedPackages = mutableMapOf<String, Pa4xSetPackage>()

    private val _loadedSets = MutableStateFlow<List<SetSummary>>(emptyList())
    override val loadedSets: StateFlow<List<SetSummary>> = _loadedSets.asStateFlow()

    private val _activeSetPackage = MutableStateFlow<Pa4xSetPackage?>(null)
    override val activeSetPackage: StateFlow<Pa4xSetPackage?> = _activeSetPackage.asStateFlow()

    private val _importProgress = MutableStateFlow<ImportProgress?>(null)
    override val importProgress: StateFlow<ImportProgress?> = _importProgress.asStateFlow()

    init {
        // Initialize with default factory demo SET
        val demoPackage = createFactoryDemoSet()
        cachedPackages[demoPackage.metadata.name] = demoPackage
        _activeSetPackage.value = demoPackage
        updateSummaries()
    }

    override suspend fun loadSetFromDirectory(directory: File): Result<Pa4xSetPackage> = withContext(Dispatchers.IO) {
        try {
            _importProgress.value = ImportProgress("Detecting Container", 1, 6, 0.15f, directory.name)

            val report = detector.inspectDirectory(directory)
            if (!report.isValidSet) {
                val errorMsg = report.issues.firstOrNull { it.severity == ValidationSeverity.ERROR }?.message
                    ?: "Invalid KORG Pa4X SET directory"
                _importProgress.value = ImportProgress("Error", 1, 6, 0.0f, errorMessage = errorMsg)
                return@withContext Result.failure(IllegalArgumentException(errorMsg))
            }

            // Parse Styles
            _importProgress.value = ImportProgress("Parsing Styles", 2, 6, 0.35f)
            val parsedStyles = mutableListOf<IrStyle>()
            val styleFolder = report.detectedFolders[SetResourceType.STYLE]?.let { File(it) }
            if (styleFolder != null && styleFolder.exists()) {
                val styleFiles = styleFolder.walkTopDown().filter { it.isFile && it.name.endsWith(".STY", ignoreCase = true) }
                for (sf in styleFiles) {
                    try {
                        parsedStyles.add(styleParser.parseStyleFile(sf))
                    } catch (e: Exception) {
                        // Skip corrupted file
                    }
                }
            }

            // Parse Sounds (.PCG)
            _importProgress.value = ImportProgress("Parsing Sounds", 3, 6, 0.55f)
            val parsedSounds = mutableListOf<IrSound>()
            val soundFolder = report.detectedFolders[SetResourceType.SOUND]?.let { File(it) }
            if (soundFolder != null && soundFolder.exists()) {
                val pcgFiles = soundFolder.walkTopDown().filter { it.isFile && it.name.endsWith(".PCG", ignoreCase = true) }
                for (pf in pcgFiles) {
                    try {
                        parsedSounds.addAll(soundParser.parsePcgFile(pf))
                    } catch (e: Exception) {
                        // Skip
                    }
                }
            }

            // Parse PCM Samples (.PCM / .KMP / .KSF)
            _importProgress.value = ImportProgress("Parsing PCM Samples", 4, 6, 0.70f)
            val parsedSamples = mutableListOf<IrSample>()
            val pcmFolder = report.detectedFolders[SetResourceType.PCM]?.let { File(it) }
            if (pcmFolder != null && pcmFolder.exists()) {
                val pcmFiles = pcmFolder.walkTopDown().filter { it.isFile && (it.name.endsWith(".PCM", ignoreCase = true) || it.name.endsWith(".KSF", ignoreCase = true)) }
                for (pm in pcmFiles) {
                    try {
                        parsedSamples.add(pcmParser.parsePcmFile(pm))
                    } catch (e: Exception) {
                        // Skip
                    }
                }
            }

            // Parse Pads, KeyboardSets, SongBook
            val parsedPads = mutableListOf<IrPad>()
            val padFolder = report.detectedFolders[SetResourceType.PAD]?.let { File(it) }
            if (padFolder != null && padFolder.exists()) {
                for (f in padFolder.walkTopDown().filter { it.isFile && it.name.endsWith(".PAD", ignoreCase = true) }) {
                    try { parsedPads.add(auxiliaryParsers.parsePadFile(f)) } catch (e: Exception) {}
                }
            }

            val parsedKsets = mutableListOf<IrKeyboardSet>()
            val ksetFolder = report.detectedFolders[SetResourceType.KEYBOARD_SET]?.let { File(it) }
            if (ksetFolder != null && ksetFolder.exists()) {
                for (f in ksetFolder.walkTopDown().filter { it.isFile && it.name.endsWith(".KST", ignoreCase = true) }) {
                    try { parsedKsets.add(auxiliaryParsers.parseKeyboardSetFile(f)) } catch (e: Exception) {}
                }
            }

            val parsedSongBook = mutableListOf<IrSongBookEntry>()
            val sbFolder = report.detectedFolders[SetResourceType.SONG_BOOK]?.let { File(it) }
            if (sbFolder != null && sbFolder.exists()) {
                for (f in sbFolder.walkTopDown().filter { it.isFile && (it.name.endsWith(".SBD", ignoreCase = true) || it.name.endsWith(".SBL", ignoreCase = true)) }) {
                    try { parsedSongBook.addAll(auxiliaryParsers.parseSongBookFile(f)) } catch (e: Exception) {}
                }
            }

            // Dependency Resolution
            _importProgress.value = ImportProgress("Resolving Dependencies", 5, 6, 0.85f)
            val depReport = dependencyResolver.resolveDependencies(
                parsedStyles, parsedSounds, parsedSamples, parsedKsets, parsedSongBook
            )

            val metadata = Pa4xSetMetadata(
                name = report.setName,
                sourcePath = directory.absolutePath,
                author = "KORG User",
                targetModel = "KORG Pa4X",
                totalStyles = parsedStyles.size,
                totalSounds = parsedSounds.size,
                totalSamples = parsedSamples.size,
                totalPads = parsedPads.size,
                totalKeyboardSets = parsedKsets.size,
                totalSongBookEntries = parsedSongBook.size
            )

            var rawPackage = Pa4xSetPackage(
                metadata = metadata,
                styles = parsedStyles,
                sounds = parsedSounds,
                samples = parsedSamples,
                pads = parsedPads,
                keyboardSets = parsedKsets,
                songBook = parsedSongBook,
                dependencyReport = depReport
            )

            // Validation
            _importProgress.value = ImportProgress("Validating Package", 6, 6, 0.95f)
            val validationReport = validator.validate(rawPackage)
            val finalPackage = rawPackage.copy(validationReport = validationReport)

            cachedPackages[finalPackage.metadata.name] = finalPackage
            _activeSetPackage.value = finalPackage
            updateSummaries()

            _importProgress.value = ImportProgress("Complete", 6, 6, 1.0f, isComplete = true)
            Result.success(finalPackage)
        } catch (e: Exception) {
            _importProgress.value = ImportProgress("Failed", 0, 6, 0.0f, errorMessage = e.message)
            Result.failure(e)
        }
    }

    override suspend fun loadDemoPa4xSet(): Pa4xSetPackage {
        val demo = createFactoryDemoSet()
        cachedPackages[demo.metadata.name] = demo
        _activeSetPackage.value = demo
        updateSummaries()
        return demo
    }

    override fun selectActiveSet(setId: String): Boolean {
        val found = cachedPackages[setId]
        if (found != null) {
            _activeSetPackage.value = found
            return true
        }
        return false
    }

    override fun getActiveStyle(styleId: String): IrStyle? {
        return _activeSetPackage.value?.styles?.firstOrNull { it.id == styleId }
    }

    private fun updateSummaries() {
        val summaries = cachedPackages.values.map { pkg ->
            SetSummary(
                id = pkg.metadata.name,
                name = pkg.metadata.name,
                path = pkg.metadata.sourcePath,
                styleCount = pkg.styles.size,
                soundCount = pkg.sounds.size,
                isDemo = pkg.metadata.name.contains("Demo", ignoreCase = true),
                isValid = pkg.validationReport.isValid
            )
        }
        _loadedSets.value = summaries
    }

    /**
     * Builds the factory reference Pa4X demonstration SET containing styles,
     * sounds, registrations, and SongBook records.
     */
    fun createFactoryDemoSet(): Pa4xSetPackage {
        // Pop Ballad Style
        val popBallad = createStyle(
            id = "style_pop_ballad",
            name = "Pa4X Pop Ballad",
            category = "Ballad",
            tempo = 78,
            timeSig = TimeSignature(4, 4)
        )

        // Dance Club Style
        val danceClub = createStyle(
            id = "style_dance_club",
            name = "Pa4X Club Dance",
            category = "Dance",
            tempo = 128,
            timeSig = TimeSignature(4, 4)
        )

        // Oriental Saidi Style
        val orientalSaidi = createStyle(
            id = "style_oriental_saidi",
            name = "Pa4X Oriental Saidi",
            category = "Oriental",
            tempo = 115,
            timeSig = TimeSignature(4, 4)
        )

        // Latin Bossa Style
        val latinBossa = createStyle(
            id = "style_latin_bossa",
            name = "Pa4X Latin Bossa",
            category = "Latin",
            tempo = 135,
            timeSig = TimeSignature(4, 4)
        )

        val styles = listOf(popBallad, danceClub, orientalSaidi, latinBossa)

        // Factory Sounds
        val sounds = listOf(
            IrSound(
                id = "snd_german_grand",
                name = "German Grand Pa4X",
                category = "Piano",
                bankMsb = 121,
                bankLsb = 0,
                programNumber = 0,
                gmFallbackProgram = 0,
                filterCutoff = 0.95f,
                filterResonance = 0.1f,
                attackSec = 0.005f,
                decaySec = 1.6f,
                sustainLevel = 0.6f,
                releaseSec = 0.35f
            ),
            IrSound(
                id = "snd_real_strings",
                name = "Pa4X Real Strings",
                category = "Strings",
                bankMsb = 121,
                bankLsb = 0,
                programNumber = 48,
                gmFallbackProgram = 48,
                filterCutoff = 0.9f,
                filterResonance = 0.05f,
                attackSec = 0.15f,
                decaySec = 0.6f,
                sustainLevel = 0.9f,
                releaseSec = 0.5f
            ),
            IrSound(
                id = "snd_slap_bass",
                name = "Pa4X Slap Bass Pro",
                category = "Bass",
                bankMsb = 121,
                bankLsb = 0,
                programNumber = 36,
                gmFallbackProgram = 36,
                filterCutoff = 0.85f,
                filterResonance = 0.3f,
                attackSec = 0.005f,
                decaySec = 0.5f,
                sustainLevel = 0.3f,
                releaseSec = 0.15f
            ),
            IrSound(
                id = "snd_pop_kit",
                name = "Pa4X Standard Pop Kit",
                category = "Drum Kit",
                bankMsb = 120,
                bankLsb = 0,
                programNumber = 0,
                isDrumKit = true,
                gmFallbackProgram = 0
            )
        )

        // Factory Samples with verified 16-bit linear PCM audio data
        val samples = listOf(
            PcmParser.createAcousticReferenceSample(
                sampleName = "Grand Piano C4 PCM",
                sampleRate = 44100,
                rootKey = 60,
                durationSeconds = 1.0f
            ),
            PcmParser.createAcousticReferenceSample(
                sampleName = "Symphonic Strings C4",
                sampleRate = 44100,
                rootKey = 60,
                durationSeconds = 1.0f
            )
        )

        // Keyboard Sets
        val ksets = listOf(
            IrKeyboardSet(
                id = "kst_ballad_piano",
                name = "Concert Piano & Strings",
                upper1SoundId = "snd_german_grand",
                upper2SoundId = "snd_real_strings",
                lowerSoundId = "snd_real_strings",
                splitPointMidi = 60
            )
        )

        // SongBook
        val songBook = listOf(
            IrSongBookEntry(
                id = "sb_1",
                title = "Imagine Ballad",
                artist = "Lennon",
                genre = "Pop Ballad",
                tempoBpm = 78,
                meter = "4/4",
                styleRefId = "style_pop_ballad",
                key = "C"
            ),
            IrSongBookEntry(
                id = "sb_2",
                title = "Oriental Night",
                artist = "Farid",
                genre = "Oriental",
                tempoBpm = 115,
                meter = "4/4",
                styleRefId = "style_oriental_saidi",
                key = "D"
            )
        )

        val metadata = Pa4xSetMetadata(
            name = "Pa4X Factory Reference SET",
            sourcePath = "embedded://Pa4X_Factory.SET",
            author = "KORG Pa4X Compatible Engine",
            targetModel = "KORG Pa4X",
            description = "Reference Pa4X SET featuring Ballad, Dance, Oriental, and Latin styles with GM/GS fallback synthesis",
            totalStyles = styles.size,
            totalSounds = sounds.size,
            totalSamples = samples.size,
            totalPads = 4,
            totalKeyboardSets = ksets.size,
            totalSongBookEntries = songBook.size
        )

        val depReport = dependencyResolver.resolveDependencies(styles, sounds, samples, ksets, songBook)
        val packageInstance = Pa4xSetPackage(
            metadata = metadata,
            styles = styles,
            sounds = sounds,
            samples = samples,
            pads = listOf(
                IrPad("pad_1", "Perc Loop 1", 1),
                IrPad("pad_2", "Perc Loop 2", 2),
                IrPad("pad_3", "Synth Riff", 3),
                IrPad("pad_4", "Crash FX", 4)
            ),
            keyboardSets = ksets,
            songBook = songBook,
            dependencyReport = depReport
        )

        val validation = validator.validate(packageInstance)
        return packageInstance.copy(validationReport = validation)
    }

    private fun createStyle(
        id: String,
        name: String,
        category: String,
        tempo: Int,
        timeSig: TimeSignature
    ): IrStyle {
        val tracks = com.example.engine.FactoryStylePatternGenerator.createStandardFactoryTracks()

        val elements = mutableMapOf<ArrangerSection, IrStyleElement>()
        for (section in ArrangerSection.values()) {
            val bars = when (section) {
                ArrangerSection.INTRO_1, ArrangerSection.ENDING_1 -> 4
                ArrangerSection.VARIATION_1, ArrangerSection.VARIATION_2, ArrangerSection.VARIATION_3, ArrangerSection.VARIATION_4 -> 4
                ArrangerSection.FILL_1, ArrangerSection.FILL_2, ArrangerSection.FILL_3, ArrangerSection.FILL_4, ArrangerSection.BREAK -> 1
                else -> 2
            }
            elements[section] = com.example.engine.FactoryStylePatternGenerator.createFullStyleElement(section, bars)
        }

        return IrStyle(
            id = id,
            name = name,
            category = category,
            tempoBpm = tempo,
            timeSignature = timeSig,
            elements = elements,
            tracks = tracks
        )
    }
}
