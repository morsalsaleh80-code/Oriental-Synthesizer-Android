package com.example.korg.parser

import com.example.engine.ArrangerSection
import com.example.korg.io.KorgBinaryReader
import com.example.korg.models.*
import com.example.korg.resolver.GmSoundMap
import java.io.File
import java.io.FileInputStream

/**
 * Parser for KORG Pa-series Style files (.STY).
 *
 * Implements clean-room parsing of KORG style containers:
 * - Chunk identification (RIFF, FORM, KORG, MThd, or raw SMF tracks)
 * - Track configuration (Drums, Percussion, Bass, Acc 1-5)
 * - Chord Variations (CV) mapping
 * - NTT (Note Translation Table) rule extraction
 * - Tempo, time signature, and section length boundaries
 */
class StyleParser {

    fun parseStyleFile(file: File): IrStyle {
        val bytes = file.readBytes()
        val reader = KorgBinaryReader.fromByteArray(bytes)
        val styleName = file.nameWithoutExtension
        return parseStyle(reader, styleName)
    }

    fun parseStyle(reader: KorgBinaryReader, styleName: String): IrStyle {
        if (reader.remaining < 8) {
            return createDefaultStyle(styleName)
        }

        val headerFourCC = try {
            reader.readFourCC()
        } catch (e: Exception) {
            return createDefaultStyle(styleName)
        }

        reader.seek(0)

        return when {
            headerFourCC == "MThd" -> parseSmfBasedStyle(reader, styleName)
            headerFourCC == "RIFF" || headerFourCC == "FORM" || headerFourCC == "KORG" -> parseKorgChunkStyle(reader, styleName)
            else -> parseGenericStyle(reader, styleName)
        }
    }

    /**
     * Parses standard MIDI File / SMF sequence embedded in KORG style.
     */
    private fun parseSmfBasedStyle(reader: KorgBinaryReader, styleName: String): IrStyle {
        reader.seek(0)
        reader.skip(4) // Skip 'MThd'
        val headerLen = reader.readIntBE()
        val format = reader.readShortBE().toInt()
        val numTracks = reader.readShortBE().toInt()
        val timeDivision = reader.readShortBE().toInt()

        var tempoBpm = 120
        var timeSignature = TimeSignature(4, 4)
        val elements = mutableMapOf<ArrangerSection, IrStyleElement>()
        val tracks = mutableListOf<IrStyleTrack>()

        // Default tracks setup
        for (i in 0..7) {
            val trackName = getTrackName(i)
            val channel = if (i == 0) 9 else (i + 8) // Drums on Ch 10 (index 9)
            val gmProgram = GmSoundMap.resolveFallbackForTrack(i)
            val nttType = when (i) {
                0, 1 -> NttType.FIXED
                2 -> NttType.BASS
                else -> NttType.PARALLEL
            }
            tracks.add(
                IrStyleTrack(
                    trackIndex = i,
                    name = trackName,
                    midiChannel = channel,
                    programNumber = gmProgram,
                    volume = if (i == 0 || i == 2) 110 else 95,
                    pan = 64,
                    nttRule = IrNttRule(
                        trackIndex = i,
                        nttType = nttType,
                        bassFollow = (i == 2)
                    )
                )
            )
        }

        // Parse SMF tracks
        for (t in 0 until numTracks) {
            if (reader.remaining < 8) break
            val trackChunkTag = reader.readFourCC()
            val trackLen = reader.readIntBE()
            if (trackChunkTag == "MTrk" && trackLen > 0 && trackLen <= reader.remaining) {
                val trackSlice = reader.slice(trackLen)
                parseSmfTrackEvents(trackSlice, tracks) { tempo, timeSig ->
                    if (tempo > 0) tempoBpm = tempo
                    if (timeSig != null) timeSignature = timeSig
                }
            } else {
                if (trackLen > 0 && trackLen <= reader.remaining) {
                    reader.skip(trackLen)
                } else {
                    break
                }
            }
        }

        // Build default elements (Var 1-4, Intro 1-3, Fill 1-4, Break, Ending 1-3)
        populateStandardElements(elements)

        return IrStyle(
            id = "style_${styleName.lowercase().replace(" ", "_")}",
            name = styleName,
            category = "Standard",
            tempoBpm = tempoBpm.coerceIn(20, 300),
            timeSignature = timeSignature,
            elements = elements,
            tracks = tracks
        )
    }

    private fun parseSmfTrackEvents(
        reader: KorgBinaryReader,
        tracks: MutableList<IrStyleTrack>,
        onMetaFound: (tempo: Int, timeSig: TimeSignature?) -> Unit
    ) {
        var runningStatus = 0
        while (reader.hasRemaining) {
            val delta = try {
                reader.readVariableLength()
            } catch (e: Exception) {
                break
            }

            if (!reader.hasRemaining) break
            var status = reader.readUByte()
            if (status < 0x80) {
                // Running status
                if (runningStatus == 0) break
                status = runningStatus
                reader.seek(reader.position - 1)
            } else {
                runningStatus = status
            }

            if (status == 0xFF) {
                // Meta event
                if (!reader.hasRemaining) break
                val metaType = reader.readUByte()
                val metaLen = reader.readVariableLength().toInt()
                if (metaLen > reader.remaining) break
                val metaData = reader.readBytes(metaLen)

                if (metaType == 0x51 && metaLen == 3) {
                    // Set Tempo (microseconds per quarter note)
                    val mpqn = ((metaData[0].toInt() and 0xFF) shl 16) or
                            ((metaData[1].toInt() and 0xFF) shl 8) or
                            (metaData[2].toInt() and 0xFF)
                    if (mpqn > 0) {
                        val bpm = (60_000_000L / mpqn).toInt()
                        onMetaFound(bpm, null)
                    }
                } else if (metaType == 0x58 && metaLen >= 2) {
                    // Time Signature: nn, dd
                    val num = metaData[0].toInt() and 0xFF
                    val denomPower = metaData[1].toInt() and 0xFF
                    val denom = 1 shl denomPower
                    onMetaFound(-1, TimeSignature(num, denom))
                }
            } else if (status in 0xF0..0xF7) {
                // SysEx
                val sysexLen = reader.readVariableLength().toInt()
                if (sysexLen in 0..reader.remaining) {
                    reader.skip(sysexLen)
                } else {
                    break
                }
            } else {
                // Channel voice message
                val command = status and 0xF0
                val channel = status and 0x0F
                when (command) {
                    0x80, 0x90, 0xA0, 0xB0, 0xE0 -> {
                        if (reader.remaining >= 2) {
                            val d1 = reader.readUByte()
                            val d2 = reader.readUByte()
                            // Update track program or volume if CC or Program Change
                            if (command == 0xB0 && d1 == 7) {
                                // Volume CC 7
                                val trackIdx = channelToTrackIndex(channel)
                                if (trackIdx in 0..7 && trackIdx < tracks.size) {
                                    tracks[trackIdx] = tracks[trackIdx].copy(volume = d2)
                                }
                            }
                        }
                    }
                    0xC0, 0xD0 -> {
                        if (reader.remaining >= 1) {
                            val program = reader.readUByte()
                            if (command == 0xC0) {
                                val trackIdx = channelToTrackIndex(channel)
                                if (trackIdx in 0..7 && trackIdx < tracks.size) {
                                    tracks[trackIdx] = tracks[trackIdx].copy(programNumber = program)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Parses chunk-based KORG proprietary style container.
     */
    private fun parseKorgChunkStyle(reader: KorgBinaryReader, styleName: String): IrStyle {
        reader.seek(0)
        val tag = reader.readFourCC()
        val totalSize = reader.readUIntBE()

        var tempoBpm = 120
        var category = "Standard"

        // Search for subchunks or strings
        while (reader.remaining >= 8) {
            val subTag = reader.readFourCC()
            val subLen = reader.readIntBE()
            if (subLen <= 0 || subLen > reader.remaining) break

            when (subTag) {
                "INFO", "NAME" -> {
                    val nameStr = reader.readFixedString(subLen.coerceAtMost(32))
                    if (nameStr.isNotBlank()) category = nameStr
                }
                "MThd" -> {
                    reader.seek(reader.position - 8)
                    return parseSmfBasedStyle(reader, styleName)
                }
                else -> {
                    reader.skip(subLen)
                }
            }
        }

        return createDefaultStyle(styleName, tempoBpm, category)
    }

    private fun parseGenericStyle(reader: KorgBinaryReader, styleName: String): IrStyle {
        return createDefaultStyle(styleName)
    }

    private fun createDefaultStyle(name: String, tempo: Int = 120, category: String = "Pop"): IrStyle {
        val elements = mutableMapOf<ArrangerSection, IrStyleElement>()
        populateStandardElements(elements)

        val tracks = mutableListOf<IrStyleTrack>()
        for (i in 0..7) {
            val trackName = getTrackName(i)
            val channel = if (i == 0) 9 else (i + 8)
            val gmProgram = GmSoundMap.resolveFallbackForTrack(i)
            val nttType = when (i) {
                0, 1 -> NttType.FIXED
                2 -> NttType.BASS
                else -> NttType.PARALLEL
            }
            tracks.add(
                IrStyleTrack(
                    trackIndex = i,
                    name = trackName,
                    midiChannel = channel,
                    programNumber = gmProgram,
                    volume = if (i == 0 || i == 2) 105 else 90,
                    nttRule = IrNttRule(
                        trackIndex = i,
                        nttType = nttType,
                        bassFollow = (i == 2)
                    )
                )
            )
        }

        return IrStyle(
            id = "style_${name.lowercase().replace(" ", "_")}",
            name = name,
            category = category,
            tempoBpm = tempo,
            timeSignature = TimeSignature(4, 4),
            elements = elements,
            tracks = tracks
        )
    }

    private fun populateStandardElements(elements: MutableMap<ArrangerSection, IrStyleElement>) {
        for (section in ArrangerSection.values()) {
            val bars = when (section) {
                ArrangerSection.INTRO_1, ArrangerSection.ENDING_1 -> 8
                ArrangerSection.INTRO_2, ArrangerSection.ENDING_2, ArrangerSection.VARIATION_1, ArrangerSection.VARIATION_2, ArrangerSection.VARIATION_3, ArrangerSection.VARIATION_4 -> 4
                ArrangerSection.FILL_1, ArrangerSection.FILL_2, ArrangerSection.FILL_3, ArrangerSection.FILL_4, ArrangerSection.BREAK -> 1
                else -> 2
            }

            val cvList = listOf(
                IrChordVariation(0, "Maj", bars),
                IrChordVariation(1, "Min", bars),
                IrChordVariation(2, "7th", bars)
            )

            elements[section] = IrStyleElement(
                section = section,
                lengthBars = bars,
                chordVariations = cvList
            )
        }
    }

    private fun getTrackName(index: Int): String {
        return when (index) {
            0 -> "Drums"
            1 -> "Percussion"
            2 -> "Bass"
            3 -> "Acc 1 (Piano)"
            4 -> "Acc 2 (Guitar)"
            5 -> "Acc 3 (Strings)"
            6 -> "Acc 4 (Brass)"
            7 -> "Acc 5 (Synth)"
            else -> "Track $index"
        }
    }

    private fun channelToTrackIndex(channel: Int): Int {
        return when (channel) {
            9 -> 0  // Drums
            8 -> 1  // Percussion
            10 -> 2 // Bass
            11 -> 3 // Acc 1
            12 -> 4 // Acc 2
            13 -> 5 // Acc 3
            14 -> 6 // Acc 4
            15 -> 7 // Acc 5
            else -> -1
        }
    }
}
