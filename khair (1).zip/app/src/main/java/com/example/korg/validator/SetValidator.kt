package com.example.korg.validator

import com.example.korg.models.Pa4xSetPackage
import com.example.korg.models.SetValidationReport

/**
 * Validates an imported Pa4xSetPackage against real-time workstation constraints:
 * - Musical tempo and time signature bounds
 * - MIDI channel, note, and velocity boundaries
 * - Audio sample rate and loop point integrity
 * - Memory and resource bounds
 */
class SetValidator {

    fun validate(setPackage: Pa4xSetPackage): SetValidationReport {
        val warnings = mutableListOf<String>()
        val errors = mutableListOf<String>()

        // 1. Validate Styles
        if (setPackage.styles.isEmpty()) {
            warnings.add("SET package contains 0 styles.")
        }

        for (style in setPackage.styles) {
            if (style.tempoBpm !in 20..300) {
                errors.add("Style '${style.name}' has invalid tempo: ${style.tempoBpm} BPM (must be 20-300)")
            }

            if (style.timeSignature.numerator !in 1..32 || style.timeSignature.denominator !in listOf(1, 2, 4, 8, 16, 32)) {
                errors.add("Style '${style.name}' has invalid time signature: ${style.timeSignature}")
            }

            if (style.tracks.isEmpty()) {
                warnings.add("Style '${style.name}' has no tracks configured.")
            }

            for (track in style.tracks) {
                if (track.midiChannel !in 0..15) {
                    errors.add("Style '${style.name}' track '${track.name}' has invalid MIDI channel: ${track.midiChannel}")
                }
                if (track.volume !in 0..127) {
                    warnings.add("Style '${style.name}' track '${track.name}' volume ${track.volume} clamped to 0..127")
                }
            }
        }

        // 2. Validate Sounds
        for (sound in setPackage.sounds) {
            if (sound.attackSec < 0.0f || sound.decaySec < 0.0f || sound.releaseSec < 0.0f) {
                errors.add("Sound '${sound.name}' has negative envelope time parameters")
            }
            if (sound.filterCutoff !in 0.0f..1.0f) {
                warnings.add("Sound '${sound.name}' filter cutoff ${sound.filterCutoff} outside 0.0..1.0")
            }
        }

        // 3. Validate Samples
        for (sample in setPackage.samples) {
            if (sample.sampleRate !in 8000..96000) {
                errors.add("Sample '${sample.name}' has unsupported sample rate: ${sample.sampleRate} Hz")
            }

            if (sample.isLooped) {
                if (sample.loopStartSample < 0 || sample.loopEndSample < sample.loopStartSample) {
                    errors.add("Sample '${sample.name}' has invalid loop markers: start=${sample.loopStartSample}, end=${sample.loopEndSample}")
                }
            }
        }

        // Overall validity: Valid if 0 fatal errors
        val isValid = errors.isEmpty()

        return SetValidationReport(
            isValid = isValid,
            warnings = warnings,
            errors = errors
        )
    }
}
