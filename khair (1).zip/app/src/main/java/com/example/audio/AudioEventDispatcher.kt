package com.example.audio

/**
 * Interface for dispatching MIDI notes and performance events to the audio rendering pipeline.
 * Implemented by NativeAudioBridge for real Oboe rendering and Mock/Test implementations for JVM tests.
 */
interface AudioEventDispatcher {
    val isAvailable: Boolean
    fun sendNoteOn(note: Int, velocity: Int, channel: Int, centOffset: Float = 0.0f): Boolean
    fun sendNoteOff(note: Int, channel: Int): Boolean
    fun sendAllNotesOff(): Boolean
    fun sendPitchBend(bendSemitones: Float): Boolean
    fun sendModulation(modValue: Float): Boolean
    fun sendParamChange(paramId: Int, paramValueInt: Int, paramValueFloat: Float): Boolean
    fun setMasterVolume(volume: Float)
}
