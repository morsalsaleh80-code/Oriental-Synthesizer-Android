package com.example.audio

import android.util.Log

data class AudioDiagnosticsData(
    val xrunCount: Int = 0,
    val cpuLoad: Float = 0.0f,
    val activeVoices: Int = 0,
    val bufferFrames: Int = 0,
    val sampleRate: Int = 48000,
    val peakMeterL: Float = 0.0f,
    val peakMeterR: Float = 0.0f,
    val callbackDurationNs: Long = 0L,
    val hardwareLatencyMs: Float = 0.0f
)

object NativeAudioBridge : AudioEventDispatcher {
    private const val TAG = "NativeAudioBridge"
    private var isLibraryLoaded = false

    init {
        try {
            System.loadLibrary("native-audio")
            isLibraryLoaded = true
            try {
                Log.i(TAG, "libnative-audio.so successfully loaded.")
            } catch (ignored: Throwable) {}
        } catch (t: Throwable) {
            // JVM unit test environment does not contain Android .so library
        }
    }

    override val isAvailable: Boolean
        get() = isLibraryLoaded

    external fun initEngine()
    external fun destroyEngine()
    external fun startEngine(): Boolean
    external fun stopEngine()

    override external fun sendNoteOn(note: Int, velocity: Int, channel: Int, centOffset: Float): Boolean
    override external fun sendNoteOff(note: Int, channel: Int): Boolean
    override external fun sendPitchBend(bendSemitones: Float): Boolean
    override external fun sendModulation(modValue: Float): Boolean
    override external fun sendParamChange(paramId: Int, paramValueInt: Int, paramValueFloat: Float): Boolean
    override external fun sendAllNotesOff(): Boolean
    override external fun setMasterVolume(volume: Float)

    // PCM Sample loading and management
    external fun loadPcmSample16(
        slot: Int,
        sampleRate: Int,
        channels: Int,
        rootKey: Int,
        fineTuneCents: Int,
        loopStart: Int,
        loopEnd: Int,
        isLooped: Boolean,
        pcmBytes: ByteArray
    ): Boolean

    external fun loadPcmSampleFloat(
        slot: Int,
        sampleRate: Int,
        channels: Int,
        rootKey: Int,
        fineTuneCents: Int,
        loopStart: Int,
        loopEnd: Int,
        isLooped: Boolean,
        sampleFloats: FloatArray
    ): Boolean

    external fun clearPcmSamples()
    external fun isPcmSampleLoaded(slot: Int): Boolean
    external fun setActivePcmSlot(slot: Int)

    fun loadIrSample(sample: com.example.korg.models.IrSample, slot: Int = 0): Boolean {
        if (!isLibraryLoaded) return false
        val bytes = sample.pcmData ?: return false
        return loadPcmSample16(
            slot = slot,
            sampleRate = sample.sampleRate,
            channels = sample.channels,
            rootKey = sample.rootKey,
            fineTuneCents = sample.fineTuneCents,
            loopStart = sample.loopStartSample.toInt(),
            loopEnd = sample.loopEndSample.toInt(),
            isLooped = sample.isLooped,
            pcmBytes = bytes
        )
    }

    private external fun getDiagnostics(outArray: FloatArray)

    private val diagnosticsBuffer = FloatArray(9)

    @Synchronized
    fun pollDiagnostics(): AudioDiagnosticsData {
        if (!isLibraryLoaded) return AudioDiagnosticsData()
        getDiagnostics(diagnosticsBuffer)
        return AudioDiagnosticsData(
            xrunCount = diagnosticsBuffer[0].toInt(),
            cpuLoad = diagnosticsBuffer[1],
            activeVoices = diagnosticsBuffer[2].toInt(),
            bufferFrames = diagnosticsBuffer[3].toInt(),
            sampleRate = diagnosticsBuffer[4].toInt(),
            peakMeterL = diagnosticsBuffer[5],
            peakMeterR = diagnosticsBuffer[6],
            callbackDurationNs = diagnosticsBuffer[7].toLong(),
            hardwareLatencyMs = diagnosticsBuffer[8]
        )
    }
}
