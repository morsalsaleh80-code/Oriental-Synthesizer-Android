package com.example

import com.example.engine.ChordQuality
import com.example.engine.NoteName
import com.example.engine.NoteTranslationEngine
import com.example.korg.models.NttType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Deterministic Unit Tests for Note Translation Table (NTT) Engine.
 *
 * Tests:
 * 1. PARALLEL transformation across multiple root shifts
 * 2. FIXED transformation (retains octave and chord tone proximity)
 * 3. BASS transformation (clamped to natural bass register, slash-chord bass following)
 * 4. CHORD transformation across qualities: Maj, Min, 7th, m7, Maj7, Dim, Aug, Sus4
 * 5. Boundary safety clamping (0..127)
 */
class NoteTranslationEngineTest {

    private lateinit var nttEngine: NoteTranslationEngine

    @Before
    fun setUp() {
        nttEngine = NoteTranslationEngine()
    }

    @Test
    fun testParallelTransformation() {
        // Source C (0), Note C4 (60)
        // Target D (2), Major -> Note should be D4 (62)
        val transformedD = nttEngine.transformNote(
            originalNote = 60,
            nttType = NttType.PARALLEL,
            sourceRoot = 0,
            targetRoot = NoteName.D,
            targetQuality = ChordQuality.MAJOR
        )
        assertEquals(62, transformedD)

        // Target G (7), Major -> Note should be G4 (67)
        val transformedG = nttEngine.transformNote(
            originalNote = 60,
            nttType = NttType.PARALLEL,
            sourceRoot = 0,
            targetRoot = NoteName.G,
            targetQuality = ChordQuality.MAJOR
        )
        assertEquals(67, transformedG)
    }

    @Test
    fun testBassTransformationAndSlashBass() {
        // Base note C2 (36)
        // Target F Major (root F=5)
        val bassF = nttEngine.transformNote(
            originalNote = 36,
            nttType = NttType.BASS,
            targetRoot = NoteName.F,
            targetQuality = ChordQuality.MAJOR,
            targetBass = NoteName.F,
            bassFollow = false
        )
        // F pitch class in range 28..55 -> 41 (F2) or 29 (F1)
        assertEquals(5, bassF % 12)
        assertTrue("Bass must be in bass range", bassF in 28..55)

        // Slash chord: C / G (Target Root C, Bass G)
        val slashBassG = nttEngine.transformNote(
            originalNote = 36,
            nttType = NttType.BASS,
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.MAJOR,
            targetBass = NoteName.G,
            bassFollow = true
        )
        assertEquals(7, slashBassG % 12)
        assertTrue("Slash bass must follow target bass G", slashBassG in 28..55)
    }

    @Test
    fun testChordTransformationMajorToMinor() {
        // Source C Maj: Root C4 (60), Third E4 (64), Fifth G4 (67)
        // In C Minor: Third should become Eb4 (63)
        val minorThird = nttEngine.transformNote(
            originalNote = 64, // E4 (3rd of C Maj)
            nttType = NttType.CHORD,
            sourceRoot = 0,
            sourceQuality = "Maj",
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.MINOR
        )
        assertEquals(63, minorThird) // Eb4
    }

    @Test
    fun testChordTransformationDominant7th() {
        // In C7, 7th degree is Bb (10)
        val dom7 = nttEngine.transformNote(
            originalNote = 60, // Root
            nttType = NttType.CHORD,
            sourceRoot = 0,
            sourceQuality = "Maj",
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.DOMINANT_7TH
        )
        assertEquals(60, dom7) // Root stays C4
    }

    @Test
    fun testChordTransformationSus4() {
        // In Csus4, 3rd is replaced by 4th (F=5)
        val sus4Note = nttEngine.transformNote(
            originalNote = 64, // E4 (3rd)
            nttType = NttType.CHORD,
            sourceRoot = 0,
            sourceQuality = "Maj",
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.SUSPENDED_4TH
        )
        assertEquals(65, sus4Note) // F4
    }

    @Test
    fun testFixedTransformationRegisterPreservation() {
        // Fixed mode prevents octave jumps
        val fixedNote = nttEngine.transformNote(
            originalNote = 64, // E4
            nttType = NttType.FIXED,
            sourceRoot = 0,
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.MAJOR
        )
        assertEquals(64, fixedNote) // Remains E4 since it fits C Major
    }

    @Test
    fun testNoteClampingBounds() {
        val clampedHigh = nttEngine.transformNote(
            originalNote = 126,
            nttType = NttType.PARALLEL,
            sourceRoot = 0,
            targetRoot = NoteName.B,
            targetQuality = ChordQuality.MAJOR
        )
        assertTrue(clampedHigh <= 127)

        val clampedLow = nttEngine.transformNote(
            originalNote = 2,
            nttType = NttType.PARALLEL,
            sourceRoot = 11,
            targetRoot = NoteName.C,
            targetQuality = ChordQuality.MAJOR
        )
        assertTrue(clampedLow >= 0)
    }
}
