package com.example

import com.example.engine.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ChordRecognitionUnitTest {

    private lateinit var recognizer: ChordRecognizer
    private lateinit var chordEngine: ArrangerChordEngine

    @Before
    fun setup() {
        recognizer = ChordRecognizer()
        chordEngine = ArrangerChordEngine(recognizer)
    }

    @Test
    fun testMajorChordRecognition() {
        // C Major: C4 (60), E4 (64), G4 (67)
        val chord = recognizer.recognize(listOf(60, 64, 67), ChordRecognitionMode.FINGERED)
        assertNotNull(chord)
        assertEquals(NoteName.C, chord!!.root)
        assertEquals(ChordQuality.MAJOR, chord.quality)
        assertEquals(NoteName.C, chord.bass)
        assertFalse(chord.isSlashChord)
        assertEquals("C", chord.formattedName)
    }

    @Test
    fun testMinorChordRecognition() {
        // A Minor: A3 (57), C4 (60), E4 (64)
        val chord = recognizer.recognize(listOf(57, 60, 64), ChordRecognitionMode.FINGERED)
        assertNotNull(chord)
        assertEquals(NoteName.A, chord!!.root)
        assertEquals(ChordQuality.MINOR, chord.quality)
        assertEquals(NoteName.A, chord.bass)
        assertEquals("Am", chord.formattedName)
    }

    @Test
    fun testDominant7thChordRecognition() {
        // G Dominant 7th: G3 (55), B3 (59), D4 (62), F4 (65)
        val chord = recognizer.recognize(listOf(55, 59, 62, 65), ChordRecognitionMode.FINGERED)
        assertNotNull(chord)
        assertEquals(NoteName.G, chord!!.root)
        assertEquals(ChordQuality.DOMINANT_7TH, chord.quality)
        assertEquals("G7", chord.formattedName)
    }

    @Test
    fun testMajor7thChordRecognition() {
        // F Major 7th: F3 (53), A3 (57), C4 (60), E4 (64)
        val chord = recognizer.recognize(listOf(53, 57, 60, 64), ChordRecognitionMode.FINGERED)
        assertNotNull(chord)
        assertEquals(NoteName.F, chord!!.root)
        assertEquals(ChordQuality.MAJOR_7TH, chord.quality)
        assertEquals("FMaj7", chord.formattedName)
    }

    @Test
    fun testMinor7thChordRecognition() {
        // D Minor 7th: D4 (62), F4 (65), A4 (69), C5 (72)
        val chord = recognizer.recognize(listOf(62, 65, 69, 72), ChordRecognitionMode.FINGERED)
        assertNotNull(chord)
        assertEquals(NoteName.D, chord!!.root)
        assertEquals(ChordQuality.MINOR_7TH, chord.quality)
        assertEquals("Dm7", chord.formattedName)
    }

    @Test
    fun testDiminishedAndAugmentedChords() {
        // B Diminished: B3 (59), D4 (62), F4 (65)
        val dim = recognizer.recognize(listOf(59, 62, 65), ChordRecognitionMode.FINGERED)
        assertNotNull(dim)
        assertEquals(NoteName.B, dim!!.root)
        assertEquals(ChordQuality.DIMINISHED, dim.quality)
        assertEquals("Bdim", dim.formattedName)

        // C Augmented: C4 (60), E4 (64), G#4 (68)
        val aug = recognizer.recognize(listOf(60, 64, 68), ChordRecognitionMode.FINGERED)
        assertNotNull(aug)
        assertEquals(NoteName.C, aug!!.root)
        assertEquals(ChordQuality.AUGMENTED, aug.quality)
        assertEquals("Caug", aug.formattedName)
    }

    @Test
    fun testSuspendedChords() {
        // C Sus4: C4 (60), F4 (65), G4 (67)
        val sus4 = recognizer.recognize(listOf(60, 65, 67), ChordRecognitionMode.FINGERED)
        assertNotNull(sus4)
        assertEquals(NoteName.C, sus4!!.root)
        assertEquals(ChordQuality.SUSPENDED_4TH, sus4.quality)
        assertEquals("Csus4", sus4.formattedName)

        // D Sus2: D4 (62), E4 (64), A4 (69)
        val sus2 = recognizer.recognize(listOf(62, 64, 69), ChordRecognitionMode.FINGERED)
        assertNotNull(sus2)
        assertEquals(NoteName.D, sus2!!.root)
        assertEquals(ChordQuality.SUSPENDED_2ND, sus2.quality)
        assertEquals("Dsus2", sus2.formattedName)
    }

    @Test
    fun testInversionsAndSlashChords() {
        // C Major 1st Inversion (E in bass): E3 (52), G3 (55), C4 (60)
        val cOverE = recognizer.recognize(listOf(52, 55, 60), ChordRecognitionMode.FINGERED)
        assertNotNull(cOverE)
        assertEquals(NoteName.C, cOverE!!.root)
        assertEquals(ChordQuality.MAJOR, cOverE.quality)
        assertEquals(NoteName.E, cOverE.bass)
        assertTrue(cOverE.isSlashChord)
        assertEquals("C/E", cOverE.formattedName)

        // G Major 1st Inversion (B in bass): B3 (59), D4 (62), G4 (67)
        val gOverB = recognizer.recognize(listOf(59, 62, 67), ChordRecognitionMode.FINGERED)
        assertNotNull(gOverB)
        assertEquals(NoteName.G, gOverB!!.root)
        assertEquals(ChordQuality.MAJOR, gOverB.quality)
        assertEquals(NoteName.B, gOverB.bass)
        assertEquals("G/B", gOverB.formattedName)
    }

    @Test
    fun testOneFingerEZChordRecognition() {
        // Single root note C4 (60) -> C Major
        val cMaj = recognizer.recognize(listOf(60), ChordRecognitionMode.ONE_FINGER)
        assertNotNull(cMaj)
        assertEquals(NoteName.C, cMaj!!.root)
        assertEquals(ChordQuality.MAJOR, cMaj.quality)

        // Root C4 (60) + black key to left (Bb3: 58) -> C Minor
        val cMin = recognizer.recognize(listOf(58, 60), ChordRecognitionMode.ONE_FINGER)
        assertNotNull(cMin)
        assertEquals(NoteName.C, cMin!!.root)
        assertEquals(ChordQuality.MINOR, cMin.quality)

        // Root C4 (60) + white key to left (B3: 59) -> C Dominant 7th
        val c7 = recognizer.recognize(listOf(59, 60), ChordRecognitionMode.ONE_FINGER)
        assertNotNull(c7)
        assertEquals(NoteName.C, c7!!.root)
        assertEquals(ChordQuality.DOMINANT_7TH, c7.quality)

        // Root C4 (60) + white key (59) + black key (58) -> C Minor 7th
        val cm7 = recognizer.recognize(listOf(58, 59, 60), ChordRecognitionMode.ONE_FINGER)
        assertNotNull(cm7)
        assertEquals(NoteName.C, cm7!!.root)
        assertEquals(ChordQuality.MINOR_7TH, cm7.quality)
    }

    @Test
    fun testArrangerChordEngineSplitAndMemory() {
        chordEngine.splitPointMidi = 60 // C4
        chordEngine.isMemoryEnabled = true

        // Play C Major below split: C3 (48), E3 (52), G3 (55)
        val note1Consumed = chordEngine.onNoteOn(48)
        val note2Consumed = chordEngine.onNoteOn(52)
        val note3Consumed = chordEngine.onNoteOn(55)

        assertTrue(note1Consumed)
        assertTrue(note2Consumed)
        assertTrue(note3Consumed)
        assertEquals(NoteName.C, chordEngine.currentChord.root)
        assertEquals(ChordQuality.MAJOR, chordEngine.currentChord.quality)

        // Note above split should not be consumed by chord zone
        val upperNoteConsumed = chordEngine.onNoteOn(64) // E4
        assertFalse("Upper note must not be consumed by chord zone", upperNoteConsumed)

        // Release lower notes: with memory enabled, chord must remain latched!
        chordEngine.onNoteOff(48)
        chordEngine.onNoteOff(52)
        chordEngine.onNoteOff(55)

        assertEquals("Chord must remain latched when Memory is ON", NoteName.C, chordEngine.currentChord.root)
        assertEquals(ChordQuality.MAJOR, chordEngine.currentChord.quality)

        // Now play F Major below split: F3 (53), A3 (57), C4 (not included), just F3 and A3
        chordEngine.onNoteOn(53)
        chordEngine.onNoteOn(57)
        assertEquals(NoteName.F, chordEngine.currentChord.root)
        assertEquals(ChordQuality.MAJOR, chordEngine.currentChord.quality)
    }
}
