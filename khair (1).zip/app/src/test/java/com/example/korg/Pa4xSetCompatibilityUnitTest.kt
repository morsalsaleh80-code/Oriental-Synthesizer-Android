package com.example.korg

import com.example.engine.ArrangerSection
import com.example.korg.detector.SetContainerDetector
import com.example.korg.io.KorgBinaryReadException
import com.example.korg.io.KorgBinaryReader
import com.example.korg.models.*
import com.example.korg.parser.AuxiliaryParsers
import com.example.korg.parser.PcmParser
import com.example.korg.parser.SoundParser
import com.example.korg.parser.StyleParser
import com.example.korg.repository.SetRepositoryImpl
import com.example.korg.resolver.GmSoundMap
import com.example.korg.resolver.SetDependencyResolver
import com.example.korg.validator.SetValidator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.ByteOrder

class Pa4xSetCompatibilityUnitTest {

    private lateinit var detector: SetContainerDetector
    private lateinit var styleParser: StyleParser
    private lateinit var soundParser: SoundParser
    private lateinit var pcmParser: PcmParser
    private lateinit var auxParsers: AuxiliaryParsers
    private lateinit var resolver: SetDependencyResolver
    private lateinit var validator: SetValidator
    private lateinit var repository: SetRepositoryImpl

    @Before
    fun setUp() {
        detector = SetContainerDetector()
        styleParser = StyleParser()
        soundParser = SoundParser()
        pcmParser = PcmParser()
        auxParsers = AuxiliaryParsers()
        resolver = SetDependencyResolver()
        validator = SetValidator()
        repository = SetRepositoryImpl(
            detector, styleParser, soundParser, pcmParser, auxParsers, resolver, validator
        )
    }

    @Test
    fun testKorgBinaryReader_EndiannessAndPrimitives() {
        val data = byteArrayOf(
            0x12, 0x34, 0x56, 0x78,             // 32-bit int
            0x41, 0x42, 0x43, 0x44,             // ASCII "ABCD"
            0x00, 0x7F,                         // 16-bit short
            0x81.toByte(), 0x00                 // MIDI VLQ: 128
        )
        val reader = KorgBinaryReader.fromByteArray(data)

        // Read Big-Endian Int
        val intBE = reader.readIntBE()
        assertEquals(0x12345678, intBE)

        // Read FourCC
        val fourCC = reader.readFourCC()
        assertEquals("ABCD", fourCC)

        // Read Short BE
        val shortBE = reader.readShortBE().toInt()
        assertEquals(127, shortBE)

        // Read Variable Length Quantity
        val vlq = reader.readVariableLength()
        assertEquals(128L, vlq)
    }

    @Test
    fun testKorgBinaryReader_BoundsSafety() {
        val data = byteArrayOf(0x01, 0x02)
        val reader = KorgBinaryReader.fromByteArray(data)

        assertEquals(1, reader.readUByte())
        assertEquals(2, reader.readUByte())

        // Buffer underflow should throw KorgBinaryReadException, never crash the JVM
        assertThrows(KorgBinaryReadException::class.java) {
            reader.readIntBE()
        }
    }

    @Test
    fun testKorgBinaryReader_SliceAndStrings() {
        val strBytes = "KORG Pa4X Workstation\u0000ExtraBytes".toByteArray(Charsets.ISO_8859_1)
        val reader = KorgBinaryReader.fromByteArray(strBytes)

        val str = reader.readFixedString(10)
        assertEquals("KORG Pa4X", str)

        val childSlice = reader.slice(10)
        assertEquals(10, childSlice.remaining)
    }

    @Test
    fun testSetContainerDetector_InvalidPath() {
        val report = detector.inspectPath("/non/existent/path.SET")
        assertFalse(report.isValidSet)
        assertTrue(report.issues.any { it.severity == ValidationSeverity.ERROR })
    }

    @Test
    fun testSetContainerDetector_SyntheticSetFolder() {
        val tempDir = File.createTempFile("TEST_PA4X", ".SET")
        tempDir.delete()
        tempDir.mkdirs()

        try {
            val styleFolder = File(tempDir, "STYLE").apply { mkdirs() }
            File(styleFolder, "BALLAD.STY").writeBytes(byteArrayOf(0x4D, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 1, 0, 1, 0, 96))

            val soundFolder = File(tempDir, "SOUND").apply { mkdirs() }
            File(soundFolder, "USER01.PCG").writeBytes(byteArrayOf(0x50, 0x43, 0x47, 0x31, 0, 0, 0, 10))

            val report = detector.inspectDirectory(tempDir)
            assertTrue(report.isValidSet)
            assertTrue(report.setName.startsWith("TEST_PA4X"))
            assertEquals(1, report.resourceCounts[SetResourceType.STYLE])
            assertEquals(1, report.resourceCounts[SetResourceType.SOUND])
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun testGmSoundMap_FallbackMappings() {
        assertEquals("Acoustic Grand Piano", GmSoundMap.getProgramName(0))
        assertEquals("Electric Bass (finger)", GmSoundMap.getProgramName(33))
        assertEquals("String Ensemble 1", GmSoundMap.getProgramName(48))

        // Role-based fallbacks
        assertEquals(0, GmSoundMap.resolveFallbackForTrack(0))   // Drum
        assertEquals(33, GmSoundMap.resolveFallbackForTrack(2))  // Bass
        assertEquals(24, GmSoundMap.resolveFallbackForTrack(4))  // Guitar
    }

    @Test
    fun testStyleParser_TrackStructureAndNttRules() {
        val mockData = byteArrayOf(
            0x4B, 0x4F, 0x52, 0x47, // 'KORG'
            0x00, 0x00, 0x00, 0x20  // Length
        )
        val reader = KorgBinaryReader.fromByteArray(mockData)
        val style = styleParser.parseStyle(reader, "Test Ballad")

        assertEquals("Test Ballad", style.name)
        assertEquals(120, style.tempoBpm)
        assertEquals(8, style.tracks.size)

        // Drum Track
        val drumTrack = style.tracks[0]
        assertEquals("Drums", drumTrack.name)
        assertEquals(9, drumTrack.midiChannel)
        assertEquals(NttType.FIXED, drumTrack.nttRule.nttType)

        // Bass Track
        val bassTrack = style.tracks[2]
        assertEquals("Bass", bassTrack.name)
        assertEquals(10, bassTrack.midiChannel)
        assertEquals(NttType.BASS, bassTrack.nttRule.nttType)
        assertTrue(bassTrack.nttRule.bassFollow)

        // Accompaniment tracks have elements (Var 1-4, Intro 1-3, Fill 1-4, Break, Ending 1-3)
        assertEquals(15, style.elements.size)
        assertTrue(style.elements.containsKey(ArrangerSection.VARIATION_1))
        assertTrue(style.elements.containsKey(ArrangerSection.INTRO_1))
        assertTrue(style.elements.containsKey(ArrangerSection.ENDING_1))
    }

    @Test
    fun testSoundParser_PcgSynthesisParameters() {
        val mockData = byteArrayOf(
            0x50, 0x43, 0x47, 0x31, // 'PCG1'
            0x00, 0x00, 0x00, 0x20
        )
        val reader = KorgBinaryReader.fromByteArray(mockData)
        val sounds = soundParser.parsePcg(reader, "USER1")

        assertTrue(sounds.isNotEmpty())
        val firstSound = sounds[0]
        assertTrue(firstSound.filterCutoff in 0.0f..1.0f)
        assertTrue(firstSound.attackSec >= 0.0f)
        assertTrue(firstSound.releaseSec >= 0.0f)
    }

    @Test
    fun testPcmParser_WaveSampleHeader() {
        // Construct minimal valid RIFF WAVE header with 'fmt ' and 'data'
        val waveData = byteArrayOf(
            0x52, 0x49, 0x46, 0x46, // 'RIFF'
            0x24, 0x00, 0x00, 0x00, // file size
            0x57, 0x41, 0x56, 0x45, // 'WAVE'
            0x66, 0x6D, 0x74, 0x20, // 'fmt '
            0x10, 0x00, 0x00, 0x00, // chunk size (16)
            0x01, 0x00,             // PCM format
            0x01, 0x00,             // 1 channel (mono)
            0x44, 0xAC.toByte(), 0x00, 0x00, // 44100 Hz
            0x88.toByte(), 0x58, 0x01, 0x00, // byte rate
            0x02, 0x00,             // block align
            0x10, 0x00,             // 16 bits
            0x64, 0x61, 0x74, 0x61, // 'data'
            0x04, 0x00, 0x00, 0x00, // 4 bytes data
            0x00, 0x00, 0x00, 0x00  // sample data
        )
        val reader = KorgBinaryReader.fromByteArray(waveData)
        val sample = pcmParser.parseSample(reader, "GrandPianoC4")

        assertEquals("GrandPianoC4", sample.name)
        assertEquals(44100, sample.sampleRate)
        assertEquals(1, sample.channels)
        assertEquals(16, sample.bitDepth)
        assertEquals(2L, sample.totalSamples)
    }

    @Test
    fun testSetDependencyResolver_ResolvesAndFallbacks() {
        val styles = listOf(
            IrStyle(
                id = "style_test",
                name = "Test Style",
                category = "Pop",
                tempoBpm = 120,
                tracks = listOf(
                    IrStyleTrack(0, "Drums", 9, programNumber = 0),
                    IrStyleTrack(2, "Bass", 10, programNumber = 999) // Non-existent program
                )
            )
        )
        val sounds = listOf(
            IrSound(
                id = "snd_drum",
                name = "Pop Kit",
                category = "Drums",
                bankMsb = 120,
                bankLsb = 0,
                programNumber = 0,
                isDrumKit = true,
                multisampleRefs = listOf("missing_sample_ref")
            )
        )
        val samples = emptyList<IrSample>()

        val report = resolver.resolveDependencies(styles, sounds, samples, emptyList(), emptyList())

        // Drum was direct resolved, Bass program 999 got GM fallback, missing sample got oscillator fallback
        assertEquals(3, report.totalDependencies)
        assertEquals(1, report.resolvedCount)
        assertEquals(2, report.fallbackCount)
        assertTrue(report.fallbackMappings.values.any { it.contains("GM Program") })
        assertTrue(report.fallbackMappings.values.any { it.contains("Synthesizer Oscillator") })
    }

    @Test
    fun testSetValidator_ConstraintChecking() {
        val validDemo = repository.createFactoryDemoSet()
        val validReport = validator.validate(validDemo)
        assertTrue(validReport.isValid)
        assertTrue(validReport.errors.isEmpty())

        // Create corrupt package with out-of-bounds tempo and negative envelope
        val corruptPackage = validDemo.copy(
            styles = listOf(validDemo.styles[0].copy(tempoBpm = 450)), // Invalid BPM > 300
            sounds = listOf(validDemo.sounds[0].copy(attackSec = -0.5f)) // Negative attack
        )
        val invalidReport = validator.validate(corruptPackage)
        assertFalse(invalidReport.isValid)
        assertEquals(2, invalidReport.errors.size)
        assertTrue(invalidReport.errors.any { it.contains("invalid tempo") })
        assertTrue(invalidReport.errors.any { it.contains("negative envelope") })
    }

    @Test
    fun testSetRepository_FactoryDemoSetAndStyleSelection() = runBlocking {
        val activePkg = repository.activeSetPackage.value
        assertNotNull(activePkg)
        assertEquals("Pa4X Factory Reference SET", activePkg?.metadata?.name)
        assertTrue((activePkg?.styles?.size ?: 0) >= 4)

        // Check style selection
        val balladStyle = repository.getActiveStyle("style_pop_ballad")
        assertNotNull(balladStyle)
        assertEquals(78, balladStyle?.tempoBpm)
        assertEquals(8, balladStyle?.tracks?.size)

        // Check loaded sets summary
        val summaries = repository.loadedSets.value
        assertTrue(summaries.isNotEmpty())
        assertEquals("Pa4X Factory Reference SET", summaries[0].name)
        assertTrue(summaries[0].isValid)
    }
}
