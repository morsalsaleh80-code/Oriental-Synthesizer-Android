package com.example

import com.example.audio.NativeAudioBridge
import com.example.engine.ArrangerSection
import com.example.engine.ChordQuality
import com.example.engine.FactoryStylePatternGenerator
import com.example.engine.NoteName
import com.example.engine.NoteTranslationEngine
import com.example.engine.RecognizedChord
import com.example.engine.StyleSequencer
import com.example.korg.repository.SetRepositoryImpl
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Deterministic Unit Tests for StyleSequencer & Real-Time Arranger Engine.
 *
 * Verifies:
 * 1. Transport Start / Stop / Tempo synchronization
 * 2. Section switching & loop boundaries
 * 3. Automatic transition from Fill/Break back to the preceding Variation
 * 4. Factory pattern generation integrity across all 8 tracks
 * 5. Track mute and solo routing
 */
@OptIn(ExperimentalCoroutinesApi::class)
class StyleSequencerTest {

    private lateinit var sequencer: StyleSequencer
    private val testDispatcher = UnconfinedTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    private val mockAudioDispatcher = object : com.example.audio.AudioEventDispatcher {
        override val isAvailable: Boolean = true
        override fun sendNoteOn(note: Int, velocity: Int, channel: Int, centOffset: Float): Boolean = true
        override fun sendNoteOff(note: Int, channel: Int): Boolean = true
        override fun sendAllNotesOff(): Boolean = true
        override fun sendPitchBend(bendSemitones: Float): Boolean = true
        override fun sendModulation(modValue: Float): Boolean = true
        override fun sendParamChange(paramId: Int, paramValueInt: Int, paramValueFloat: Float): Boolean = true
        override fun setMasterVolume(volume: Float) {}
    }

    @Before
    fun setUp() {
        sequencer = StyleSequencer(
            audioBridge = mockAudioDispatcher,
            nttEngine = NoteTranslationEngine(),
            scope = testScope
        )
    }

    @Test
    fun testFactoryPatternGenerationIntegrity() {
        val tracks = FactoryStylePatternGenerator.createStandardFactoryTracks()
        assertEquals("Standard factory style must have 8 tracks", 8, tracks.size)

        // Verify drum track on MIDI channel 9 and bass on 10
        assertEquals(9, tracks[0].midiChannel)
        assertEquals(10, tracks[2].midiChannel)

        // Generate full variation 1
        val element = FactoryStylePatternGenerator.createFullStyleElement(ArrangerSection.VARIATION_1, 4)
        assertEquals(ArrangerSection.VARIATION_1, element.section)
        assertEquals(4, element.lengthBars)
        assertTrue(element.chordVariations.isNotEmpty())

        val cv0Events = element.chordVariations[0].trackEvents
        // Check drums and bass have musical events
        assertTrue("Track 0 (Drums) must contain events", cv0Events[0]?.isNotEmpty() == true)
        assertTrue("Track 2 (Bass) must contain events", cv0Events[2]?.isNotEmpty() == true)
        assertTrue("Track 3 (Piano) must contain events", cv0Events[3]?.isNotEmpty() == true)
    }

    @Test
    fun testSequencerStartAndStop() {
        assertFalse(sequencer.isPlaying.value)

        sequencer.start()
        assertTrue(sequencer.isPlaying.value)

        sequencer.stop()
        assertFalse(sequencer.isPlaying.value)
    }

    @Test
    fun testTempoAdjustment() {
        sequencer.setTempo(140)
        assertEquals(140, sequencer.currentTempoBpm.value)

        // Clamp checks
        sequencer.setTempo(20)
        assertEquals(40, sequencer.currentTempoBpm.value)

        sequencer.setTempo(350)
        assertEquals(300, sequencer.currentTempoBpm.value)
    }

    @Test
    fun testSectionSelectionImmediate() {
        sequencer.selectSection(ArrangerSection.VARIATION_2, immediate = true)
        assertEquals(ArrangerSection.VARIATION_2, sequencer.currentSection.value)

        sequencer.selectSection(ArrangerSection.FILL_1, immediate = true)
        assertEquals(ArrangerSection.FILL_1, sequencer.currentSection.value)
    }

    @Test
    fun testFillReturnsToPreviousVariation() = runTest(testDispatcher) {
        val repo = SetRepositoryImpl()
        val demoPkg = repo.loadDemoPa4xSet()
        val style = demoPkg.styles.first()
        sequencer.setStyle(style)

        // Set initial variation to VAR 2
        sequencer.selectSection(ArrangerSection.VARIATION_2, immediate = true)

        // Trigger Fill 1
        sequencer.selectSection(ArrangerSection.FILL_1, immediate = true)
        assertEquals(ArrangerSection.FILL_1, sequencer.currentSection.value)

        // Advance past 1 bar of Fill 1 (1 bar = 4 beats = 4 * 480 ticks = 1920 ticks)
        sequencer.advanceClock(1920L)

        // Sequencer must automatically return to VARIATION_2!
        assertEquals(ArrangerSection.VARIATION_2, sequencer.currentSection.value)
    }

    @Test
    fun testTrackMutingAndSoloing() {
        assertFalse(sequencer.isTrackMuted(0))
        sequencer.setTrackMute(0, true)
        assertTrue(sequencer.isTrackMuted(0))

        sequencer.setTrackMute(0, false)
        assertFalse(sequencer.isTrackMuted(0))
    }

    @Test
    fun testChordUpdateIntegration() {
        val newChord = RecognizedChord(NoteName.A, ChordQuality.MINOR)
        sequencer.setChord(newChord)
        // Verify sequencer accepts chord without throwing
        assertTrue(true)
    }

    @Test
    fun testSynchroStartAndStopIntegration() {
        val controller = com.example.engine.PerformanceController(audioBridge = mockAudioDispatcher)
        // Default state: synchro start disabled, stopped
        assertFalse(controller.uiState.value.isSynchroStartEnabled)
        assertFalse(controller.uiState.value.isSynchroStopEnabled)
        assertFalse(controller.uiState.value.isArrangerPlaying)

        // Toggle Synchro Start & Synchro Stop
        controller.toggleSynchroStart()
        controller.toggleSynchroStop()
        assertTrue(controller.uiState.value.isSynchroStartEnabled)
        assertTrue(controller.uiState.value.isSynchroStopEnabled)

        // Striking a chord note below split point triggers Synchro Start
        controller.onNoteOn(48, 100) // C3 < 60
        assertTrue("Arranger should start via Synchro Start", controller.uiState.value.isArrangerPlaying)

        // Releasing chord note triggers Synchro Stop
        controller.onNoteOff(48)
        assertFalse("Arranger should stop via Synchro Stop", controller.uiState.value.isArrangerPlaying)
    }
}
