package com.example

import com.example.audio.AudioDiagnosticsData
import com.example.engine.ArrangerSection
import com.example.engine.ScalePreset
import kotlin.math.pow
import org.junit.Assert.*
import org.junit.Test

class WorkstationEngineUnitTest {

    @Test
    fun testScalePresetsStructure() {
        for (preset in ScalePreset.values()) {
            assertEquals("Preset ${preset.name} must define exactly 12 chromatic offsets", 12, preset.offsets.size)
        }

        // Verify 12-TET has 0 offset on all notes
        val equal = ScalePreset.EQUAL_TEMPERAMENT
        assertTrue("12-TET must have all 0 offsets", equal.offsets.all { it == 0 })

        // Verify Bayati on D detunes E (index 4) and B (index 11) by -50 cents
        val bayati = ScalePreset.BAYATI_D
        assertEquals(-50, bayati.offsets[4]) // E
        assertEquals(-50, bayati.offsets[11]) // B
    }

    @Test
    fun testMicrotonalFrequencyCalculation() {
        // Standard A4 = 440 Hz (MIDI note 69)
        val standardA4 = 440.0 * 2.0.pow((69 - 69) / 12.0)
        assertEquals(440.0, standardA4, 0.001)

        // A4 with -50 cents (quarter-tone flat)
        // 50 cents = 0.5 semitone flat
        val quarterFlatA4 = 440.0 * 2.0.pow((69.0 - 0.5 - 69.0) / 12.0)
        assertTrue("Detuned frequency should be lower than standard 440Hz", quarterFlatA4 < 440.0)
        // 440 * 2^(-0.5/12) ≈ 427.474 Hz
        assertEquals(427.474, quarterFlatA4, 0.01)
    }

    @Test
    fun testOctaveTransposeAndClamping() {
        val baseNote = 60 // Middle C
        val octaveShift = -2
        val shiftedNote = (baseNote + octaveShift * 12).coerceIn(0, 127)
        assertEquals(36, shiftedNote)

        // Extreme bounds clamping
        val extremeLow = (baseNote + (-5) * 12).coerceIn(0, 127)
        assertEquals(0, extremeLow)

        val extremeHigh = (baseNote + 10 * 12).coerceIn(0, 127)
        assertEquals(127, extremeHigh)
    }

    @Test
    fun testArrangerSectionsCompleteness() {
        val expectedSections = listOf(
            ArrangerSection.INTRO_1, ArrangerSection.INTRO_2, ArrangerSection.INTRO_3,
            ArrangerSection.VARIATION_1, ArrangerSection.VARIATION_2, ArrangerSection.VARIATION_3, ArrangerSection.VARIATION_4,
            ArrangerSection.FILL_1, ArrangerSection.FILL_2, ArrangerSection.FILL_3, ArrangerSection.FILL_4,
            ArrangerSection.BREAK,
            ArrangerSection.ENDING_1, ArrangerSection.ENDING_2, ArrangerSection.ENDING_3
        )
        assertEquals(15, expectedSections.size)
        assertEquals(expectedSections.size, ArrangerSection.values().size)
    }

    @Test
    fun testAudioDiagnosticsDefaults() {
        val diag = AudioDiagnosticsData()
        assertEquals(0, diag.xrunCount)
        assertEquals(0.0f, diag.cpuLoad, 0.0001f)
        assertEquals(0, diag.activeVoices)
        assertEquals(48000, diag.sampleRate)
    }

    @Test
    fun testSoundEngineVelocityCurveMapping() {
        // Linear mapping: velocity / 127
        val vel127 = 127 / 127.0f
        assertEquals(1.0f, vel127, 0.0001f)
        val vel64 = 64 / 127.0f
        assertTrue("Mid velocity should be approx 0.5", vel64 in 0.49f..0.52f)

        // Soft curve: 1.5v - 0.5v^2 boost lower velocities
        val softVal = 1.5f * vel64 - 0.5f * vel64 * vel64
        assertTrue("Soft curve should produce higher gain than linear for mid velocity", softVal > vel64)

        // Hard curve: v^2 attenuates lower velocities
        val hardVal = vel64 * vel64
        assertTrue("Hard curve should produce lower gain than linear for mid velocity", hardVal < vel64)

        // Fixed velocity
        val fixedVal = 100.0f / 127.0f
        assertEquals(0.7874f, fixedVal, 0.001f)
    }

    @Test
    fun testSoundEngineFilterFrequencyBounds() {
        val minCutoff = 20.0f
        val maxCutoff = 48000.0f * 0.45f // Nyquist safety bound: 21600 Hz
        assertTrue("Filter cutoff must have minimum 20Hz", minCutoff == 20.0f)
        assertTrue("Filter cutoff must remain below Nyquist", maxCutoff < 24000.0f)
    }

    @Test
    fun testModulationDepthClamping() {
        val mod0 = (-0.5f).coerceIn(0.0f, 1.0f)
        val mod1 = (1.5f).coerceIn(0.0f, 1.0f)
        val modHalf = (0.5f).coerceIn(0.0f, 1.0f)
        assertEquals(0.0f, mod0, 0.0001f)
        assertEquals(1.0f, mod1, 0.0001f)
        assertEquals(0.5f, modHalf, 0.0001f)
    }
}
