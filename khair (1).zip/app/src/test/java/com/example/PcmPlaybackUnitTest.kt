package com.example

import com.example.audio.NativeAudioBridge
import com.example.korg.io.KorgBinaryReader
import com.example.korg.models.IrSample
import com.example.korg.parser.PcmParser
import com.example.korg.repository.SetRepositoryImpl
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs
import kotlin.math.pow

/**
 * Unit test suite verifying the complete pipeline from decoded PCM samples to audio engine integration.
 */
class PcmPlaybackUnitTest {

    @Test
    fun testAcousticReferenceSampleCreation() {
        val sample = PcmParser.createAcousticReferenceSample(
            sampleName = "Concert Grand C4",
            sampleRate = 44100,
            rootKey = 60,
            durationSeconds = 0.5f
        )

        assertNotNull("Sample must not be null", sample)
        assertEquals("Concert Grand C4", sample.name)
        assertEquals(44100, sample.sampleRate)
        assertEquals(1, sample.channels)
        assertEquals(16, sample.bitDepth)
        assertEquals(60, sample.rootKey)
        assertTrue("Sample must be looped", sample.isLooped)
        assertEquals(22050L, sample.totalSamples)
        assertNotNull("PCM data must be non-null", sample.pcmData)
        assertEquals(22050 * 2, sample.pcmData!!.size) // 16-bit mono = 2 bytes per sample

        // Verify that the PCM data contains non-zero audio content
        var hasNonZero = false
        for (b in sample.pcmData!!) {
            if (b != 0.toByte()) {
                hasNonZero = true
                break
            }
        }
        assertTrue("PCM data must contain non-zero audio waveforms", hasNonZero)
    }

    @Test
    fun testRiffWaveEncodingAndParsingRoundTrip() {
        // Create known 16-bit PCM test frames
        val frameCount = 1000
        val testShorts = ShortArray(frameCount) { i ->
            (Math.sin(2.0 * Math.PI * 440.0 * i / 44100.0) * 20000.0).toInt().toShort()
        }

        val encodedWaveBytes = PcmParser.encodeRiffWave(
            pcmShorts = testShorts,
            sampleRate = 44100,
            channels = 1,
            rootKey = 60,
            loopStart = 200,
            loopEnd = 800
        )

        assertTrue("Encoded WAVE bytes must be larger than 44 bytes", encodedWaveBytes.size > 44)

        // Parse with PcmParser
        val reader = KorgBinaryReader.fromByteArray(encodedWaveBytes)
        val parser = PcmParser()
        val parsedSample = parser.parseSample(reader, "TestSineWave")

        assertEquals("TestSineWave", parsedSample.name)
        assertEquals(44100, parsedSample.sampleRate)
        assertEquals(1, parsedSample.channels)
        assertEquals(16, parsedSample.bitDepth)
        assertEquals(1000L, parsedSample.totalSamples)
        assertEquals(200L, parsedSample.loopStartSample)
        assertEquals(800L, parsedSample.loopEndSample)
        assertTrue(parsedSample.isLooped)
        assertNotNull(parsedSample.pcmData)
        assertEquals(1000 * 2, parsedSample.pcmData!!.size)
    }

    @Test
    fun testPitchMappingCalculations() {
        // Mathematical verification of pitch ratios used in C++ WorkstationVoicePool:
        // pitchRatio = 2 ^ ((targetNote - rootKey + centOffset/100) / 12)

        val rootKey = 60 // C4

        // 1. Root key (C4) -> ratio 1.0
        val ratioC4 = 2.0.pow((60 - rootKey) / 12.0)
        assertEquals(1.0, ratioC4, 0.0001)

        // 2. Octave up (C5, note 72) -> ratio 2.0
        val ratioC5 = 2.0.pow((72 - rootKey) / 12.0)
        assertEquals(2.0, ratioC5, 0.0001)

        // 3. Octave down (C3, note 48) -> ratio 0.5
        val ratioC3 = 2.0.pow((48 - rootKey) / 12.0)
        assertEquals(0.5, ratioC3, 0.0001)

        // 4. Perfect Fifth (G4, note 67) -> ratio ~1.4983
        val ratioG4 = 2.0.pow((67 - rootKey) / 12.0)
        assertTrue(abs(ratioG4 - 1.498307) < 0.001)

        // 5. Quarter-tone oriental detune (-50 cents on E4 note 64)
        val ratioE4QuarterTone = 2.0.pow((64 - rootKey - 0.5) / 12.0)
        val ratioE4Standard = 2.0.pow((64 - rootKey) / 12.0)
        assertTrue("Quarter tone flat should have lower pitch ratio", ratioE4QuarterTone < ratioE4Standard)
    }

    @Test
    fun testFactoryDemoSetContainsVerifiedPcmSamples() {
        val repository = SetRepositoryImpl()
        val demoPackage = repository.createFactoryDemoSet()

        assertNotNull("Demo package must exist", demoPackage)
        assertTrue("Demo package must contain samples", demoPackage.samples.isNotEmpty())

        val pianoSample = demoPackage.samples.firstOrNull { it.id == "smp_grand_piano_c4_pcm" || it.name.contains("Piano", ignoreCase = true) }
        assertNotNull("Grand Piano PCM sample must be present in demo set", pianoSample)
        assertNotNull("Sample must contain real non-null pcmData", pianoSample!!.pcmData)
        assertTrue("Sample pcmData size must be positive", pianoSample.pcmData!!.size > 1000)
        assertEquals(60, pianoSample.rootKey)
        assertTrue("Sample must have loop points defined", pianoSample.loopEndSample > pianoSample.loopStartSample)
    }

    @Test
    fun testNativeBridgeGracefulFallbackWhenNativeLibUnavailable() {
        val sample = PcmParser.createAcousticReferenceSample(durationSeconds = 0.1f)
        // In JVM unit tests, System.loadLibrary is safely skipped
        val loaded = NativeAudioBridge.loadIrSample(sample, slot = 0)
        if (!NativeAudioBridge.isAvailable) {
            assertFalse("When native library is not present, loadIrSample safely returns false without crashing", loaded)
        }
    }
}
